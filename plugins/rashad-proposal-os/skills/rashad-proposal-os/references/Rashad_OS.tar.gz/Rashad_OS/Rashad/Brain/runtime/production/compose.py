# -*- coding: utf-8 -*-
"""Rashad v7.3.3 instrumented HTML/SVG semantic composer.

Implements:
  62_PRODUCTION_INSTRUMENTATION_CONTRACT  — L3 data-* contract (page/node/edge/slot)
  29_PRODUCTION_EXECUTION_FIREWALL        — Arabic-Indic numeral hard lock, logo geometry
  16_COBRAND_LOGO_DIRECTOR                — Rubix far-left cluster (owner override: top-left)
  45_CROSS_FORMAT_BIDI...                 — declared directional islands, no string reversal
  63_DIRECTIONAL_LAYOUT_ENGINE            — semantic seq drives physical x, RTL origin right
  75_CONNECTOR_SEMANTICS...               — edge_id/source/target/relation/anchors
"""
import html as _h, re
from theme import C, page, asset_uri

LOGO = None
CLIENT_LOGO = None
CURRENT_LAYOUT = {"v": "standard"}
PAGE_META = {}          # page_name -> dict(mode, family, band)

# 71_AUTO_REPAIR_AND_PAGE_SPLIT_POLICY — bounded micro-spacing ladder.
# Allowed: micro spacing, local line-break optimisation, local rebalance.
# Forbidden: shrinking typography below the approved minimum, clipping, hiding.
# Type sizes are NEVER touched here; only spacing and line-height.
DRAFT_MARK = True       # 66_V6_2 ADVISORY export law — cleared only when the
                        # exact handoff guard returns CERTIFIED_FOR_HANDOFF
REPAIR_LEVEL = {}       # page_id -> 0..3
try:
    import json as _json, pathlib as _pl
    _rl = _pl.Path(__file__).parent / "repair_levels.json"
    if _rl.exists():
        REPAIR_LEVEL = _json.loads(_rl.read_text(encoding="utf-8"))
except Exception:
    pass
_REPAIR_CSS = {
 0: "",
 1: (".card{padding:9px 15px}.g{gap:9px}.col{gap:8px}.row{gap:10px}"
     ".p{line-height:1.24}.card .sub{line-height:1.22}table.t td{padding:7px 12px}"),
 2: (".card{padding:7px 14px}.g{gap:7px}.col{gap:6px}.row{gap:9px}"
     ".p{line-height:1.20}.card .sub{line-height:1.19}table.t td{padding:5px 11px}"
     ".body{margin-top:8px}"),
 3: (".card{padding:6px 12px}.g{gap:5px}.col{gap:5px}.row{gap:8px}"
     ".p{line-height:1.17}.card .sub{line-height:1.16}table.t td{padding:4px 10px}"
     ".body{margin-top:6px}.thesis{padding:8px 16px}"),
}

# --------------------------------------------------------------------------- #
# Arabic-Indic numeral lock (29_PRODUCTION_EXECUTION_FIREWALL Rule 5)
# --------------------------------------------------------------------------- #
_AR_DIGITS = "٠١٢٣٤٥٦٧٨٩"
_W2A = {chr(0x30 + i): _AR_DIGITS[i] for i in range(10)}
# Declared LTR islands are technical/immutable by definition (70_V7 admission rule:
# proper name, acronym, standard, immutable identifier, URL/email/code/version) —
# their digits are preserved. Everything else in Arabic prose converts.
_KEEP_RE = re.compile(r'(<span class="(?:keep|ltr)"[^>]*>.*?</span>)', re.S)
_TAG_RE = re.compile(r'(<[^>]+>)')

# Bare immutable identifiers that appear in Arabic prose without an explicit island.
_IMMUTABLE = re.compile(
    r'(PR-IC-\d{4}-\d{3}'
    r'|ISO\s*/?\s*IEC\s*\d{4,5}(?::\d{4})?'
    r'|ISO\s*\d{4,5}(?::\d{4})?'
    r'|NIST\s*(?:SP\s*)?\d{2,4}(?:-\d+)?'
    r'|https?://[^\s<]+'
    r'|[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}'
    r'|\b[a-z0-9-]+\.(?:gov\.sa|com\.sa|sa|com|org)\b'
    r'|\bGPT-\d+(?:\.\d+)?\b'
    r'|\b[A-Z][A-Za-z]*\s?\d+\.\d+\b)')


def _protect_immutables(html_str):
    """Wrap bare immutable technical identifiers in declared preserve islands,
    outside tags, so the numeral lock cannot corrupt them (29_FIREWALL Rule 5
    exception clause; 74_CROSS_FORMAT_BIDI run-order contract)."""
    chunks = _TAG_RE.split(html_str)
    out = []
    for i, ch in enumerate(chunks):
        if i % 2 == 1:
            out.append(ch)
        else:
            out.append(_IMMUTABLE.sub(
                lambda m: f'<span class="keep" data-direction="LTR"'
                          f' data-numeral-policy="PRESERVE">{m.group(0)}</span>', ch))
    return "".join(out)


_STYLE_RE = re.compile(r'(<style\b[^>]*>.*?</style>|<script\b[^>]*>.*?</script>)', re.S | re.I)
# HTML <span> inside <svg> terminates foreign-content parsing and truncates the SVG.
# Inside SVG we therefore convert numerals WITHOUT inserting island elements;
# direction is carried by the element's own direction/unicode-bidi style instead
# (74_CROSS_FORMAT_BIDI: isolation, never string reversal).
_SVG_RE = re.compile(r'(<svg\b.*?</svg>)', re.S | re.I)


def _convert_svg(seg):
    holes, out = [], seg
    for m in list(_IMMUTABLE.finditer(seg))[::-1]:
        holes.append(m.group(0))
        out = out[:m.start()] + f"\x00{len(holes)-1}\x00" + out[m.end():]
    chunks = _TAG_RE.split(out)
    res = []
    for i, ch in enumerate(chunks):
        res.append(ch if i % 2 == 1 else "".join(_W2A.get(c, c) for c in ch))
    out = "".join(res)
    for i, h in enumerate(holes):
        out = out.replace(f"\x00{i}\x00", h)
    return out


_LATIN_RUN = re.compile(r'(?<![A-Za-z0-9<&=."-])((?:[A-Za-z][A-Za-z0-9]*)(?:[ .&/-][A-Za-z][A-Za-z0-9]*)*)(?![A-Za-z0-9;"=])')


def _island_latin(html_str):
    """Every Latin run inside Arabic prose becomes a DECLARED directional island
    (70_V7 foreign-token admission; 74_CROSS_FORMAT_BIDI forbids fixing direction
    by reversing strings — isolation is the sanctioned mechanism)."""
    chunks = _TAG_RE.split(html_str)
    out = []
    for i, ch in enumerate(chunks):
        if i % 2 == 1:
            out.append(ch)
        else:
            out.append(_LATIN_RUN.sub(
                lambda m: f'<span class="ltr" data-direction="LTR">{m.group(1)}</span>', ch))
    return "".join(out)


def to_arabic_indic(html_str):
    """Convert Western digits to Arabic-Indic in visible Arabic text nodes only.
    Declared LTR/preserve islands are byte-preserved. Tag internals and
    <style>/<script> contents are never touched."""
    segs = _STYLE_RE.split(html_str)
    out = []
    for seg in segs:
        if _STYLE_RE.fullmatch(seg):
            out.append(seg)
            continue
        for sub in _SVG_RE.split(seg):
            out.append(_convert_svg(sub) if _SVG_RE.fullmatch(sub) else _convert_visible(sub))
    return "".join(out)


def _convert_visible(html_str):
    html_str = _protect_immutables(html_str)
    parts0 = _KEEP_RE.split(html_str)
    html_str = "".join(p if (p.startswith('<span class="keep"') or p.startswith('<span class="ltr"'))
                       else _island_latin(p) for p in parts0)
    parts = _KEEP_RE.split(html_str)
    out = []
    for part in parts:
        if part.startswith('<span class="keep"') or part.startswith('<span class="ltr"'):
            out.append(part)
            continue
        chunks = _TAG_RE.split(part)
        for i, ch in enumerate(chunks):
            if i % 2 == 1:
                out.append(ch)
            else:
                out.append("".join(_W2A.get(c, c) for c in ch))
    return "".join(out)


def logo():
    global LOGO
    if LOGO is None:
        LOGO = asset_uri("rubix-consulting-current-light.png")
    return LOGO


def esc(s):
    return _h.escape(str(s), quote=False)


def n(x):
    """LTR-isolated numeric island; still subject to the Arabic-Indic lock."""
    return f'<span class="num" data-numeral-policy="ARABIC_INDIC">{x}</span>'


def L(x):
    """Latin acronym island — bidi-isolated, digits still converted if present."""
    return f'<span class="ltr" data-direction="LTR">{x}</span>'


def keep(x):
    """Immutable technical identifier — LTR and numeral-preserved."""
    return f'<span class="keep" data-direction="LTR" data-numeral-policy="PRESERVE">{x}</span>'


# --------------------------------------------------------------------------- #
# Page frame
# --------------------------------------------------------------------------- #
DURATION_CLASSES = ("RASHAD_PRODUCTION_TIME", "RUBIX_HUMAN_CALENDAR",
                    "CLIENT_CALENDAR", "CONTRACT_CALENDAR")


def dur(cls, inner, tag="div", extra=""):
    """Wrap content that states a duration with its declared class
    (86_V7_3_3 RASHAD PURPOSE & TIME-TO-VALUE LAW section 2)."""
    assert cls in DURATION_CLASSES, cls
    return f'<{tag} data-duration-class="{cls}" {extra}>{inner}</{tag}>'


_TOPLEVEL = re.compile(r'<(div|table|section|ul|ol)(\s[^>]*)?>')


def auto_instrument(body_html, pid):
    """62_PRODUCTION_INSTRUMENTATION_CONTRACT step 4 of the migration path.

    Assigns a STRUCTURAL identity to visible analytical objects that the page
    author did not model semantically. These are real, visible objects — this is
    instrumentation, not invented topology, and each carries
    data-node-origin="AUTO_STRUCTURAL" so the coverage report can separate
    modelled nodes from structural ones (81_GVM_SEMANTIC_TOPOLOGY_SIDECAR
    forbids fabricating hidden nodes purely to satisfy a gate)."""
    out, pos, k = [], 0, 0
    for m in _TOPLEVEL.finditer(body_html):
        attrs = m.group(2) or ""
        if "data-node-id" in attrs:
            continue
        cls = re.search(r'class="([^"]*)"', attrs)
        classes = set((cls.group(1) if cls else "").split())
        if not (classes & {"card", "t", "statcard", "chip", "bar", "vwrap"}) and \
           "style=" not in attrs:
            continue
        k += 1
        ins = (f' data-node-id="{pid}-S{k:02d}" data-node-type="EVIDENCE"'
               f' data-node-origin="AUTO_STRUCTURAL"')
        out.append(body_html[pos:m.end() - 1]); out.append(ins)
        pos = m.end() - 1
    out.append(body_html[pos:])
    return "".join(out)


def frame(*, role, kicker, chapter, title, thesis, thesis_lab="الخلاصة",
          thesis_tone="", body, sources, pgno, total, layout=None,
          page_id=None, mode="ARTIFACT_LED", family="ANALYTICAL", band="AC-2",
          client_logo=None, duration_class=None):
    layout = layout or CURRENT_LAYOUT.get("v", "standard")
    pid = page_id or f"P{pgno:02d}"
    body = auto_instrument(body, pid)

    head = (f'<div class="kick" data-header-role="EYEBROW" data-content-slot="question">'
            f'<span class="ch">{esc(chapter)}</span> &nbsp;·&nbsp; {esc(kicker)}</div>'
            f'<div class="h1" data-header-role="TITLE" data-content-slot="question" data-stress-grow>{title}</div>')

    # Co-brand cluster — owner override 2026-08-20: cluster moves to TOP-LEFT.
    # Rubix remains far-left within the cluster (16_COBRAND, never mirrored by RTL).
    cl = client_logo if client_logo is not None else CLIENT_LOGO
    client_mark = (f'<img class="mark client" src="{cl}" data-asset-id="CLIENT_MARK">'
                   if cl else
                   f'<span class="mark client slot" data-asset-id="CLIENT_MARK_ABSENT"'
                   f' data-client-logo-status="REQUIRED_NOT_SUPPLIED"></span>')
    cobrand = (f'<div class="cobrand" data-region-id="BAND" data-region-role="COBRAND"'
               f' data-cobrand-order="RUBIX_LEFT__CLIENT_RIGHT" data-mirror-policy="NEVER_MIRROR">'
               f'<img class="mark rubix" src="{logo()}" data-asset-id="RUBIX_CONSULTING_LIGHT">'
               f'<span class="sep"></span>{client_mark}</div>')

    # Page number — owner instruction: BOTTOM-LEFT. Arabic-Indic, one bidi island.
    pgblock = (f'<div class="pgno" data-content-slot="pagenum" data-direction="LTR">'
               f'<span class="num" data-numeral-policy="ARABIC_INDIC">{pgno} / {total}</span></div>')

    foot = (f'<div class="foot" data-region-id="SOURCE" data-area-budget="0.06">'
            f'{pgblock}'
            f'<div class="src" data-content-slot="source" data-confidence="HIGH">{sources}</div>'
            f'</div>')

    def th(cls=""):
        if not thesis:
            return ""
        dc = f' data-duration-class="{duration_class}"' if duration_class else ""
        return (f'<div class="thesis {thesis_tone} {cls}" data-region-id="SUPPORTING"'
                f' data-region-role="IMPLICATION" data-area-budget="0.14"{dc}>'
                f'<div class="lab">{thesis_lab}</div>'
                f'<div class="txt" data-content-slot="thesis" data-stress-grow>{thesis}</div></div>')

    hdr = (f'<div class="hdr" data-region-id="BAND" data-region-role="HEADER"'
           f' data-area-budget="0.16">{cobrand}<div class="headtext">{head}</div></div>')
    rule = '<div class="rule" data-divider-id="D-TITLE"></div>'

    if layout == "banner":
        dcb = f' data-duration-class="{duration_class}"' if duration_class else ""
        inner = (f'<div class="pad">{hdr}{rule}'
                 f'<div class="body banner" data-region-id="DOMINANT" data-area-budget="0.60"{dcb}>{body}</div>'
                 f'{th("bottom")}{foot}</div>')
    else:
        dcb = f' data-duration-class="{duration_class}"' if duration_class else ""
        inner = (f'<div class="pad">{hdr}{rule}{th()}'
                 f'<div class="body" data-region-id="DOMINANT" data-area-budget="0.58"{dcb}>{body}</div>'
                 f'{foot}</div>')

    lvl = REPAIR_LEVEL.get(pid, 0)
    mark = ('<div class="draftmark" data-release-status="ADVISORY_UNVERIFIED">'
            '<i>DRAFT \u2014 NOT RELEASED</i></div>') if DRAFT_MARK else ""
    slide = (f'<section class="slide" data-page-id="{pid}" data-page-mode="{mode}"'
             f' data-page-family="{family}" data-canvas="1600x900"'
             f' data-complexity-band="{band}" data-role="{role}" data-page="{pgno}"'
             f' data-layout="{layout}" data-repair-level="{lvl}"'
             f' data-release-status="{"ADVISORY_UNVERIFIED" if DRAFT_MARK else "QA_CANDIDATE"}"'
             f' dir="rtl" lang="ar">{inner}{mark}</section>')
    return to_arabic_indic(page(slide, _REPAIR_CSS.get(lvl, '')))


# --------------------------------------------------------------------------- #
# primitives — every analytical object carries node identity
# --------------------------------------------------------------------------- #
_AUTO = {"i": 0}


def _nid(nid):
    if nid:
        return nid
    _AUTO["i"] += 1
    return f"N-A{_AUTO['i']:03d}"


def _attrs(nid=None, ntype="EVIDENCE", seqg=None, seq=None, align=None,
           axis="START", spacing=None, owner=None, anchor=None, extra=""):
    a = [f'data-node-id="{_nid(nid)}"', f'data-node-type="{ntype}"']
    if seqg:
        a.append(f'data-seq-group="{seqg}"')
        a.append(f'data-seq="{seq}"')
    if align:
        a.append(f'data-align-group="{align}"')
        a.append(f'data-align-axis="{axis}"')
    if spacing:
        a.append(f'data-spacing-group="{spacing}"')
    if owner:
        a.append(f'data-owner-id="{owner}"')
        a.append(f'data-anchor="{anchor or "TOP_START"}"')
    if extra:
        a.append(extra)
    return " ".join(a)


def chip(text, tone="gry", owner=None, anchor=None):
    o = f' data-owner-id="{owner}" data-anchor="{anchor or "TOP_START"}"' if owner else ""
    return f'<span class="chip c-{tone}"{o}>{text}</span>'


def card(title, sub="", tint="", extra="", nid=None, ntype="CAPABILITY",
         seqg=None, seq=None, align=None, spacing=None, slot="evidence"):
    s = (f'<div class="sub" data-content-slot="{slot}" data-stress-grow>{sub}</div>') if sub else ""
    return (f'<div class="card {tint}" {_attrs(nid, ntype, seqg, seq, align, "CENTER_Y", spacing)}>'
            f'<div class="ttl" data-label-for="{_LAST["id"]}">{title}</div>{s}{extra}</div>')


_LAST = {"id": ""}
_orig_nid = _nid


def _nid(nid):                                     # noqa: F811  (track last id for labels)
    v = _orig_nid(nid)
    _LAST["id"] = v
    return v


def stat(value, label, unit="", note="", tint="", small=False, nid=None,
         ntype="MEASURE", seqg=None, seq=None):
    u = f'<span class="u">{unit}</span>' if unit else ""
    nt = (f'<div class="p sm" style="margin-top:8px" data-content-slot="interpretation"'
          f' data-stress-grow>{note}</div>') if note else ""
    cls = "metric sm" if small else "metric"
    at = _attrs(nid, ntype, seqg, seq)
    return (f'<div class="card {tint} statcard" {at}>'
            f'<div class="lab" data-label-for="{_LAST["id"]}">{label}</div>'
            f'<div class="{cls}" data-content-slot="evidence">{value}{u}</div>{nt}</div>')


def table(headers, rows, widths=None, dense=False, aligns=None, tight=False,
          role="EVIDENCE", tid=None):
    cg = ""
    if widths:
        cg = "<colgroup>" + "".join(f'<col style="width:{w}%">' for w in widths) + "</colgroup>"
    th = "".join(f'<th class="{(aligns or [""]*len(headers))[i]}" scope="col">{c}</th>'
                 for i, c in enumerate(headers))
    tr = []
    for i, r in enumerate(rows):
        tds = []
        for j, c in enumerate(r):
            cls = "k" if j == 0 else ""
            a = (aligns or [""] * len(headers))[j] if aligns else ""
            slot = ' data-content-slot="evidence" data-stress-grow' if j else ' data-content-slot="evidence"'
            tds.append(f'<td class="{cls} {a}"{slot}>{c}</td>')
        tr.append(f'<tr class="{"alt" if i%2 else ""}" data-row="{i+1}">' + "".join(tds) + "</tr>")
    tid = tid or f"T-{_orig_nid(None)}"
    return (f'<table class="t {"dense" if dense else ""} {"tight" if tight else ""}"'
            f' data-table-role="{role}" data-node-id="{tid}" data-node-type="EVIDENCE">'
            f'{cg}<thead><tr>{th}</tr></thead><tbody>{"".join(tr)}</tbody></table>')


def dot(color):
    return f'<span class="dot" style="background:{color}"></span>'


def bar(segments, nid=None):
    inner = "".join(f'<i style="width:{p}%;background:{c}"></i>' for p, c in segments)
    return f'<div class="bar" {_attrs(nid, "MEASURE")}>{inner}</div>'
