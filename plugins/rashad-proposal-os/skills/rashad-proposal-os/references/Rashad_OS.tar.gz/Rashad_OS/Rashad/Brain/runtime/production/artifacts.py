# -*- coding: utf-8 -*-
"""Relational artifact primitives — the vector layer.

55_HTML_SVG_SEMANTIC_COMPOSER_RUNTIME_CONTRACT: SVG owns flows, connectors,
matrices, timelines and custom relationship geometry. Div-only approximations of
relationship-rich artifacts are prohibited.
75_CONNECTOR_SEMANTICS_AND_ENDPOINT_CONTRACT: every edge carries edge_id,
source, target, relationship_type, directionality, anchors, route policy.
63_DIRECTIONAL_LAYOUT_ENGINE: RTL — logical item 1 sits at the physical RIGHT.
"""
from theme import C

ARROW = ('<defs><marker id="ah" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7"'
         ' markerHeight="7" orient="auto-start-reverse">'
         '<path d="M0,0 L10,5 L0,10 z" fill="{c}"/></marker>'
         '<marker id="ahm" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7"'
         ' markerHeight="7" orient="auto-start-reverse">'
         '<path d="M0,0 L10,5 L0,10 z" fill="{m}"/></marker></defs>')


def svgwrap(w, h, inner, nid="A-SVG", cls="flow"):
    """1:1 projection — viewBox units ARE CSS px, so no downscale can shrink type
    below the binding pt floors (83_V7_3_2 clause 3)."""
    h = int(round(h))
    return (f'<div class="vwrap" data-node-id="{nid}" data-node-type="ASSET"'
            f' data-artifact-family="RELATIONAL" style="height:{h}px;flex:none">'
            f'<svg class="{cls}" viewBox="0 0 {w} {h}" width="{w}" height="{h}"'
            f' preserveAspectRatio="xMinYMin meet" style="height:{h}px">'
            f'{ARROW.format(c=C["muted"], m=C["magenta"])}{inner}</svg></div>')


# In an RTL text element, SVG text-anchor `start` is the PHYSICAL RIGHT edge.
# _tw takes a PHYSICAL anchor and maps it, so callers reason in page geometry
# (63_DIRECTIONAL_LAYOUT_ENGINE: direction is physical reading geometry).
_PHYS = {"right": "start", "left": "end", "middle": "middle"}


def _tw(x, y, s, size=22, weight=600, fill=None, anchor="middle", cls="nlab"):
    return (f'<text class="{cls}" x="{x:.1f}" y="{y:.1f}" font-size="{size}" font-weight="{weight}"'
            f' fill="{fill or C["ink"]}" text-anchor="{_PHYS.get(anchor, anchor)}"'
            f' style="direction:rtl;unicode-bidi:isolate">{s}</text>')


def timebands(bands, w=1440, h=None, axis_label="", nid="A-TIME", row_h=30):
    """Duration bands, each with a DECLARED duration class. RTL: t0 at the physical
    RIGHT, time progresses leftward (63_DIRECTIONAL_LAYOUT_ENGINE).
    Height is COMPUTED from content — never clamped, so a band can never be painted
    over its neighbour's labels (60_RENDER_QA_THREAT_MODEL surface 9)."""
    pad_r, pad_l = 620, 210
    plot = w - pad_r - pad_l
    head_h, gap_b, axis_h = 54, 12, (28 if axis_label else 4)
    total_h = 6 + axis_h + sum(head_h + row_h * len(b["items"]) + gap_b for b in bands)
    y = 6
    o = []
    for bi, b in enumerate(bands):
        tone = b.get("tone", "magenta")
        col = C[tone]
        bh = head_h + row_h * len(b["items"])
        o.append(f'<rect x="{pad_l-14}" y="{y}" width="{w-pad_l+8}" height="{bh-6}" rx="9" '
                 f'fill="{C.get(tone[:3]+"8", C["warm"])}" opacity=".62"/>')
        o.append(_tw(w - 22, y + 30, b["label"], 25, 700, col, "right"))
        o.append(_tw(w - 22, y + 52, b["sub"], 20, 500, C["muted"], "right"))
        yy = y + head_h
        for i, (nm, s0, s1, owner) in enumerate(b["items"]):
            x1 = pad_l + plot * (1 - s1)
            x0 = pad_l + plot * (1 - s0)
            bw = max(9, x0 - x1)
            cy = yy + row_h / 2
            o.append(f'<rect data-node-id="{nid}-B{bi}{i}" data-node-type="PROCESS"'
                     f' data-seq-group="{nid}-band{bi}" data-seq="{i+1}"'
                     f' x="{x1:.1f}" y="{cy-10:.1f}" width="{bw:.1f}" height="20" rx="5"'
                     f' fill="{col}" opacity=".93"/>')
            o.append(_tw(w - 14, cy + 7, nm, 21, 600, C["ink"], "right"))
            o.append(_tw(pad_l - 16, cy + 6, owner, 20, 500, C["muted"], "right"))
            yy += row_h
        y += bh + gap_b
    if axis_label:
        o.append(f'<line x1="{pad_l}" y1="{y+2}" x2="{w-pad_r}" y2="{y+2}"'
                 f' stroke="{C["hair"]}" stroke-width="2"/>')
        o.append(_tw(w - pad_r, y + 24, axis_label, 20, 500, C["muted"], "right"))
    return svgwrap(w, total_h, "".join(o), nid)


def mapflow(left, right, edges, w=1440, h=470, ltitle="", rtitle="", nid="A-MAP"):
    """Two-column relational mapping with real connectors.
    RTL: the SOURCE column sits physically right, the TARGET column left.
    left/right: [(node_id, label, sub, tone)]; edges: [(eid, src, tgt, relation, tone)]
    """
    colw, gap = 430, 240
    xr = w - colw - 10          # physically right = logical source
    xl = 10
    def col(items, x, title):
        o = [_tw(x + colw / 2, 26, title, 21, 700, C["muted"])] if title else []
        step = (h - 70) / max(1, len(items))
        for i, (nid_, lab, sub, tone) in enumerate(items):
            y = 50 + i * step
            o.append(f'<rect data-node-id="{nid_}" data-node-type="CAPABILITY"'
                     f' x="{x}" y="{y}" width="{colw}" height="{step-16}" rx="7"'
                     f' fill="{C.get(tone[:3]+"8", C["warm"])}" stroke="{C.get(tone,C["hair"])}" stroke-width="1.6"/>')
            o.append(_tw(x + colw - 16, y + 30, lab, 22, 600, C["ink"], "right"))
            if sub:
                o.append(_tw(x + colw - 16, y + 56, sub, 19, 400, C["ink2"], "right"))
        return "".join(o), step
    ro, stepr = col(left, xr, ltitle)
    lo, stepl = col(right, xl, rtitle)
    pos = {}
    for i, (nid_, *_r) in enumerate(left):
        pos[nid_] = (xr, 50 + i * stepr + (stepr - 16) / 2)
    for i, (nid_, *_r) in enumerate(right):
        pos[nid_] = (xl + colw, 50 + i * stepl + (stepl - 16) / 2)
    eo = []
    for eid, s, t, rel, tone in edges:
        if s not in pos or t not in pos:
            continue
        x1, y1 = pos[s]; x2, y2 = pos[t]
        mx = (x1 + x2) / 2
        eo.append(f'<path class="edge{" strong" if tone=="mag" else ""}"'
                  f' data-edge-id="{eid}" data-source="{s}" data-target="{t}"'
                  f' data-relation="{rel}" data-directionality="DIRECTED"'
                  f' data-source-anchor="START" data-target-anchor="END" data-route-policy="CURVED"'
                  f' d="M{x1},{y1} C{mx},{y1} {mx},{y2} {x2},{y2}"'
                  f' marker-end="url(#{"ahm" if tone=="mag" else "ah"})"/>')
    return svgwrap(w, h, "".join(eo) + ro + lo, nid)


def field2d(points, w=1440, h=470, xlab="", ylab="", quads=None, nid="A-FIELD"):
    """Positioning field (risk, priority, trade-off). points: [(id,label,x,y,tone,size)]
    x,y in 0..1 with x=1 at the physical RIGHT (RTL origin)."""
    ml, mr, mt, mb = 60, 210, 34, 62
    pw, ph = w - ml - mr, h - mt - mb
    o = [f'<rect x="{ml}" y="{mt}" width="{pw}" height="{ph}" fill="{C["warm"]}" stroke="{C["hair"]}"/>']
    o.append(f'<line x1="{ml}" y1="{mt+ph/2}" x2="{ml+pw}" y2="{mt+ph/2}" stroke="{C["hair"]}" stroke-dasharray="6 6"/>')
    o.append(f'<line x1="{ml+pw/2}" y1="{mt}" x2="{ml+pw/2}" y2="{mt+ph}" stroke="{C["hair"]}" stroke-dasharray="6 6"/>')
    for q in (quads or []):
        qx, qy, txt, tone = q
        o.append(_tw(ml + pw * qx, mt + ph * qy, txt, 20, 600, C.get(tone, C["muted"]), "middle"))
    for pid, lab, x, y, tone, sz in points:
        cx = ml + pw * (1 - x)
        cy = mt + ph * (1 - y)
        o.append(f'<circle data-node-id="{pid}" data-node-type="RISK" cx="{cx}" cy="{cy}" r="{sz}"'
                 f' fill="{C.get(tone,C["magenta"])}" opacity=".85"/>')
        o.append(_tw(cx, cy + 6, pid, 18, 700, "#fff", "middle"))
        o.append(_tw(cx + sz + 8, cy + 6, lab, 19, 500, C["ink2"], "left"))
    o.append(_tw(ml + pw / 2, h - 22, xlab, 20, 600, C["muted"], "middle"))
    o.append(f'<text class="nlab" transform="translate({ml-22},{mt+ph/2}) rotate(-90)" font-size="20"'
             f' font-weight="600" fill="{C["muted"]}" text-anchor="middle">{ylab}</text>')
    return svgwrap(w, h, "".join(o), nid)


def stackbars(rows, w=1440, h=440, nid="A-BARS", unit=""):
    """Quantitative comparison bars. rows: [(id,label,value,max,tone,note)] — RTL:
    bars grow from the physical RIGHT edge leftward."""
    lab_w, right = 330, 40
    plot = w - lab_w - right - 150
    o = []
    step = (h - 30) / max(1, len(rows))
    for i, (rid, lab, val, mx, tone, note) in enumerate(rows):
        y = 16 + i * step
        bw = plot * (val / mx if mx else 0)
        x0 = w - right - lab_w
        o.append(_tw(w - right, y + 26, lab, 22, 600, C["ink"], "right"))
        o.append(f'<rect x="{x0-plot}" y="{y+8}" width="{plot}" height="26" rx="4" fill="{C["hair"]}" opacity=".55"/>')
        o.append(f'<rect data-node-id="{rid}" data-node-type="MEASURE" x="{x0-bw}" y="{y+8}"'
                 f' width="{bw}" height="26" rx="4" fill="{C.get(tone,C["magenta"])}"/>')
        o.append(_tw(x0 - bw - 12, y + 29, f"{val}{unit}", 21, 700, C.get(tone, C["magenta"]), "end"))
        if note:
            o.append(_tw(w - right, y + 52, note, 18, 400, C["muted"], "right"))
    return svgwrap(w, h, "".join(o), nid)
