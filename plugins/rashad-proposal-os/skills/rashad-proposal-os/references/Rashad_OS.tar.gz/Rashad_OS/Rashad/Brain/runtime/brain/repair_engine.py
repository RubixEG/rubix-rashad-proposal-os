from __future__ import annotations
import copy, hashlib, json
from brain.composition_spec import validate_page_composition_spec

FORMS=['LANE','SPINE','FIELD','HUB','STACK','MATRIX','LADDER','RING','TREE','FUNNEL']
UNREPAIRABLE={
 'EVIDENCE':['EVIDENCE','SOURCE_ID','CLAIM_EVIDENCE','UNSOURCED'],
 'ASSET':['CLIENT_LOGO','IMAGE_ADMISSION','BRAND_PREFLIGHT','FONT_PREFLIGHT'],
 'LANGUAGE':['WESTERN_NUMERAL','VISIBLE_LANGUAGE','RTL_BIDI','INTERNAL_VOCAB'],
 'DEPTH':['DEPTH_','ROLE_CONTRACT','CLARIFICATION_WINDOW','DATE_CONFLICT'],
}

def _hash_spec(spec):
    payload={k:v for k,v in spec.items() if k not in {'spec_sha256','validation'}}
    return hashlib.sha256(json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def _expand(b, amount=.035):
    b=dict(b or {}); x=max(.04,float(b.get('x',.22)) - amount); y=max(.16,float(b.get('y',.24)) - amount)
    r=min(.96,float(b.get('x',.22))+float(b.get('w',.56))+amount); bot=min(.88,float(b.get('y',.24))+float(b.get('h',.48))+amount)
    return {'x':round(x,4),'y':round(y,4),'w':round(max(.20,r-x),4),'h':round(max(.20,bot-y),4)}

def _tokens(qa):
    raw=((qa or {}).get('hard_blockers') or [])+((qa or {}).get('blocking_gates') or [])+((qa or {}).get('blockers') or [])
    return [str(x) for x in raw]

def repair_spec(spec, qa, round_no):
    s=copy.deepcopy(spec or {}); blockers=_tokens(qa); joined=' '.join(blockers).upper(); ops=[]
    for fam,toks in UNREPAIRABLE.items():
        if any(t in joined for t in toks):
            return {'status':'UNREPAIRABLE_BY_DESIGN','reason':fam+'_BLOCKER_REQUIRES_UPSTREAM_REPAIR','original_blockers':blockers,'spec':s,'operations':[]}
    s.setdefault('dominant_bbox',{'x':.22,'y':.24,'w':.56,'h':.48})
    s.setdefault('focal_anchor',{'zone':'CENTER','bbox':copy.deepcopy(s['dominant_bbox']),'salience_rank':1})
    s['focal_anchor'].setdefault('bbox',copy.deepcopy(s['dominant_bbox']))
    old_form=s.get('dominant_form') or 'FIELD'; scores=(qa or {}).get('scores') or {}
    low_form=float(scores.get('visual_form_fitness',100) or 0)<90 or any(k in joined for k in ('CARD','TEMPLATE','G18','GENERIC','VARIETY'))
    if low_form:
        try: idx=FORMS.index(old_form)
        except ValueError: idx=2
        nxt=FORMS[(idx+max(1,int(round_no)))%len(FORMS)]; s['dominant_form']=nxt; ops.append('CHANGE_DOMINANT_FORM:'+old_form+'->'+nxt)
    low_prod=float(scores.get('production_quality',100) or 0)<90 or any(k in joined for k in ('C9_PIXEL','UNDERFILL','DENSITY','BLANK','DOMINANT_MASS'))
    if low_prod:
        s['dominant_bbox']=_expand(s.get('dominant_bbox'), .025 + .008*max(0,int(round_no)-1)); s['focal_anchor']['bbox']=copy.deepcopy(s['dominant_bbox'])
        s['dominant_mass_target']=round(min(.66,max(.38,float(s.get('dominant_mass_target',.42))+.04)),3); ops.append('EXPAND_DOMINANT_MASS')
    if any(k in joined for k in ('CONNECTOR','G41','G16','LABEL')):
        topo=s.setdefault('topology',{}); topo['route_policy']='ORTHOGONAL_CLEARANCE'; topo['crossing_budget']=0; ops.append('REROUTE_CONNECTORS')
    if any(k in joined for k in ('G40_COLUMN_BALANCE','MASS_IMBALANCE')):
        # Shift focal zone instead of blindly increasing mass.
        seq=['LEFT_CENTER','RIGHT_CENTER','CENTER','UPPER_RIGHT','UPPER_LEFT']; old=s['focal_anchor'].get('zone','CENTER'); s['focal_anchor']['zone']=seq[(seq.index(old)+1)%len(seq)] if old in seq else 'CENTER'; ops.append('REBALANCE_FOCAL_ZONE')
    if not ops:
        return {'status':'UNREPAIRABLE_BY_DESIGN','reason':'NO_SAFE_REPAIR_OPERATION_FOR_BLOCKER_CLASS','original_blockers':blockers,'spec':s,'operations':[]}
    s['repair_revision']=int(s.get('repair_revision',0))+1; s['repair_operations']=list(dict.fromkeys((s.get('repair_operations') or [])+ops+[f'ROUND_{round_no}_REVISION']))
    s['spec_sha256']=_hash_spec(s); s['validation']=validate_page_composition_spec(s)
    return {'status':'PASS' if s['validation']['status']=='PASS' else 'BLOCKED','spec':s,'operations':s['repair_operations'],'original_blockers':blockers}
