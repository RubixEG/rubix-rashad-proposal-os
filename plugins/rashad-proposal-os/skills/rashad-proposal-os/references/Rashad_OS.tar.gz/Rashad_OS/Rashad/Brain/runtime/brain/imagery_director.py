from __future__ import annotations
from pathlib import Path
import hashlib,json,uuid
from .image_asset_scanner import scan_image

def _sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def build_image_request(spec,content_pack):
    im=spec.get('imagery') or {}; mode=im.get('mode','NONE')
    if mode=='NONE': return {'status':'NOT_REQUIRED','mode':mode}
    payload={'schema':'RASHAD_HOST_NATIVE_IMAGE_REQUEST_V1','request_id':'IMGREQ-'+uuid.uuid4().hex[:12].upper(),'page_id':spec.get('page_id'),'mode':mode,'scene':spec.get('scene_metaphor'),'negative_space_zones':spec.get('negative_space_zones'),'dominant_bbox':spec.get('dominant_bbox'),'forbidden':['legible text','logos','digits','official seals'],'style':'premium consulting editorial, restrained, institutional, photoreal or materially sophisticated as appropriate','content_theme':str(content_pack.get('title') or content_pack.get('thesis') or '')[:300]}
    payload['request_sha256']=hashlib.sha256(json.dumps(payload,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
    return {'status':'HOST_NATIVE_IMAGE_PENDING','mode':mode,'request':payload}

def validate_image_plate(result,request,admission_scan=None):
    """Validate a generated plate using an independent scan, not provider declarations.

    `result` proves generation/request binding. `admission_scan` must come from a separate
    OCR/logo/digit/seal scanner and be bound to the actual asset hash.
    """
    if not isinstance(result,dict): return {'status':'BLOCKED','reason':'IMAGE_RESULT_REQUIRED','blockers':['IMAGE_RESULT_REQUIRED']}
    proof=result.get('proof') or {}; blockers=[]
    if result.get('status')!='PASS': blockers.append('IMAGE_PROVIDER_NOT_PASS')
    if proof.get('request_sha256')!=request.get('request_sha256'): blockers.append('IMAGE_REQUEST_BINDING_MISMATCH')
    asset=result.get('asset_path') or result.get('image_path'); expected=result.get('asset_sha256') or result.get('image_sha256')
    actual=None
    if not asset or not Path(asset).exists() or not expected: blockers.append('IMAGE_ASSET_PROOF_REQUIRED')
    else:
        actual=_sha(asset)
        if actual!=expected: blockers.append('IMAGE_ASSET_HASH_MISMATCH')
    # Production truth is recomputed from the asset bytes by the in-package OCR/CV scanner.
    # Caller/provider declarations are supplemental only and can never make a dirty asset clean.
    scan=scan_image(asset,scanner_actor_id='RASHAD-OCR-CV-SCANNER-V1') if asset and Path(asset).exists() else {}
    if scan.get('schema')!='RASHAD_IMAGE_ADMISSION_SCAN_V1': blockers.append('INDEPENDENT_IMAGE_ADMISSION_SCAN_REQUIRED')
    if scan and scan.get('status')!='PASS': blockers.append('IMAGE_ADMISSION_SCANNER_NOT_PASS')
    if actual and scan and scan.get('asset_sha256')!=actual: blockers.append('IMAGE_ADMISSION_SCAN_HASH_MISMATCH')
    if scan and not scan.get('scanner_actor_id'): blockers.append('IMAGE_ADMISSION_SCANNER_ID_REQUIRED')
    provider_actor=str(result.get('provider_actor_id') or result.get('actor_id') or '')
    if provider_actor and scan.get('scanner_actor_id')==provider_actor: blockers.append('IMAGE_PROVIDER_SCANNER_COLLISION')
    if admission_scan:
        ext=dict(admission_scan)
        if actual and ext.get('asset_sha256') not in (None,actual): blockers.append('EXTERNAL_IMAGE_SCAN_HASH_MISMATCH')
    if str(scan.get('ocr_text') or '').strip(): blockers.append('GENERATED_IMAGE_CONTAINS_TEXT')
    if scan.get('contains_logo') is not False: blockers.append('GENERATED_IMAGE_LOGO_NOT_PROVEN_ABSENT')
    if scan.get('contains_digits') is not False: blockers.append('GENERATED_IMAGE_DIGITS_NOT_PROVEN_ABSENT')
    if scan.get('contains_official_seal') is not False: blockers.append('GENERATED_IMAGE_SEAL_NOT_PROVEN_ABSENT')
    return {'status':'PASS' if not blockers else 'BLOCKED','blockers':sorted(set(blockers)),'asset_path':asset,'asset_sha256':expected,'admission_scan':scan,'rule':'Generated visual plates are non-authoritative. Independent hash-bound scanning must prove text, logos, digits and official seals absent before native overlays are applied.'}
