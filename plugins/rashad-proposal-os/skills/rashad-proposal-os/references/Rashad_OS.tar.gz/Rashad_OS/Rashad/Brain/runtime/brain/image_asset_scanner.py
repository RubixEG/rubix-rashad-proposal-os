from __future__ import annotations
from pathlib import Path
import hashlib, json, re, shutil, tempfile, zipfile
from collections import Counter, defaultdict

SCHEMA='RASHAD_IMAGE_ADMISSION_SCAN_V1'

def sha256_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def _require_ocr():
    try:
        import pytesseract, cv2  # noqa
        from PIL import Image  # noqa
    except Exception as e:
        return False, f'OCR_CV_IMPORT_FAILED:{e}'
    if shutil.which('tesseract') is None:
        return False, 'TESSERACT_BINARY_NOT_FOUND'
    return True, None

def scan_image(path, *, scanner_actor_id='RASHAD-OCR-CV-SCANNER-V1', known_logo_paths=None):
    """Independent byte-opening OCR/CV scan. No provider declaration is trusted.

    This is deliberately conservative for release: OCR text/digits always block generated plates.
    Logo evidence is detected by reference-template matching when known logos are supplied and by
    compact high-contrast mark heuristics; official-seal evidence is detected by circular-contour
    heuristics. The exact asset hash is always recorded.
    """
    p=Path(path); blockers=[]
    if not p.exists():
        return {'schema':SCHEMA,'status':'BLOCKED','scanner_actor_id':scanner_actor_id,'blockers':['IMAGE_NOT_FOUND']}
    ok,reason=_require_ocr()
    if not ok:
        return {'schema':SCHEMA,'status':'BLOCKED','scanner_actor_id':scanner_actor_id,'asset_sha256':sha256_file(p),'blockers':['OCR_CV_PREREQUISITE_UNAVAILABLE',reason]}
    import cv2, numpy as np, pytesseract
    img=cv2.imread(str(p),cv2.IMREAD_UNCHANGED)
    if img is None:
        return {'schema':SCHEMA,'status':'BLOCKED','scanner_actor_id':scanner_actor_id,'asset_sha256':sha256_file(p),'blockers':['IMAGE_DECODE_FAILED']}
    if img.ndim==2: gray=img
    else: gray=cv2.cvtColor(img[:,:,:3],cv2.COLOR_BGR2GRAY)
    h,w=gray.shape[:2]
    # Mechanical plate sanity: generated visual plates must contain coherent continuous-tone
    # structure. This is not an aesthetic scorer; it only rejects flat placeholders and
    # pathological uncorrelated RGB noise that otherwise satisfies OCR/logo absence.
    import numpy as np
    gs=gray.astype('float32')
    luma_std=float(gs.std())
    if w>2:
        x=gs[:,:-1].ravel(); y=gs[:,1:].ravel()
        sx=float(x.std()); sy=float(y.std())
        neighbor_corr=float(np.corrcoef(x,y)[0,1]) if sx>1e-6 and sy>1e-6 else 1.0
        neighbor_abs_diff=float(np.abs(gs[:,1:]-gs[:,:-1]).mean())
    else:
        neighbor_corr=1.0; neighbor_abs_diff=0.0
    quality_blockers=[]
    if luma_std<7.0: quality_blockers.append('IMAGE_EFFECTIVELY_FLAT')
    if neighbor_corr<0.12 and neighbor_abs_diff>38.0: quality_blockers.append('IMAGE_UNCORRELATED_RANDOM_NOISE')
    # OCR at native plus upscaled pass for small marks.
    try:
        data=pytesseract.image_to_data(gray,config='--psm 11',output_type=pytesseract.Output.DICT)
        toks=[]
        for i,t in enumerate(data.get('text',[])):
            t=str(t).strip(); conf=float(data.get('conf',['-1'])[i] or -1)
            if t and conf>=25: toks.append(t)
        ocr=' '.join(toks).strip()
    except Exception as e:
        return {'schema':SCHEMA,'status':'BLOCKED','scanner_actor_id':scanner_actor_id,'asset_sha256':sha256_file(p),'blockers':['OCR_EXECUTION_FAILED:'+str(e)[:120]]}
    contains_digits=bool(re.search(r'[0-9٠-٩۰-۹]',ocr))
    # Reference logo matching.
    logo_matches=[]
    for ref in known_logo_paths or []:
        rp=Path(ref)
        if not rp.exists(): continue
        r=cv2.imread(str(rp),cv2.IMREAD_GRAYSCALE)
        if r is None: continue
        # Multi-scale template matching bounded to reasonable sizes.
        for scale in (0.5,0.75,1.0,1.25,1.5):
            rr=cv2.resize(r,None,fx=scale,fy=scale,interpolation=cv2.INTER_AREA if scale<1 else cv2.INTER_CUBIC)
            if rr.shape[0]>h or rr.shape[1]>w or min(rr.shape[:2])<8: continue
            score=float(cv2.matchTemplate(gray,rr,cv2.TM_CCOEFF_NORMED).max())
            if score>=0.82:
                logo_matches.append({'reference':str(rp),'score':round(score,4)}); break
    # Mark heuristic: count compact dark connected components in upper/lower brand bands.
    blur=cv2.GaussianBlur(gray,(3,3),0)
    _,bw=cv2.threshold(blur,0,255,cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)
    n,labels,stats,cents=cv2.connectedComponentsWithStats(bw,8)
    compact=[]
    for i in range(1,n):
        x,y,ww,hh,area=map(int,stats[i])
        if area<max(20,w*h*0.00001) or area>w*h*0.04: continue
        aspect=ww/max(1,hh); fill=area/max(1,ww*hh)
        in_brand_band=(y<h*0.28 or y+hh>h*0.72)
        if in_brand_band and 0.15<=aspect<=8 and fill>=0.12 and ww>=8 and hh>=8:
            compact.append((x,y,ww,hh,area))
    # Seal heuristic: Hough circles on a downscaled image; conservative only when OCR also present nearby/global.
    small=gray
    maxdim=max(h,w)
    if maxdim>1200:
        sc=1200/maxdim; small=cv2.resize(gray,None,fx=sc,fy=sc,interpolation=cv2.INTER_AREA)
    circles=cv2.HoughCircles(cv2.medianBlur(small,5),cv2.HOUGH_GRADIENT,dp=1.2,minDist=40,param1=100,param2=45,minRadius=12,maxRadius=max(20,min(small.shape[:2])//5))
    contains_seal=bool(circles is not None and len(ocr)>0)
    # A generic compact mark alone is weak; two or more compact components clustered in a brand band is stronger.
    contains_logo=bool(logo_matches)
    if not contains_logo and len(compact)>=2:
        # If OCR has text, a compact mark + text in a branding band is treated as logo-like.
        contains_logo=bool(ocr)
    out={
      'schema':SCHEMA,'status':'PASS','scanner_actor_id':scanner_actor_id,'scanner_engine':'TESSERACT+OPENCV',
      'asset_path':str(p),'asset_sha256':sha256_file(p),'width':w,'height':h,
      'ocr_text':ocr,'contains_digits':contains_digits,'contains_logo':contains_logo,'contains_official_seal':contains_seal,
      'logo_reference_matches':logo_matches,'compact_mark_count':len(compact),
      'quality':{'luma_std':round(luma_std,4),'neighbor_corr':round(neighbor_corr,4),'neighbor_abs_diff':round(neighbor_abs_diff,4)},
      'blockers':blockers+quality_blockers,
    }
    if quality_blockers: out['status']='BLOCKED'
    out['scan_sha256']=hashlib.sha256(json.dumps({k:v for k,v in out.items() if k!='scan_sha256'},ensure_ascii=False,sort_keys=True,default=str).encode()).hexdigest()
    return out


def _extract_pdf_images(path, outdir):
    import fitz
    doc=fitz.open(path); rows=[]
    seen=set()
    for pno,page in enumerate(doc,1):
        for j,img in enumerate(page.get_images(full=True),1):
            xref=img[0]
            try: obj=doc.extract_image(xref)
            except Exception: continue
            data=obj.get('image'); ext=obj.get('ext','png')
            if not data: continue
            h=hashlib.sha256(data).hexdigest()
            f=outdir/f'pdf_p{pno:03d}_x{xref}_{h[:10]}.{ext}'
            if h not in seen: f.write_bytes(data); seen.add(h)
            rows.append({'path':str(f),'sha256':h,'source_path':str(path),'source_kind':'PDF_EMBEDDED_IMAGE','page':pno,'xref':xref})
    return rows

def _extract_zip_media(path,outdir):
    rows=[]; suffix=Path(path).suffix.lower()
    prefix='word/media/' if suffix=='.docx' else 'ppt/media/'
    try:
        z=zipfile.ZipFile(path)
    except Exception:return rows
    for name in z.namelist():
        if not name.startswith(prefix): continue
        data=z.read(name); h=hashlib.sha256(data).hexdigest(); ext=Path(name).suffix or '.bin'
        f=outdir/f'{suffix[1:]}_{h[:12]}{ext}'; f.write_bytes(data)
        rows.append({'path':str(f),'sha256':h,'source_path':str(path),'source_kind':'OOXML_EMBEDDED_MEDIA','member':name})
    return rows

def extract_visual_assets(source_paths,out_dir):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True); rows=[]
    for src in source_paths:
        p=Path(src)
        if not p.exists(): continue
        suf=p.suffix.lower()
        if suf=='.pdf': rows.extend(_extract_pdf_images(p,out))
        elif suf in {'.docx','.pptx'}: rows.extend(_extract_zip_media(p,out))
        elif suf in {'.png','.jpg','.jpeg','.webp','.bmp','.tif','.tiff'}:
            h=sha256_file(p); dst=out/(h[:12]+suf); dst.write_bytes(p.read_bytes()); rows.append({'path':str(dst),'sha256':h,'source_path':str(p),'source_kind':'SOURCE_IMAGE'})
    return rows

def _norm(s):
    s=re.sub(r'[^\w\u0600-\u06ff]+',' ',str(s).lower()).strip()
    return ' '.join(s.split())

def resolve_client_logo(source_paths, client_identity_terms, out_dir, *, scanner_actor_id='RASHAD-SOURCE-ASSET-RESOLVER-V1'):
    """Extract and verify a client-logo candidate from supplied authoritative source bytes.

    Never invents or replaces a missing logo with text. If no source-bound identity match is found,
    production must block with CLIENT_LOGO_NOT_VERIFIED.
    """
    assets=extract_visual_assets(source_paths,out_dir); terms=[_norm(x) for x in client_identity_terms if _norm(x)]
    counts=Counter(x['sha256'] for x in assets); candidates=[]
    for a in assets:
        scan=scan_image(a['path'],scanner_actor_id=scanner_actor_id)
        text=_norm(scan.get('ocr_text','')); score=0; matched=[]
        for t in terms:
            # token overlap permits bilingual lockups and acronyms supplied as explicit terms.
            toks=[x for x in t.split() if len(x)>=2]
            if t and (t in text or (toks and sum(x in text for x in toks)>=max(1,min(2,len(toks))))):
                score+=60; matched.append(t)
        score+=min(20,(counts[a['sha256']]-1)*5)
        try:
            w=int(scan.get('width',0)); h=int(scan.get('height',0)); aspect=w/max(1,h)
            if 0.6<=aspect<=8: score+=8
            if w>=60 and h>=30: score+=5
        except Exception: pass
        c={**a,'scan':scan,'identity_matches':matched,'score':score,'occurrences':counts[a['sha256']]}; candidates.append(c)
    # Same hash can appear multiple times; keep best record per hash.
    best_by={}
    for c in candidates:
        h=c['sha256']
        if h not in best_by or c['score']>best_by[h]['score']: best_by[h]=c
    ranked=sorted(best_by.values(),key=lambda x:(x['score'],x['occurrences']),reverse=True)
    selected=next((x for x in ranked if x['identity_matches'] and x['scan'].get('status')=='PASS'),None)
    if not selected:
        return {'status':'BLOCKED','reason':'CLIENT_LOGO_NOT_VERIFIED','source_files':[str(x) for x in source_paths],'candidate_count':len(ranked),'candidates':ranked[:20]}
    # Copy exact verified bytes to canonical output name; preserve suffix.
    src=Path(selected['path']); dest=Path(out_dir)/('VERIFIED_CLIENT_LOGO'+src.suffix.lower()); dest.write_bytes(src.read_bytes())
    return {'status':'PASS','client_logo_path':str(dest),'client_logo_sha256':sha256_file(dest),'selected_source':selected,'candidate_count':len(ranked),'rule':'Client logo must be extracted from supplied authoritative source bytes; no placeholder, redraw or text substitute is permitted.'}
