from __future__ import annotations
from pathlib import Path
import html,json,hashlib,base64,mimetypes,re

_ARABIC_INDIC_TRANS = str.maketrans('0123456789','٠١٢٣٤٥٦٧٨٩')

def _px_bbox(b,w=1920,h=1080): return [round(float(b['x'])*w),round(float(b['y'])*h),round(float(b['w'])*w),round(float(b['h'])*h)]
def _visible_text(x, *, arabic=False): return str(x or '').translate(_ARABIC_INDIC_TRANS) if arabic else str(x or '')
def _esc(x, *, arabic=False): return html.escape(_visible_text(x,arabic=arabic),quote=True)
def _rich_visible(x, *, arabic=False):
    text=_visible_text(x,arabic=arabic)
    if not arabic: return html.escape(text)
    parts=[]; pos=0
    for m in re.finditer(r'[٠-٩]+(?:[./٪%\-–—][٠-٩]+)*',text):
        parts.append(html.escape(text[pos:m.start()])); parts.append(f'<bdi class="ltr-island" dir="ltr" data-directionality="ISOLATED">{html.escape(m.group(0))}</bdi>'); pos=m.end()
    parts.append(html.escape(text[pos:])); return ''.join(parts)
def _asset_uri(path):
    p=Path(path); mime=mimetypes.guess_type(p.name)[0] or 'application/octet-stream'; return f"data:{mime};base64,{base64.b64encode(p.read_bytes()).decode()}"
def _hash_obj(o): return hashlib.sha256(json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def _numeric_list(vals):
    if not isinstance(vals,(list,tuple)) or not vals: return None
    out=[]
    for v in vals:
        try: out.append(float(v))
        except Exception: return None
    return out

def compose_html(spec,content_pack,semantic_graph,out_path,image_asset=None,brand_logo=None,client_logo=None):
    """Build the authoritative, instrumented semantic HTML master.

    v7.3.1 invariants:
    - the HTML is hash-bound to the exact PageCompositionSpec;
    - quantitative charts cannot invent values;
    - analytical pages cannot invent an evidence/source label;
    - physical grammar varies by dominant form rather than reducing every form to cards;
    - typography/material/focal/mass/negative-space intent are consumed or embedded for parity QA;
    - connectors are resolved only after document.fonts.ready from measured boxes.
    """
    out=Path(out_path); out.parent.mkdir(parents=True,exist_ok=True)
    pal=spec['palette_role_map']; typo=spec.get('typographic_hierarchy') or {}; font=typo.get('font_family','Montserrat')
    lang='ar' if (spec.get('eye_path') or {}).get('direction')=='RTL' else 'en'; direction='rtl' if lang=='ar' else 'ltr'; arvis=(lang=='ar' and typo.get('numeral_system')=='ARABIC_INDIC')
    family=str(spec.get('page_family') or 'ANALYTICAL')
    title=_rich_visible(content_pack.get('title') or content_pack.get('management_question') or '',arabic=arvis)
    thesis=_rich_visible(content_pack.get('thesis') or content_pack.get('answer_first_thesis') or content_pack.get('answer') or '',arabic=arvis)
    raw_proofs=content_pack.get('proof_points') or content_pack.get('evidence_points') or content_pack.get('bullets') or []
    if not isinstance(raw_proofs,list): raw_proofs=[str(raw_proofs)]
    proofs=[_rich_visible(x.get('text') if isinstance(x,dict) else x,arabic=arvis) for x in raw_proofs]
    if not proofs and content_pack.get('executive_implication'): proofs=[_rich_visible(content_pack.get('executive_implication'),arabic=arvis)]
    source_id=str(content_pack.get('source_id') or content_pack.get('evidence_id') or content_pack.get('source_note') or '').strip()
    if family not in {'COVER','SECTION_OPENER'} and not source_id:
        return {'status':'BLOCKED','reason':'CLIENT_VISIBLE_SOURCE_ID_REQUIRED'}
    if len(source_id)>96: return {'status':'BLOCKED','reason':'CLIENT_VISIBLE_SOURCE_ID_TOO_LONG'}
    implication=_rich_visible(content_pack.get('executive_implication') or content_pack.get('implication') or '',arabic=arvis) if (content_pack.get('executive_implication') or content_pack.get('implication')) else (proofs[-1] if proofs else thesis)
    db=_px_bbox(spec['dominant_bbox']); zones={z['id']:_px_bbox(z['bbox']) for z in spec['content_zones']}
    strategy=spec['communication_strategy']; form=spec['dominant_form']; topo=spec.get('topology') or {}; nodes=topo.get('nodes') or []
    relation_labels_ar={'ENABLES':'يمكّن','DEPENDS_ON':'يعتمد على','FLOWS_TO':'ينتقل إلى','CONTROLS':'يضبط','MEASURES':'يقيس','EVIDENCES':'يثبت','RISKS':'يهدد','PRIORITIZES':'يرتّب','OWNS':'يملك','APPROVES':'يعتمد','FEEDS_BACK':'يغذّي التحسين','THRESHOLD_FOR':'شرط لـ','MAPS_TO':'يرتبط بـ','BLOCKS':'يمنع'}
    relation_labels_en={'ENABLES':'enables','DEPENDS_ON':'depends on','FLOWS_TO':'flows to','CONTROLS':'controls','MEASURES':'measures','EVIDENCES':'evidences','RISKS':'risks','PRIORITIZES':'prioritizes','OWNS':'owns','APPROVES':'approves','FEEDS_BACK':'feeds back','THRESHOLD_FOR':'threshold for','MAPS_TO':'maps to','BLOCKS':'blocks'}
    edge_labels=relation_labels_ar if arvis else relation_labels_en
    if not nodes: nodes=[{'id':f'N{i+1}','label':re.sub('<[^>]+>','',p),'type':'PROOF'} for i,p in enumerate(proofs)]
    if len(nodes)>int((spec.get('acceptance') or {}).get('max_topology_nodes_per_page',8)):
        return {'status':'BLOCKED','reason':'COMPOSER_CONTENT_CAPACITY_EXCEEDED_REQUIRES_PAGE_SPLIT','node_count':len(nodes)}
    def node_markup(n,i):
        nid=_esc(n['id']); raw_type=str(n.get('type','CLAIM')).upper(); ntype=_esc(raw_type); label=_rich_visible(n.get('label',n['id']),arabic=arvis)
        if n.get('palette_role'):
            semantic_role=str(n.get('palette_role')).upper()
        elif 'RISK' in raw_type:
            semantic_role='RISK'
        elif any(x in raw_type for x in ('METRIC','KPI','NUMBER')):
            semantic_role='METRIC'
        elif any(x in raw_type for x in ('EVIDENCE','PROOF','SOURCE')):
            semantic_role='EVIDENCE'
        else:
            semantic_role='DEFAULT'
        meta=[]
        for k,cls in [('metric','metric'),('owner','owner'),('status','status')]:
            if n.get(k) not in (None,''): meta.append(f'<span class="node-{cls}" data-node-meta="{cls}">{_rich_visible(n.get(k),arabic=arvis)}</span>')
        return f'<div class="node node-rank-{i+1}" data-node-id="{nid}" data-node-type="{ntype}" data-palette-role="{_esc(semantic_role)}" data-content-slot="evidence"><span class="semantic-icon" data-icon-role="{ntype}" aria-hidden="true"></span><span class="step-badge" data-decoration-id="STEP-{i+1}" data-owner-id="{nid}">{_rich_visible(i+1,arabic=arvis)}</span><span class="node-label" data-label-for="{nid}">{label}</span>{"".join(meta)}</div>'
    node_html=''.join(node_markup(n,i) for i,n in enumerate(nodes))
    img=f'<img class="hero-plate" data-artifact-type="IMAGE_LED" data-asset="PRIMARY_VISUAL" data-asset-id="PRIMARY_VISUAL" src="{html.escape(_asset_uri(image_asset))}" alt="" />' if image_asset else ''
    logo=f'<img class="brand-logo" data-asset="RUBIX" data-asset-id="RUBIX" src="{html.escape(_asset_uri(brand_logo))}" alt="Rubix" />' if brand_logo else ''
    client=f'<img class="client-logo" data-asset="CLIENT" data-asset-id="CLIENT" src="{html.escape(_asset_uri(client_logo))}" alt="Client" />' if client_logo else ''
    support=''.join(f'<li data-content-slot="evidence" data-source="{_esc(source_id)}">{p}</li>' for p in proofs)
    track='<div class="form-track" data-decoration-id="FORM-TRACK"></div>' if form in {'LANE','SPINE','LADDER'} else ''
    structure=f'<div class="dominant-inner form-{form.lower()}" data-artifact-type="{_esc(strategy)}">{track}{node_html}</div>'
    if form=='CHART':
        vals=_numeric_list(content_pack.get('chart_values'))
        refs=content_pack.get('chart_evidence_refs') or []
        if not vals: return {'status':'BLOCKED','reason':'CHART_VALUES_REQUIRE_BOUND_EVIDENCE'}
        if not isinstance(refs,list) or len(refs)<len(vals): return {'status':'BLOCKED','reason':'CHART_VALUE_EVIDENCE_BINDING_REQUIRED'}
        cats=content_pack.get('chart_categories') or []; ctitle=str(content_pack.get('chart_title') or '').strip(); unit=str(content_pack.get('chart_unit') or '').strip()
        if not ctitle or not isinstance(cats,list) or len(cats)<len(vals): return {'status':'BLOCKED','reason':'CHART_FURNITURE_REQUIRES_TITLE_AND_CATEGORIES'}
        vmax=max(max(vals),1.0)
        bars=''.join(f'<div class="bar-wrap" data-evidence-ref="{_esc(refs[i])}" data-chart-value="{_esc(vals[i])}" data-chart-index="{i+1}"><div class="bar-value" data-source="{_esc(refs[i])}">{_rich_visible(v,arabic=arvis)}{(" "+_esc(unit)) if unit else ""}</div><div class="bar" style="height:{max(6,min(100,float(v)/vmax*100))}%"></div><span class="bar-category" data-source="{_esc(refs[i])}">{_rich_visible(cats[i],arabic=arvis)}</span></div>' for i,v in enumerate(vals))
        structure=f'<div class="chart-shell" data-artifact-type="CHART_LED"><div class="chart-heading">{_rich_visible(ctitle,arabic=arvis)}</div><div class="chart-grid" data-decoration-id="CHART-GRID"><i></i><i></i><i></i><i></i></div><div class="chart">{bars}</div><div class="chart-baseline" data-decoration-id="CHART-BASELINE"></div></div>'
    elif form=='TABLE':
        if not proofs: return {'status':'BLOCKED','reason':'TABLE_EVIDENCE_ROWS_REQUIRED'}
        structure='<table data-table-role="EVIDENCE" data-artifact-type="TABLE_LED"><tbody>'+''.join(f'<tr><td>{_rich_visible(i+1,arabic=arvis)}</td><td>{p}</td></tr>' for i,p in enumerate(proofs))+'</tbody></table>'
    elif form=='HERO_IMAGE':
        if not img: return {'status':'BLOCKED','reason':'IMAGE_LED_REQUIRES_ADMITTED_IMAGE_PLATE'}
        structure=img
    elif form=='STATEMENT_BLOCK': structure=f'<div class="hero-statement" data-artifact-type="STATEMENT_BLOCK">{thesis or title}</div><div class="proof-strip">{support}</div>'
    levels=typo.get('levels') or []
    def px(role,default):
        for x in levels:
            if x.get('role')==role:
                try:return int(x.get('px'))
                except Exception:return default
        return default
    title_px=px('TITLE',46); thesis_px=px('THESIS',30); body_px=px('BODY',21); source_px=px('SOURCE',13)
    mat=spec.get('material_plan') or {}; radius=int(mat.get('corner_radius_px',12) or 12); line=int(mat.get('line_weight_px',2) or 2)
    neg=''.join(f'<div class="negative-space-guard" data-negative-space-type="{_esc(z.get("type"))}" data-negative-space-bbox="{_esc(json.dumps(z.get("bbox") or {},sort_keys=True))}"></div>' for z in (spec.get('negative_space_zones') or []))
    mass_hash=_hash_obj(spec.get('mass_plan') or [])
    scene=(spec.get('scene_metaphor') or {}).get('concept') or ''
    focal=(spec.get('focal_anchor') or {}).get('zone') or ''
    support_box=zones.get('SUPPORT',[90,300,400,500]); implication_box=zones.get('IMPLICATION',[345,902,1230,70])
    spec_hash=str(spec.get('spec_sha256') or '')
    css="""
*{box-sizing:border-box} html,body{margin:0;width:1920px;height:1080px;overflow:hidden;background:__CANVAS__;font-family:"__FONT__",sans-serif;color:__INK__}
.page{position:relative;width:1920px;height:1080px;overflow:hidden;background:__CANVAS__;direction:__DIRECTION__}
.header{position:absolute;left:__HEADER_X__px;top:__HEADER_Y__px;width:__HEADER_W__px;height:__HEADER_H__px;z-index:30}.eyebrow{font-size:16px;color:__ACCENT__;font-weight:700}h1{font-size:__TITLE_PX__px;line-height:1.08;margin:6px 0 0;font-weight:750;max-width:1420px}.thesis{font-size:__THESIS_PX__px;line-height:1.24;color:__MUTED__;margin-top:10px;max-width:1350px}
.dominant{position:absolute;left:__DBX__px;top:__DBY__px;width:__DBW__px;height:__DBH__px;z-index:20;background:__DOMBG__;border:2px solid #E6E2E4;border-radius:__RADIUS__px;overflow:hidden;display:flex;align-items:stretch;justify-content:stretch}.dominant.hero-underlay{border:0;border-radius:0}.dominant-inner{width:100%;height:100%;padding:34px;gap:20px;position:relative}.node{font-size:__BODY_PX__px;line-height:1.22;position:relative;z-index:23;color:__INK__}.node span{display:block}.node[data-palette-role="RISK"]{border-color:__ACCENT__!important}.node[data-palette-role="EVIDENCE"] .semantic-icon{background:__ACCENT2__}.node[data-palette-role="METRIC"] .semantic-icon{background:__ACCENT__}.draft-mark{font-size:14px;font-weight:800;color:__ACCENT__;letter-spacing:.02em;white-space:nowrap}.source-label{overflow:hidden;text-overflow:clip;white-space:nowrap}.semantic-icon{width:18px;height:18px;border-radius:4px;background:__ACCENT2__;margin-bottom:8px}.node-metric{font-size:18px;font-weight:750;color:__ACCENT__;margin-top:8px}.node-owner,.node-status{font-size:14px;color:__MUTED__;margin-top:4px}.step-badge{font-size:14px;color:__ACCENT__;font-weight:800;margin-bottom:4px}
.form-stack{display:flex;flex-direction:column;justify-content:center;gap:18px;padding:28px 44px}.form-stack .node{flex:1;min-height:62px;border-inline-start:8px solid __ACCENT2__;border-bottom:2px solid #E6E2E4;padding:14px 24px;background:#E2EBF5;border-radius:0;display:flex;align-items:center}.form-stack .node:nth-child(even){background:#DAEAEC}.form-stack .node-rank-1{border-inline-start-color:__ACCENT__;font-weight:750;background:#F1DEE8}
.form-spine{display:flex;flex-direction:column;justify-content:space-around;padding:26px 44px 26px 72px}.form-spine .form-track{position:absolute;top:9%;bottom:9%;inset-inline-start:42px;width:4px;background:__ACCENT__;z-index:21}.form-spine .node{min-height:78px;padding:16px 22px;background:#F0F4FA;border:0;border-block-end:4px solid __ACCENT2__;border-inline-start:6px solid __ACCENT2__;border-radius:0;display:flex;align-items:center}.form-spine .node-rank-1{background:#F7EEF3;border-inline-start-color:__ACCENT__;border-block-end-color:__ACCENT__;font-weight:750}.form-spine .node>.step-badge{position:absolute;inset-inline-start:-43px;top:50%;width:24px;height:24px;border:4px solid __ACCENT__;background:__CANVAS__;border-radius:50%;transform:translateY(-50%);font-size:14px;color:__ACCENT__;display:flex;align-items:center;justify-content:center}.form-spine .semantic-icon{display:none}
.form-lane{display:flex;align-items:center;justify-content:space-between;padding:42px 30px;gap:28px}.form-lane .form-track{position:absolute;left:6%;right:6%;top:50%;height:8px;background:__ACCENT2__;z-index:21}.form-lane .node{flex:1;text-align:center;background:#E2EBF5;border:0;border-top:8px solid __ACCENT2__;border-inline-start:4px solid __ACCENT2__;padding:110px 12px 16px;min-height:210px}.form-lane .node:nth-child(even){background:#DAEAEC}.form-lane .node-rank-1{border-top-color:__ACCENT__;border-inline-start-color:__ACCENT__;background:#F1DEE8;font-weight:750}.form-lane .step-badge{position:absolute;top:18px;left:50%;transform:translateX(-50%);width:44px;height:44px;border-radius:50%;background:__ACCENT__;box-shadow:0 0 0 6px __SURFACE__;z-index:24;color:#FFFFFF;display:flex;align-items:center;justify-content:center;font-weight:750}.form-lane .node-label{margin-top:10px}.form-lane .semantic-icon{display:none}
.form-hub{display:grid;grid-template-columns:1fr 1.35fr 1fr;grid-template-rows:1fr 1fr;gap:22px;align-items:center;padding:34px}.form-hub .node{padding:18px;border:0;border-bottom:4px solid __ACCENT2__;border-radius:0;background:transparent;text-align:center}.form-hub .node-rank-1{grid-column:2;grid-row:1 / span 2;align-self:center;min-height:150px;display:flex;align-items:center;justify-content:center;background:__ACCENT__;color:white;border:2px solid __ACCENT__;border-radius:999px;font-weight:750;box-shadow:0 0 0 12px #F3E5ED}.form-hub .node-rank-1 .step-badge{color:#FFFFFF}.form-field .node-rank-1 .step-badge{color:#FFFFFF}
.form-matrix{display:grid;grid-template-columns:repeat(2,1fr);grid-auto-rows:1fr;gap:24px;background:__ACCENT2__;padding:22px}.form-matrix .node{padding:28px;background:#E2EBF5;border:3px solid #203B70;border-top:8px solid __ACCENT2__;border-inline-start:4px solid __ACCENT2__;border-radius:0;display:flex;align-items:center}.form-matrix .node:nth-child(2){background:#DAEAEC}.form-matrix .node:nth-child(3){background:#F1DEE8}.form-matrix .node:nth-child(4){background:#ECDFEC}.form-matrix .node-rank-1{background:#DEE2EA;border-top-color:__ACCENT__;border-inline-start:8px solid __ACCENT__;font-weight:750}
.form-field{display:flex;flex-wrap:wrap;align-content:center;justify-content:center;gap:22px;padding:42px}.form-field .node{flex:0 1 26%;min-height:92px;padding:16px 20px;border:1px solid #D8D4D7;border-inline-start:6px solid __ACCENT2__;border-radius:4px;background:#F4F7FA;text-align:center}.form-field .node:nth-child(2){flex-basis:34%;background:#EAF2F4}.form-field .node:nth-child(3){flex-basis:22%;background:#F5ECF1}.form-field .node:nth-child(4){flex-basis:30%;background:#EEF1F6}.form-field .node-rank-1{flex-basis:42%;min-height:118px;background:__ACCENT__;color:white;border-color:__ACCENT__;border-radius:999px;font-weight:750}
.form-ladder{display:flex;flex-direction:column-reverse;justify-content:center;gap:12px;padding:28px 55px;position:relative}.form-ladder .form-track{position:absolute;inset-inline-end:28px;top:12%;bottom:12%;width:6px;background:__ACCENT__;opacity:.82;z-index:21}.form-ladder .node{min-height:80px;padding:16px 22px;background:#F0F4FA;border-inline-start:8px solid __ACCENT2__;border-block-end:3px solid #D0DADF;border-radius:4px;display:flex;align-items:center}.form-ladder .node:nth-child(2){margin-inline-start:8%}.form-ladder .node:nth-child(3){margin-inline-start:16%}.form-ladder .node:nth-child(4){margin-inline-start:24%}.form-ladder .node:nth-child(5){margin-inline-start:32%}.form-ladder .node-rank-1{border-inline-start-color:__ACCENT__;font-weight:750;background:#F7EEF3}
.form-ring,.form-tree,.form-funnel{display:flex;flex-wrap:wrap;align-items:center;justify-content:center;gap:24px;padding:40px}.form-ring .node,.form-tree .node,.form-funnel .node{padding:16px 22px;border-bottom:4px solid __ACCENT__;background:transparent}
.support{position:absolute;left:__SUP_X__px;top:__SUP_Y__px;width:__SUP_W__px;height:__SUP_H__px;z-index:22;padding:22px;border-inline-start:5px solid __ACCENT2__;background:#F5F8FA;border-radius:6px}.support ul{margin:0;padding:0 24px 0 0}.support li{font-size:__BODY_PX__px;line-height:1.35;margin-bottom:16px}.support-chart{padding:10px 18px;border-inline-start:0;border-top:3px solid __ACCENT2__;display:flex;align-items:center;background:#EEF4F5}.support-chart ul{width:100%;height:100%;padding:0;margin:0;display:grid;grid-template-columns:repeat(auto-fit,minmax(0,1fr));gap:16px;align-items:center;list-style:none}.support-chart li{margin:0;padding:0 12px;font-size:18px;line-height:1.25;border-inline-start:2px solid #D0DADF}.support-image{padding:5px 16px;border-inline-start:0;border-top:2px solid __ACCENT2__;background:#F5F8FA;display:flex;align-items:center;justify-content:center;text-align:center;font-size:16px;line-height:1.2;overflow:hidden}.hero-statement{font-size:__HERO_PX__px;line-height:1.12;font-weight:780;align-self:center;padding:50px;max-width:84%}.proof-strip{font-size:__BODY_PX__px;position:absolute;bottom:28px;inset-inline:42px}.implication{position:absolute;left:__IMP_X__px;top:__IMP_Y__px;width:__IMP_W__px;height:__IMP_H__px;padding:12px 22px;border-top:__IMPLINE__px solid __ACCENT__;font-size:18px;line-height:1.25;text-align:center;background:#F7EEF3;z-index:24;font-weight:700;overflow:hidden}
.chart-shell{position:relative;width:100%;height:100%;padding:24px 30px 20px}.chart-heading{font-size:26px;line-height:1.15;font-weight:750;height:44px}.chart-grid{position:absolute;left:50px;right:40px;top:90px;bottom:80px;display:flex;flex-direction:column;justify-content:space-between}.chart-grid i{height:1px;background:#D7DDE5;display:block}.chart-baseline{position:absolute;left:50px;right:40px;bottom:96px;height:2px;background:__INK__}.bar-value{font-size:14px;font-weight:700;color:__INK__}.bar-category{font-size:14px;text-align:center;min-height:36px}table{width:100%;height:100%;border-collapse:collapse;font-size:__BODY_PX__px;background:__CANVAS__}td{border-bottom:1px solid #E6E2E4;padding:14px}td:first-child{color:__ACCENT__;font-weight:700;width:64px}.chart{position:absolute;left:50px;right:40px;top:90px;bottom:60px;display:flex;align-items:flex-end;gap:24px;padding:0}.bar-wrap{height:100%;flex:1;display:flex;flex-direction:column;justify-content:flex-end;align-items:center;gap:12px}.bar{width:70%;background:__ACCENT__;border-radius:8px 8px 0 0;min-height:6%}.bar-wrap span{font-weight:750;font-size:__BODY_PX__px}.hero-plate{width:100%;height:100%;object-fit:cover}.cobrand{position:absolute;left:58px;top:40px;width:300px;height:56px;display:flex;direction:ltr;align-items:center;gap:18px;z-index:40}.brand-logo{width:150px;height:52px;object-fit:contain;object-position:left center}.client-logo{width:120px;height:52px;object-fit:contain;object-position:left center;border-left:1px solid #D9D5D7;padding-left:16px}.footer{position:absolute;left:58px;right:58px;bottom:38px;font-size:__SOURCE_PX__px;color:__MUTED__;z-index:30;display:flex;align-items:center;justify-content:space-between;gap:24px}.negative-space-guard{display:none}#edge-layer{position:absolute;left:0;top:0;width:1920px;height:1080px;z-index:22;pointer-events:none;overflow:visible}#edge-layer path[data-edge-id]{stroke:__ACCENT__;stroke-width:3;fill:none;opacity:.9}
"""
    repl={'__CANVAS__':pal['canvas'],'__FONT__':font,'__INK__':pal['ink'],'__DIRECTION__':direction,'__ACCENT__':pal['accent_primary'],'__ACCENT2__':pal['accent_secondary'],'__MUTED__':pal['muted'],'__SURFACE__':pal.get('surface','#FAF9FA'),'__HEADER_X__':str(zones['HEADER'][0]),'__HEADER_Y__':str(zones['HEADER'][1]),'__HEADER_W__':str(zones['HEADER'][2]),'__HEADER_H__':str(zones['HEADER'][3]),'__TITLE_PX__':str(title_px),'__THESIS_PX__':str(thesis_px),'__BODY_PX__':str(body_px),'__SOURCE_PX__':str(source_px),'__HERO_PX__':str(max(40,title_px)),'__DBX__':str(db[0]),'__DBY__':str(db[1]),'__DBW__':str(db[2]),'__DBH__':str(db[3]),'__DOMBG__':('transparent' if form=='HERO_IMAGE' else pal.get('surface','#FAF9FA')),'__RADIUS__':str(radius),'__LINE__':str(line),'__IMPLINE__':str(line+1),'__SUP_X__':str(support_box[0]),'__SUP_Y__':str(support_box[1]),'__SUP_W__':str(support_box[2]),'__SUP_H__':str(support_box[3]),'__IMP_X__':str(implication_box[0]),'__IMP_Y__':str(implication_box[1]),'__IMP_W__':str(implication_box[2]),'__IMP_H__':str(implication_box[3])}
    for k,v in repl.items(): css=css.replace(k,str(v))
    edges_json=json.dumps(topo.get('edges') or [],ensure_ascii=False)
    classification=str(content_pack.get('output_classification') or content_pack.get('classification') or 'USER_VISIBLE_ARTIFACT_DRAFT')
    draft_required=classification=='USER_VISIBLE_ARTIFACT_DRAFT'
    draft_markup='<span class="draft-mark" data-draft-mark="VISIBLE">مسودة — غير معتمدة</span>' if draft_required and arvis else ('<span class="draft-mark" data-draft-mark="VISIBLE">DRAFT — NOT APPROVED</span>' if draft_required else '')
    if form in {'CHART','TABLE'}:
        support_class='support support-chart'
        support_markup=(f'<div class="{support_class}" data-region-id="SUPPORT"><ul>{support}</ul></div>' if 'SUPPORT' in zones else '')
    elif form=='HERO_IMAGE':
        # The visual plate is not evidence by itself. Bind one concise, visible evidence
        # caption to the real source so G30/G31 can verify the analytical image page.
        evidence_caption=proofs[0] if proofs else ''
        support_markup=(f'<div class="support support-image" data-region-id="SUPPORT" data-content-slot="evidence" data-source="{_esc(source_id)}">{evidence_caption}</div>' if 'SUPPORT' in zones and evidence_caption else '')
    else:
        support_class='support'
        support_markup=(f'<div class="{support_class}" data-region-id="SUPPORT"><ul>{support}</ul></div>' if 'SUPPORT' in zones else '')
    implication_markup=(f'<div class="implication" data-region-id="IMPLICATION" data-content-slot="implication">{implication}</div>' if 'IMPLICATION' in zones else '')
    dominant_class='dominant hero-underlay' if form=='HERO_IMAGE' else 'dominant'
    dominant_overlap=' data-overlap-policy="ALLOW"' if form=='HERO_IMAGE' else ''
    page_attrs=f'data-page-mode="ARTIFACT_LED" data-page-family="{_esc(family)}" data-page-id="{_esc(spec.get("page_id") or "PAGE")}" data-grammar-id="{_esc((spec.get("reference_grammar_ids") or ["NONE"])[0])}" data-composition-spec-sha256="{_esc(spec_hash)}" data-mass-plan-sha256="{mass_hash}" data-focal-zone="{_esc(focal)}" data-scene-concept="{_esc(scene)}"'
    html_txt='<!doctype html><html lang="'+lang+'" dir="'+direction+'"><head><meta charset="utf-8"><style>'+css+'</style></head><body><div class="page" '+page_attrs+'>'+neg+f'<div class="cobrand" data-region-id="COBRAND">{logo}{client}</div><div class="header" data-header-role="TITLE"><div class="eyebrow">{_rich_visible(content_pack.get("eyebrow") or "",arabic=arvis)}</div><h1 data-content-slot="question">{title}</h1><div class="thesis" data-content-slot="thesis">{thesis}</div></div><svg id="edge-layer"><defs><marker id="rashad-arrow" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto"><path d="M0,0 L0,6 L9,3 z" fill="{pal["accent_primary"]}" stroke="none"/></marker></defs></svg><div class="{dominant_class}" data-region-id="DOMINANT"{dominant_overlap} data-area-budget="{spec["dominant_mass_target"]}">{structure}</div>{support_markup}{implication_markup}<div class="footer" data-header-role="FOOTER" data-content-slot="source" data-source="{_esc(source_id)}" data-directionality="ISOLATED">{draft_markup}<span class="source-label" data-content-slot="source" data-source="{_esc(source_id)}" data-directionality="ISOLATED">{_esc(content_pack.get("footer") or content_pack.get("source_note") or source_id)}</span></div></div>'
    js="""<script>async function layout(){await document.fonts.ready;const svg=document.getElementById('edge-layer');svg.querySelectorAll('path[data-edge-id]').forEach(x=>x.remove());const nodes=[...document.querySelectorAll('[data-node-id]')];nodes.forEach((n,i)=>n.dataset.step=String(i+1));const by=Object.fromEntries(nodes.map(n=>[n.dataset.nodeId,n]));const edges=__EDGES__;const dom=document.querySelector('.dominant').getBoundingClientRect();const textEls=[...document.querySelectorAll('.header h1,.thesis,.support li,.implication,.footer,[data-node-id] span')];function anchors(r){const cx=r.left+r.width/2,cy=r.top+r.height/2;return[{side:'L',x:r.left,y:cy},{side:'R',x:r.right,y:cy},{side:'T',x:cx,y:r.top},{side:'B',x:cx,y:r.bottom}]}function segHit(a,b,r,pad=8){const x0=r.left-pad,x1=r.right+pad,y0=r.top-pad,y1=r.bottom+pad;if(Math.abs(a.x-b.x)<.5){const x=a.x,lo=Math.min(a.y,b.y),hi=Math.max(a.y,b.y);return x>=x0&&x<=x1&&hi>=y0&&lo<=y1}if(Math.abs(a.y-b.y)<.5){const y=a.y,lo=Math.min(a.x,b.x),hi=Math.max(a.x,b.x);return y>=y0&&y<=y1&&hi>=x0&&lo<=x1}return false}function compact(pts){return pts.filter((q,i)=>i===0||Math.abs(q.x-pts[i-1].x)>.5||Math.abs(q.y-pts[i-1].y)>.5)}function pathScore(pts,s,t){let hits=0,textHits=0,len=0;for(let i=0;i<pts.length-1;i++){len+=Math.hypot(pts[i+1].x-pts[i].x,pts[i+1].y-pts[i].y);for(const n of nodes){if(n===s||n===t)continue;if(segHit(pts[i],pts[i+1],n.getBoundingClientRect()))hits++}for(const tx of textEls){const endpointChild=s.contains(tx)||t.contains(tx);const endpointBadge=endpointChild&&tx.classList&&tx.classList.contains('step-badge');if(endpointChild&&!endpointBadge)continue;if(segHit(pts[i],pts[i+1],tx.getBoundingClientRect(),2))textHits++}}const sr=s.getBoundingClientRect(),tr=t.getBoundingClientRect(),flow={x:(tr.left+tr.width/2)-(sr.left+sr.width/2),y:(tr.top+tr.height/2)-(sr.top+sr.height/2)};let j=pts.length-1;while(j>0&&Math.abs(pts[j].x-pts[j-1].x)<.5&&Math.abs(pts[j].y-pts[j-1].y)<.5)j--;const tan={x:pts[j].x-pts[j-1].x,y:pts[j].y-pts[j-1].y};const arrowPenalty=(flow.x*tan.x+flow.y*tan.y)<0?500000:0;return arrowPenalty+hits*100000+textHits*20000+Math.max(0,pts.length-2)*35+len}function pathD(pts){return 'M '+compact(pts).map(q=>`${q.x} ${q.y}`).join(' L ')}for(const e of edges){let s=by[e.source],t=by[e.target];if(!s||!t)continue;let a=s.getBoundingClientRect(),b=t.getBoundingClientRect(),p=document.createElementNS('http://www.w3.org/2000/svg','path');const corridors=[dom.top-18,dom.bottom+18],vertical=[dom.left-18,dom.right+18];let candidates=[];const acx=a.left+a.width/2,acy=a.top+a.height/2,bcx=b.left+b.width/2,bcy=b.top+b.height/2;if(a.right<=b.left){const gx=(a.right+b.left)/2;candidates.push([{x:a.right,y:acy},{x:gx,y:acy},{x:gx,y:bcy},{x:b.left,y:bcy}])}else if(b.right<=a.left){const gx=(b.right+a.left)/2;candidates.push([{x:a.left,y:acy},{x:gx,y:acy},{x:gx,y:bcy},{x:b.right,y:bcy}])}if(a.bottom<=b.top){const gy=(a.bottom+b.top)/2;candidates.push([{x:acx,y:a.bottom},{x:acx,y:gy},{x:bcx,y:gy},{x:bcx,y:b.top}])}else if(b.bottom<=a.top){const gy=(b.bottom+a.top)/2;candidates.push([{x:acx,y:a.top},{x:acx,y:gy},{x:bcx,y:gy},{x:bcx,y:b.bottom}])}for(const p0 of anchors(a))for(const p1 of anchors(b)){if(Math.abs(p0.x-p1.x)<.5||Math.abs(p0.y-p1.y)<.5)candidates.push([p0,p1]);candidates.push([p0,{x:p1.x,y:p0.y},p1],[p0,{x:p0.x,y:p1.y},p1]);for(const y of corridors)candidates.push([p0,{x:p0.x,y},{x:p1.x,y},p1]);for(const x of vertical)candidates.push([p0,{x,y:p0.y},{x,y:p1.y},p1]);for(const x of vertical)for(const y of corridors){candidates.push([p0,{x,y:p0.y},{x,y},{x:p1.x,y},p1]);candidates.push([p0,{x:p0.x,y},{x,y},{x,y:p1.y},p1])}}candidates.sort((u,v)=>pathScore(u,s,t)-pathScore(v,s,t));const d=pathD(candidates[0]);p.setAttribute('d',d);p.setAttribute('marker-end','url(#rashad-arrow)');p.dataset.edgeId=e.id;p.dataset.source=e.source;p.dataset.target=e.target;p.dataset.directionality='DIRECTED';p.dataset.labelOwner=e.label_owner||'EDGE';svg.appendChild(p)}document.documentElement.dataset.rashadLayoutReady='1'}layout();</script></body></html>""".replace('__EDGES__',edges_json)
    html_txt+=js
    out.write_text(html_txt,encoding='utf-8')
    return {'status':'PASS','html_path':str(out),'html_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'composition_spec_sha256':spec_hash,'instrumented':True,'mass_plan_sha256':mass_hash}
