from __future__ import annotations
from pathlib import Path
import hashlib, json, math, os, shutil, tempfile, base64, re
from collections import Counter

from .semantic_master_gate import inspect_semantic_html_master

HERE=Path(__file__).resolve().parent
PROFILE_PATH=HERE.parents[1]/'config'/'production_visual_quality_profile_v7_3_2.json'
TYPE_SCALE=(12,14,16,18,21,26,32,40,52,64)

def _sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def _area(r): return max(0.0,float(r.get('w',0)))*max(0.0,float(r.get('h',0)))
def _inter(a,b):
    return max(0,min(a['r'],b['r'])-max(a['x'],b['x']))*max(0,min(a['b'],b['b'])-max(a['y'],b['y']))

def _edge_band_metrics(path):
    from PIL import Image
    import numpy as np
    import cv2
    im=Image.open(path).convert('RGB').resize((1920,1080),Image.Resampling.LANCZOS)
    a=np.asarray(im)
    gray=cv2.cvtColor(a,cv2.COLOR_RGB2GRAY)
    edges=cv2.Canny(gray,70,160)
    raw=float((edges>0).mean())
    band=cv2.dilate(edges,np.ones((21,21),np.uint8),iterations=1)
    density=float((band>0).mean())
    # page occupancy against modal 16-level canvas color
    q=(a//16).astype('int16'); packed=q[:,:,0]*256+q[:,:,1]*16+q[:,:,2]
    vals,counts=np.unique(packed,return_counts=True); mode=int(vals[int(counts.argmax())])
    mr=((mode//256)%16)*16+8; mg=((mode//16)%16)*16+8; mb=(mode%16)*16+8
    dist=np.sqrt(((a.astype('float32')-np.array([mr,mg,mb],dtype='float32'))**2).sum(axis=2))
    ink_mask=(dist>22); ink=float(ink_mask.mean())
    col=[float(ink_mask[:,i*480:(i+1)*480].mean()) for i in range(4)]; cm=sum(col)/4 or 1e-9
    # G40 is a visual-mass balance gate, not a dark-ink balance gate. The previous
    # implementation used the quantised modal colour as 'canvas', causing pale but
    # intentional surfaces (evidence rails, matrix bands) to disappear from the
    # measurement. Estimate the true canvas from the four page corners and count any
    # materially different pixel as visual mass. This preserves C9's stricter ink
    # metric while making G40 reflect what a viewer actually sees.
    patches=np.concatenate([a[:32,:32].reshape(-1,3),a[:32,-32:].reshape(-1,3),a[-32:,:32].reshape(-1,3),a[-32:,-32:].reshape(-1,3)],axis=0)
    canvas=np.median(patches,axis=0).astype('float32')
    vdist=np.sqrt(((a.astype('float32')-canvas)**2).sum(axis=2))
    visual_mask=(vdist>6.0)
    vcol=[float(visual_mask[:,i*480:(i+1)*480].mean()) for i in range(4)]; vcm=sum(vcol)/4 or 1e-9
    return {'normalized_edge_band_density':round(density,6),'raw_edge_density':round(raw,6),'ink_coverage':round(ink,6),'canvas_mode_rgb':[mr,mg,mb],'canvas_corner_rgb':[round(float(x),1) for x in canvas],'column_ink_shares':[round(x,6) for x in col],'column_ink_ratios':[round(x/cm,3) for x in col],'column_visual_mass_shares':[round(x,6) for x in vcol],'column_visual_mass_ratios':[round(x/vcm,3) for x in vcol]}

def _browser_snapshot(html_path,out_png):
    from playwright.sync_api import sync_playwright
    exe=os.environ.get('RASHAD_CHROMIUM') or shutil.which('chromium') or shutil.which('google-chrome')
    launch={'headless':True,'args':['--no-sandbox','--disable-dev-shm-usage','--allow-file-access-from-files']}
    if exe: launch['executable_path']=exe
    js="""()=>{const page=document.querySelector('.page');if(!page)return null;const rr=e=>{const r=e.getBoundingClientRect();return{x:r.x,y:r.y,w:r.width,h:r.height,r:r.right,b:r.bottom}};const css=e=>{const c=getComputedStyle(e);return{fontSize:parseFloat(c.fontSize)||0,fontFamily:c.fontFamily,borderRadius:parseFloat(c.borderRadius)||0,background:c.backgroundColor,color:c.color,display:c.display,visibility:c.visibility,direction:c.direction}};const visible=e=>{const r=e.getBoundingClientRect(),c=getComputedStyle(e);return c.display!=='none'&&c.visibility!=='hidden'&&r.width>1&&r.height>1};const els=[...page.querySelectorAll('[data-node-id],[data-region-id],[data-decoration-id],[data-artifact-type],[data-evidence-ref],[data-asset],h1,.thesis,.support li,.footer,.implication,.node-label,.node-metric,.node-owner,.node-status,.step-badge,.chart-heading,.bar-wrap,.bar-category,.bar-value,.hero-plate,table,tr,td,.hero-statement,.draft-mark')].filter(visible).map(e=>({tag:e.tagName.toLowerCase(),rect:rr(e),css:css(e),text:(e.innerText||e.textContent||'').trim(),node:e.dataset.nodeId||'',region:e.dataset.regionId||'',decoration:e.dataset.decorationId||'',source:e.dataset.source||'',owner:e.dataset.ownerId||'',paletteRole:e.dataset.paletteRole||'',artifactType:e.dataset.artifactType||'',evidenceRef:e.dataset.evidenceRef||'',chartValue:e.dataset.chartValue||'',asset:e.dataset.asset||e.dataset.assetId||'',cls:(e.className&&String(e.className))||''}));const nodes=Object.fromEntries(els.filter(x=>x.node).map(x=>[x.node,x]));const edges=[...page.querySelectorAll('#edge-layer path[data-edge-id]')].map(p=>{const len=p.getTotalLength(),samples=[];for(let i=0;i<=20;i++){const q=p.getPointAtLength(len*i/20);samples.push({x:q.x,y:q.y})}return{id:p.dataset.edgeId,source:p.dataset.source,target:p.dataset.target,samples,markerEnd:p.getAttribute('marker-end')||''}});return{page:rr(page),dir:getComputedStyle(page).direction,els,nodes,edges,layoutReady:document.documentElement.dataset.rashadLayoutReady||'',bodyText:(page.innerText||'').trim()}}"""
    with sync_playwright() as p:
        b=p.chromium.launch(**launch); page=b.new_page(viewport={'width':1920,'height':1080},device_scale_factor=1)
        page.set_content(Path(html_path).read_text(encoding='utf-8'),wait_until='load'); page.evaluate('()=>document.fonts.ready')
        page.wait_for_function("document.documentElement.dataset.rashadLayoutReady==='1'"); page.wait_for_timeout(80)
        snap=page.evaluate(js); page.screenshot(path=str(out_png),full_page=False); b.close()
    return snap

def _embedded_primary_visual_sha(html_path):
    text=Path(html_path).read_text(encoding='utf-8')
    m=re.search(r'<img[^>]+class=["\'][^"\']*hero-plate[^"\']*["\'][^>]+src=["\'](data:[^"\']+)["\']',text,re.I)
    if not m: return None
    src=m.group(1)
    try:
        head,payload=src.split(',',1)
        raw=base64.b64decode(payload) if ';base64' in head else payload.encode('utf-8')
        return hashlib.sha256(raw).hexdigest()
    except Exception:
        return None

def run_production_preexport(html_path,spec,graph,render_path,out_dir=None,*,allow_font_waiver=False,admitted_image_sha256=None):
    """Production-path release control for the highest-value semantic/visual gates.

    The function independently reopens the HTML, re-renders it at the authoritative 1920x1080 scale,
    compares those pixels byte-for-byte with the renderer output, then measures DOM + pixels. This is
    deliberately inside Brain/runtime, not a certification side-car.
    """
    prof=json.loads(PROFILE_PATH.read_text(encoding='utf-8')); th=prof.get('thresholds',{}); brand=prof.get('brand_lock',{})
    blockers=[]; gates=[]; sm=inspect_semantic_html_master(html_path,spec)
    if sm.get('status')!='PASS': blockers += ['SEMANTIC::'+x for x in sm.get('blockers',[])]
    od=Path(out_dir or tempfile.mkdtemp(prefix='rashad-preexport-')); od.mkdir(parents=True,exist_ok=True); proof_png=od/'preexport_recomputed.png'
    try: snap=_browser_snapshot(html_path,proof_png)
    except Exception as e:
        return {'status':'BLOCKED','release_verdict':'BLOCKED','blockers':['PREEXPORT_BROWSER_EXECUTION_FAILED:'+type(e).__name__],'semantic_master':sm}
    if not snap: blockers.append('PREEXPORT_PAGE_ROOT_MISSING')
    actual_render=Path(render_path or '')
    if not actual_render.exists(): blockers.append('PREEXPORT_RENDER_FILE_MISSING')
    elif _sha(actual_render)!=_sha(proof_png): blockers.append('PREEXPORT_HTML_RENDER_BYTES_DO_NOT_MATCH_PRODUCTION_RENDER')
    metrics=_edge_band_metrics(proof_png)
    dens=metrics['normalized_edge_band_density']; ink=metrics['ink_coverage']
    form=str(spec.get('dominant_form') or '').upper(); strategy=str(spec.get('communication_strategy') or '').upper()
    continuous_tone=form=='HERO_IMAGE' and bool((spec.get('overlay_policy') or {}).get('continuous_tone',True))
    if continuous_tone:
        from PIL import Image
        import numpy as np
        std=float(np.asarray(Image.open(proof_png).convert('L')).std())
        metrics['continuous_tone_luma_std']=round(std,4)
        if std<7.0: blockers.append('C9_PIXEL::CONTINUOUS_TONE_PAGE_EFFECTIVELY_FLAT')
    else:
        if ink<0.04 and dens<float(th.get('min_visual_fill_density',0.12)): blockers.append('C9_PIXEL::PAGE_EFFECTIVELY_BLANK')
        if ink>0.72: blockers.append('C9_PIXEL::PAGE_OVER_FULL')
        if dens<float(th.get('min_visual_fill_density',0.12)): blockers.append('C9_PIXEL::PAGE_VISUALLY_UNDERFILLED')
        if dens>float(th.get('max_visual_fill_density',0.72)): blockers.append('C9_PIXEL::PAGE_VISUALLY_OVERFILLED')
    approved=False
    if snap:
        els=snap['els']; page=snap['page']; nodes=snap['nodes']; edges=snap['edges']
        # Artifact truth is form-specific. Relationship forms must preserve the exact graph;
        # chart/table/statement/image forms prove their own semantic carriers instead of faking graph nodes.
        topological=form in {'HUB','STACK','LANE','MATRIX','SPINE','LADDER','FIELD','RING','TREE','FUNNEL'}
        exp_nodes={str(x.get('id')) for x in (graph or {}).get('nodes',[]) if x.get('id')}; act_nodes=set(nodes)
        exp_edges={str(x.get('id')) for x in (graph or {}).get('edges',[]) if x.get('id')}; act_edges={str(x.get('id')) for x in edges if x.get('id')}
        if topological:
            if exp_nodes!=act_nodes: blockers.append('G15_TOPOLOGY::RENDERED_NODE_SET_MISMATCH')
            if exp_edges!=act_edges: blockers.append('G16_CONNECTORS::RENDERED_EDGE_SET_MISMATCH')
        elif form=='CHART':
            bind=(spec.get('content_binding') or {}).get('chart') or {}
            bars=[e for e in els if e.get('evidenceRef') and e.get('chartValue') not in ('',None)]
            shells=[e for e in els if e.get('artifactType')=='CHART_LED']
            vals=list(bind.get('values') or []); refs=list(bind.get('evidence_refs') or []); cats=list(bind.get('categories') or [])
            if not shells: blockers.append('G32_ARTIFACT_TRUTH::CHART_SHELL_MISSING')
            if len(bars)<2: blockers.append('G32_ARTIFACT_TRUTH::CHART_REQUIRES_MULTIPLE_MARKS')
            if len(bars)!=len(vals): blockers.append('G32_ARTIFACT_TRUTH::CHART_VALUE_COUNT_MISMATCH')
            try:
                actual_vals=[float(e.get('chartValue')) for e in bars]
                if len(actual_vals)!=len(vals) or any(abs(a-float(b))>1e-9 for a,b in zip(actual_vals,vals)): blockers.append('G32_ARTIFACT_TRUTH::CHART_VALUE_BINDING_MISMATCH')
            except Exception: blockers.append('G32_ARTIFACT_TRUTH::CHART_VALUE_NOT_NUMERIC')
            if refs and [str(e.get('evidenceRef')) for e in bars] != [str(x) for x in refs]: blockers.append('G31_EVIDENCE_TRACE::CHART_EVIDENCE_BINDING_MISMATCH')
            catels=[e for e in els if 'bar-category' in str(e.get('cls','')).split()]
            if len(cats)!=len(catels): blockers.append('G32_ARTIFACT_TRUTH::CHART_CATEGORY_COUNT_MISMATCH')
        elif form=='TABLE':
            if not any(e.get('artifactType')=='TABLE_LED' for e in els): blockers.append('G32_ARTIFACT_TRUTH::TABLE_MISSING')
        elif form=='STATEMENT_BLOCK':
            if not any('hero-statement' in str(e.get('cls','')).split() for e in els): blockers.append('G32_ARTIFACT_TRUTH::STATEMENT_BLOCK_MISSING')
        elif form=='HERO_IMAGE':
            hero=[e for e in els if e.get('asset')=='PRIMARY_VISUAL']
            if not hero: blockers.append('G32_ARTIFACT_TRUTH::PRIMARY_VISUAL_MISSING')
            embedded=_embedded_primary_visual_sha(html_path)
            if not admitted_image_sha256: blockers.append('G20_ASSETS::ADMITTED_IMAGE_SHA256_REQUIRED')
            elif embedded!=str(admitted_image_sha256): blockers.append('G20_ASSETS::PRIMARY_VISUAL_NOT_BOUND_TO_ADMITTED_IMAGE')
        # Type-scale / brand font. Font waiver can only waive family, never size/quality thresholds.
        # Text collision checks operate on leaf/text objects, never region containers whose innerText aggregates children.
        # Text geometry must be measured on real text-bearing leaves/labels, not aggregate
        # artifact containers whose innerText concatenates every child. Counting a semantic
        # wrapper such as .dominant-inner as text creates false connector crossings even
        # when the path misses every glyph. Keep this predicate aligned with the composer
        # router's text avoidance selector.
        _leaf_classes={'thesis','implication','footer','node-label','node-metric','node-owner','node-status','step-badge','chart-heading','bar-category','bar-value','hero-statement','draft-mark'}
        def _text_leaf(e):
            cls=set(str(e.get('cls','')).split())
            return bool(e.get('text')) and (e.get('tag') in {'h1','li','td'} or bool(cls & _leaf_classes))
        textels=[e for e in els if _text_leaf(e)]
        sizes=sorted({round(float(e['css']['fontSize']),2) for e in textels if e['css']['fontSize']})
        tol=float(brand.get('type_scale_tolerance_px',0.6)); scale=brand.get('type_scale_px') or list(TYPE_SCALE)
        off=[x for x in sizes if min(abs(x-float(t)) for t in scale)>tol]
        if off: blockers.append('G26_TYPE_SCALE::OFF_SCALE:'+','.join(map(str,off[:8])))
        fams={e['css']['fontFamily'].lower() for e in textels if e['css']['fontFamily']}
        approved=('montserrat' in ' '.join(fams))
        if not approved and not allow_font_waiver: blockers.append('BRAND_FONT_PREFLIGHT_FAILED')
        # Arabic direction must be real computed direction, not U+200F decoration.
        if any('\u0600'<=ch<='\u06ff' for ch in snap.get('bodyText','')) and snap.get('dir')!='rtl': blockers.append('G14_RTL_BIDI::ARABIC_PAGE_NOT_RTL')
        # Dominant physical mass.
        dom=[e for e in els if e.get('region')=='DOMINANT']; dm=max((_area(e['rect'])/max(1,_area(page)) for e in dom),default=0)
        fam=str(spec.get('page_family') or '').upper()
        if fam not in {'COVER','SECTION_OPENER'} and not float(th.get('dominant_mass_min',.32))<=dm<=float(th.get('dominant_mass_max',.68)): blockers.append('G39_DOMINANT_MASS::OUT_OF_BAND')
        # Major semantic regions must not paint over each other. COBRAND/header overlap is allowed.
        regs={e['region']:e for e in els if e.get('region')}
        pairs=[('DOMINANT','SUPPORT'),('DOMINANT','IMPLICATION'),('SUPPORT','IMPLICATION'),('DOMINANT','FOOTER'),('IMPLICATION','FOOTER')]
        underlay_allowed=set((spec.get('overlay_policy') or {}).get('allowed_overlay_regions') or []) if continuous_tone else set()
        for a,b in pairs:
            if continuous_tone and a=='DOMINANT' and b in underlay_allowed: continue
            if a in regs and b in regs and _inter(regs[a]['rect'],regs[b]['rect'])>16: blockers.append(f'G07_OCCLUSION::{a}_OVERLAPS_{b}')
        # Spec-to-render parity: dominant geometry and declared negative-space zones are executable, not documentary.
        if 'DOMINANT' in regs:
            sr=spec.get('dominant_bbox') or {}; rr=regs['DOMINANT']['rect']; norm={'x':rr['x']/page['w'],'y':rr['y']/page['h'],'w':rr['w']/page['w'],'h':rr['h']/page['h']}
            if any(abs(float(norm[k])-float(sr.get(k,0)))>0.015 for k in ('x','y','w','h')): blockers.append('SPEC_RENDER_PARITY::DOMINANT_BBOX_MISMATCH')
        semantic_visible=[e for e in els if e.get('text') or e.get('node') or e.get('region') in ({'SUPPORT','IMPLICATION','FOOTER'} if continuous_tone else {'DOMINANT','SUPPORT','IMPLICATION','FOOTER'})]
        for zi,z in enumerate(spec.get('negative_space_zones') or [],1):
            b=z.get('bbox') or {}; zr={'x':float(b.get('x',0))*page['w'],'y':float(b.get('y',0))*page['h'],'w':float(b.get('w',0))*page['w'],'h':float(b.get('h',0))*page['h']}; zr['r']=zr['x']+zr['w']; zr['b']=zr['y']+zr['h']
            for e in semantic_visible:
                if _inter(zr,e['rect'])>max(25,.04*_area(zr)):
                    blockers.append(f'SPEC_RENDER_PARITY::NEGATIVE_SPACE_ZONE_{zi}_OCCUPIED'); break
        draft_visible=any('draft-mark' in str(e.get('cls','')).split() for e in els)
        # Step badges cannot strike their labels (the old pseudo-element was invisible to QA).
        badges=[e for e in els if str(e.get('decoration','')).startswith('STEP-')]
        # Use explicit DOM class: pseudo-element collisions are impossible to hide from this measurement.
        node_labels=[e for e in els if 'node-label' in str(e.get('cls','')).split()]
        for bd in badges:
            for lb in node_labels:
                if _inter(bd['rect'],lb['rect'])>4: blockers.append('G06_COLLISION::STEP_BADGE_OVERPRINTS_LABEL'); break
        # Equal filled rounded rectangles: card dominance smell unless the semantics genuinely require a HUB.
        node_list=list(nodes.values()); dims=[(round(e['rect']['w']/20)*20,round(e['rect']['h']/20)*20) for e in node_list]; common=max(Counter(dims).values(),default=0)
        rounded=sum(float(e['css']['borderRadius'] or 0)>=12 for e in node_list)
        if str(spec.get('dominant_form'))!='HUB' and len(node_list)>=4 and common>=4 and rounded>=4: blockers.append('G18_CARD_TRUTH::EQUAL_CARD_GRAMMAR')
        # Column balance is measured on final pixels, not nested DOM areas. Nested chart
        # children otherwise get counted repeatedly and make balanced pages look one-sided.
        ratios=list(metrics.get('column_visual_mass_ratios') or [])
        minr=float(th.get('column_balance_min_ratio',0.5)); maxr=float(th.get('column_balance_max_ratio',2.0))
        if len(ratios)==4 and any(float(x)<minr or float(x)>maxr for x in ratios): blockers.append('G40_COLUMN_BALANCE::MASS_IMBALANCE')
        # Connector geometry against nodes + text. Sampling uses actual SVG path pixels after fonts.ready.
        def inside(pt,r,pad=3): return r['x']-pad<=pt['x']<=r['r']+pad and r['y']-pad<=pt['y']<=r['b']+pad
        for ed in (edges if topological else []):
            src,tgt=ed.get('source'),ed.get('target'); samples=ed.get('samples') or []
            if not samples: blockers.append('G41_CONNECTOR_PATH_GEOMETRY::SAMPLES_MISSING'); continue
            for nid,n in nodes.items():
                if nid in (src,tgt): continue
                if any(inside(pt,n['rect']) for pt in samples[1:-1]): blockers.append('G41_CONNECTOR_PATH_GEOMETRY::CROSSES_NODE'); break
            for te in textels:
                # Endpoint-owned text (including externally positioned step badges) may be
                # touched only by the connector that terminates at that endpoint.
                if te.get('owner') in (src,tgt): continue
                if any(inside({'x':te['rect']['x']+te['rect']['w']/2,'y':te['rect']['y']+te['rect']['h']/2},nodes[n]['rect']) for n in (src,tgt) if n in nodes): continue
                if any(inside(pt,te['rect'],1) for pt in samples[1:-1]): blockers.append('G41_CONNECTOR_PATH_GEOMETRY::CROSSES_TEXT'); break
        # Evidence/source client-visible trace.
        if fam not in {'COVER','SECTION_OPENER'} and not any(e.get('source') for e in els): blockers.append('G31_EVIDENCE_TRACE::SOURCE_LOCATOR_MISSING')
    # Gate report / mechanically derived scorecard. Passing score only exists when all production gates pass.
    status='PASS' if not blockers else 'BLOCKED'
    score=95.0 if status=='PASS' else 40.0
    scorecard={
      'message_clarity':score,'five_second_comprehension':score,'visual_form_fitness':score,'simplicity':score,
      'executive_hierarchy':score,'evidence_legibility':score,'artifact_usefulness':score,'specificity_to_page':score,
      'rtl_typography':score,'brand_fidelity':(90.0 if status=='PASS' and allow_font_waiver else score),'production_quality':score,
    }
    if allow_font_waiver and status=='PASS': scorecard['brand_fidelity']=90.0
    artifact_truth=min(scorecard['visual_form_fitness'],scorecard['artifact_usefulness'],scorecard['specificity_to_page'])
    ceqs=sum(scorecard.values())/len(scorecard)
    return {
      'status':status,'release_verdict':'HTML_PREEXPORT_PASS' if status=='PASS' else 'BLOCKED','blockers':sorted(set(blockers)),
      'semantic_master':sm,'pixel_metrics':metrics,'recomputed_render_path':str(proof_png),'recomputed_render_sha256':_sha(proof_png),
      'actual_render_sha256':_sha(actual_render) if actual_render.exists() else None,'scorecard':scorecard,
      'artifact_truth_score':round(artifact_truth,2),'ceqs_score':round(ceqs,2),'font_waiver_used':bool(allow_font_waiver and snap and not approved),
      'profile_sha256':_sha(PROFILE_PATH),'profile_path':str(PROFILE_PATH),'gate_count':14,'draft_mark_visible':bool(snap and draft_visible),'artifact_form':str(spec.get('dominant_form') or ''),'admitted_image_sha256':admitted_image_sha256,
    }
