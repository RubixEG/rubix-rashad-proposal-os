# v7.3.3 — Executable Production Organ & Gate Suite

Added 2026-08-20 under `RASHAD-INC-2026-08-18` remediation. These modules make the
v7.3 Visual Production Organ and the Total-Quality gate contracts **executable**
rather than declarative.

| Module | Implements |
|---|---|
| `theme.py` | brand design system, embedded brand font, type scale at the binding pt floors |
| `compose.py` | instrumented HTML/SVG composer — L3 `data-*` contract (62), Arabic-Indic numeral lock (29 Rule 5), declared BiDi islands (74), co-brand cluster (16), duration-class wrappers (86_V7_3_3), bounded repair ladder (71) |
| `artifacts.py` | relational vector layer — time bands, mapping flows with real edges, 2-D fields, quantitative bars (55, 75, 63) |
| `extract.py` | `PRODUCTION_PAGE_RENDER` + measured scene-graph extraction after `document.fonts.ready` (55, 60_CANONICAL_PAGE_SCENE_GRAPH) |
| `gates.py` | 31 detectors, each declaring the authority it implements; `gate_authority_map` + coverage denominator (86_V7_3_3 coverage contract, 42 status taxonomy) |
| `repair.py` | bounded fit-repair sweep; micro-spacing only, typography never reduced; unresolved pages return upstream for role expansion (71) |
| `native_pptx.py` | **native editable PPTX adapter** from the same resolved scene graph — satisfies `83_V7_3_2` clause 12 when native editable output is requested (60, 45) |
| `pack.py` | searchable PDF from the approved HTML masters, structural cross-format parity, delivery dossier, exact-handoff certificate (26 steps 12-16, 81/84_V7_2_1, 83_CROSS_FORMAT) |

## Non-negotiables encoded here
- A detector that does not exist reports `NOT_EXECUTED`, never `PASS`.
- Every release summary carries a coverage denominator, never a bare blocker count.
- The exact-handoff guard returns `BLOCK_HANDOFF` while any gate blocker is open.
- Repair may move spacing; it may never shrink type, clip, hide, or delete evidence.
