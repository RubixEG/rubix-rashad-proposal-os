# -*- coding: utf-8 -*-
"""PRODUCTION_PAGE_RENDER + measured scene-graph extraction.

60_CANONICAL_PAGE_SCENE_GRAPH: one resolved object model that every format
adapter consumes. Geometry is measured AFTER document.fonts.ready
(55_HTML_SVG_SEMANTIC_COMPOSER_RUNTIME_CONTRACT, mandatory render order).
"""
import asyncio, hashlib, json, pathlib, sys
from playwright.async_api import async_playwright

BUILD = pathlib.Path(__file__).parent
HTML = BUILD / "html"
PNG = BUILD / "png"
SG = BUILD / "scene"
EV = BUILD / "evidence"
W, H = 1600, 900
SCALE = 2

EXTRACT = r"""() => {
  const S = document.querySelector('[data-page-id]');   // selector-by-contract (62.1 I-01)
  if (!S) return {error:'NO_PAGE_CONTAINER'};
  const R = S.getBoundingClientRect();
  const px = (v)=>+v.toFixed(2);
  const dataOf = (el)=>{const o={};for(const a of el.attributes){if(a.name.startsWith('data-'))o[a.name.slice(5)]=a.value;}return o;};
  const rgba = (s)=>{const m=(s||'').match(/rgba?\(([^)]+)\)/);if(!m)return null;
      const p=m[1].split(',').map(x=>parseFloat(x));return {r:p[0],g:p[1],b:p[2],a:p.length>3?p[3]:1};};
  const hex = (c)=>c? '#'+[c.r,c.g,c.b].map(v=>Math.round(v).toString(16).padStart(2,'0')).join('').toUpperCase():null;

  const out = {page:{}, els:[], svg:[], meta:{}};
  let UID = 0;
  out.page = Object.assign({w:px(R.width), h:px(R.height)}, dataOf(S));

  const isInline = (el)=>{const dd=getComputedStyle(el).display; return dd.startsWith('inline')||dd==='contents';};
  const allInline = (el)=>Array.from(el.children).every(c=>isInline(c)&&allInline(c));
  const isTextBlock = (el)=>((el.textContent||'').trim().length>0) && allInline(el) && el.children.length>=0;
  const runsOf = (el)=>{
    const out=[]; const wk=(node,styleEl)=>{
      for (const c of node.childNodes){
        if (c.nodeType===3){ const t=c.textContent; if(!t.replace(/\s+/g,'').length) { if(t.length) out.push({s:' ',sp:1}); continue; }
          const cs=getComputedStyle(styleEl);
          out.push({s:t.replace(/\s+/g,' '), pt:+(parseFloat(cs.fontSize)*0.6).toFixed(2),
                    weight:cs.fontWeight, color:hex(rgba(cs.color)),
                    dir:cs.direction, cls:(styleEl.className&&styleEl.className.baseVal!==undefined)?styleEl.className.baseVal:(styleEl.className+'')});
        } else if (c.nodeType===1){ wk(c, c); }
      }
    }; wk(el, el); return out;
  };
  const walk = (root, inSvg, pid)=>{
    for (const el of root.children) {
      const tag = el.tagName.toLowerCase();
      if (tag === 'svg') { collectSvg(el); continue; }
      const r = el.getBoundingClientRect();
      const cs = getComputedStyle(el);
      if (cs.display === 'none' || cs.visibility === 'hidden') continue;
      const box = {x:px(r.left-R.left), y:px(r.top-R.top), w:px(r.width), h:px(r.height)};
      const bg = rgba(cs.backgroundColor);
      const bw = ['Top','Right','Bottom','Left'].map(s=>parseFloat(cs['border'+s+'Width'])||0);
      const hasPaint = (bg && bg.a > 0.02) || bw.some(v=>v>0.4);
      // direct text only — never a container's aggregated text
      let txt = '';
      for (const c of el.childNodes) if (c.nodeType===3) txt += c.textContent;
      const hasHtmlChild = Array.from(el.childNodes).some(c=>c.nodeType===1);
      const tblock = (tag!=='img' && tag!=='table' && isTextBlock(el));
      const direct = tblock || txt.trim().length>0;
      const uid = 'E'+(++UID);
      const rec = {
        id:uid, pid:pid,
        tag, box, cls:(el.className&&el.className.baseVal!==undefined)?el.className.baseVal:(el.className+''),
        z:(cs.zIndex==='auto'?0:parseInt(cs.zIndex)||0), disp:cs.display, pos:cs.position,
        of:cs.overflow,
        data:dataOf(el)
      };
      if (hasPaint) {
        rec.paint = {fill:bg&&bg.a>0.02?hex(bg):null, fillA:bg?+bg.a.toFixed(2):0,
          bw:bw.map(v=>+v.toFixed(2)),
          bc:hex(rgba(cs.borderTopColor)),
          radius:parseFloat(cs.borderTopLeftRadius)||0};
      }
      if (direct && !COVERED.has(el)) {
        rec.text = {
          s: txt.replace(/\s+/g,' ').trim(),
          px:+parseFloat(cs.fontSize).toFixed(2),
          pt:+(parseFloat(cs.fontSize)*0.6).toFixed(2),
          weight:cs.fontWeight, color:hex(rgba(cs.color)),
          lh:+ (parseFloat(cs.lineHeight)||parseFloat(cs.fontSize)*1.2).toFixed(2),
          align:cs.textAlign, dir:cs.direction,
          family:cs.fontFamily.split(',')[0].replace(/['"]/g,''),
          ls:+(parseFloat(cs.letterSpacing)||0).toFixed(2),
          mixed: hasHtmlChild
        };
        // full string including inline children, for adapters that need the whole run
        rec.text.full = (el.textContent||'').replace(/\s+/g,' ').trim();
        rec.text.block = tblock;
        if (tblock) rec.text.runs = runsOf(el);
        // rendered line count via Range
        try { const rg=document.createRange(); rg.selectNodeContents(el);
              rec.text.lines = rg.getClientRects().length; } catch(e){}
      }
      if (tag === 'img') {
        rec.img = {src:el.getAttribute('src').slice(0,32)+'...', natW:el.naturalWidth, natH:el.naturalHeight,
                   fit:cs.objectFit};
        rec.imgFull = el.getAttribute('src');
      }
      if (tag === 'table') rec.table = true;
      const emitted = (hasPaint || direct || tag==='img' || tag==='table' || Object.keys(rec.data).length>0);
      if (emitted) out.els.push(rec);
      // a text block owns ALL its inline text; descendants must not re-emit it
      if (rec.text && rec.text.block) { markCovered(el); }
      walk(el, inSvg, emitted ? uid : pid);   // pid always references an EMITTED element
    }
  };
  const COVERED = new WeakSet();
  const markCovered = (el)=>{ for (const c of el.querySelectorAll('*')) COVERED.add(c); };
  const collectSvg = (sv)=>{
    const R2 = sv.getBoundingClientRect();
    const rec = {box:{x:px(R2.left-R.left),y:px(R2.top-R.top),w:px(R2.width),h:px(R2.height)},
                 cls:sv.getAttribute('class')||'', shapes:[]};
    const vb = (sv.getAttribute('viewBox')||'').split(/\s+/).map(Number);
    const sx = vb.length===4 ? R2.width/vb[2] : 1, sy = vb.length===4 ? R2.height/vb[3] : 1;
    const ox = vb.length===4 ? vb[0] : 0, oy = vb.length===4 ? vb[1] : 0;
    for (const n of sv.querySelectorAll('rect,line,path,circle,text,polyline,polygon')) {
      const cs2 = getComputedStyle(n);
      const b = n.getBoundingClientRect();
      const s = {t:n.tagName.toLowerCase(),
        box:{x:px(b.left-R.left),y:px(b.top-R.top),w:px(b.width),h:px(b.height)},
        stroke:cs2.stroke==='none'?null:cs2.stroke, sw:+(parseFloat(cs2.strokeWidth)||0).toFixed(2),
        fill:cs2.fill==='none'?null:cs2.fill, dash:cs2.strokeDasharray,
        data:dataOf(n)};
      if (n.tagName.toLowerCase()==='text'){ s.s=(n.textContent||'').trim();
        s.px=+parseFloat(cs2.fontSize).toFixed(2); s.pt=+(parseFloat(cs2.fontSize)*0.6).toFixed(2);
        s.anchor=cs2.textAnchor; s.weight=cs2.fontWeight; s.color=cs2.fill; }
      if (n.tagName.toLowerCase()==='line'){
        s.p=[px((+n.getAttribute('x1')-ox)*sx+R2.left-R.left), px((+n.getAttribute('y1')-oy)*sy+R2.top-R.top),
             px((+n.getAttribute('x2')-ox)*sx+R2.left-R.left), px((+n.getAttribute('y2')-oy)*sy+R2.top-R.top)];
      }
      if (n.tagName.toLowerCase()==='path'){
        // sample the path into a polyline in PAGE coordinates so every adapter can
        // rebuild it natively (60_CANONICAL_PAGE_SCENE_GRAPH: adapters consume the
        // same resolved graph; no adapter re-derives geometry)
        try {
          const L = n.getTotalLength(); const N = Math.max(6, Math.min(64, Math.round(L/8)));
          const pts = [];
          for (let i=0;i<=N;i++){ const p=n.getPointAtLength(L*i/N);
            pts.push([px((p.x-ox)*sx + R2.left-R.left), px((p.y-oy)*sy + R2.top-R.top)]); }
          s.poly = pts;
        } catch(err) { s.poly = null; }
        s.marker = n.getAttribute('marker-end')||null; }
      if (n.tagName.toLowerCase()==='circle'){ s.r = (parseFloat(n.getAttribute('r'))||0)*sx; }
      if (n.tagName.toLowerCase()==='rect'){ s.rx = (parseFloat(n.getAttribute('rx'))||0)*sx; }
      rec.shapes.push(s);
    }
    out.svg.push(rec);
  };
  walk(S, false, 'ROOT');
  out.meta.fontsReady = true;
  out.meta.elementCount = out.els.length;
  return out;
}"""


async def main():
    PNG.mkdir(exist_ok=True); SG.mkdir(exist_ok=True); EV.mkdir(exist_ok=True)
    files = sorted(HTML.glob("*.html"))
    async with async_playwright() as pw:
        br = await pw.chromium.launch(args=["--force-color-profile=srgb",
                                            "--font-render-hinting=none"])
        pg = await br.new_page(viewport={"width": W, "height": H}, device_scale_factor=SCALE)
        index = {}
        for f in files:
            await pg.goto(f.as_uri())
            await pg.evaluate("document.fonts.ready")
            await pg.wait_for_timeout(90)
            data = await pg.evaluate(EXTRACT)
            if data.get("error"):
                print("EXTRACT FAIL", f.name, data["error"]); continue
            out_png = PNG / (f.stem + ".png")
            await pg.screenshot(path=str(out_png))
            hsh = hashlib.sha256(f.read_bytes()).hexdigest()
            psh = hashlib.sha256(out_png.read_bytes()).hexdigest()
            data["source"] = {"html": f.name, "html_sha256": hsh,
                              "png": out_png.name, "png_sha256": psh}
            (SG / (f.stem + ".json")).write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
            index[f.stem] = {"html_sha256": hsh, "png_sha256": psh,
                             "elements": data["meta"]["elementCount"],
                             "page_id": data["page"].get("page-id")}
        await br.close()
    (EV / "render_index.json").write_text(json.dumps(index, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"rendered+extracted {len(index)} pages")


if __name__ == "__main__":
    asyncio.run(main())
