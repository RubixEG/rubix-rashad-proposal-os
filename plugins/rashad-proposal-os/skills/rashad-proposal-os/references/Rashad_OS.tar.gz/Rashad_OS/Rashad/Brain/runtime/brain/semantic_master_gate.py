from __future__ import annotations
from pathlib import Path
import re, json, hashlib

REQUIRED_MARKERS=('data-page-id=','data-page-mode=','data-region-id="DOMINANT"','data-composition-spec-sha256=')
FORBIDDEN_VISIBLE=('READY','NEXT','BLOCKED','NEXT_STEP=','Compliance Register v0','P0 Proposal Control Layer','v7.7 Test','EVIDENCE-BOUND')

def _spec_hash(spec):
    payload={k:v for k,v in dict(spec or {}).items() if k not in {'spec_sha256','validation'}}
    return hashlib.sha256(json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def inspect_semantic_html_master(html_path, composition_spec:dict|None=None)->dict:
    p=Path(html_path or ''); blockers=[]; warnings=[]
    if not p.exists(): return {'status':'BLOCKED','blockers':['SEMANTIC_HTML_MASTER_MISSING'],'warnings':[],'measured_object_count':0}
    txt=p.read_text(encoding='utf-8',errors='ignore')
    for m in REQUIRED_MARKERS:
        if m not in txt: blockers.append('SEMANTIC_MASTER_INSTRUMENTATION_MISSING:'+m.split('=')[0])
    spec=dict(composition_spec or {})
    if not spec or (spec.get('validation') or {}).get('status')!='PASS': blockers.append('SEMANTIC_MASTER_COMPOSITION_SPEC_INVALID')
    expected=_spec_hash(spec) if spec else None
    declared=spec.get('spec_sha256') if spec else None
    if expected and declared!=expected: blockers.append('COMPOSITION_SPEC_SELF_HASH_INVALID')
    m=re.search(r'data-composition-spec-sha256=["\']([^"\']+)',txt)
    html_declared=m.group(1) if m else None
    if not declared or html_declared!=declared: blockers.append('SEMANTIC_MASTER_SPEC_HASH_BINDING_MISMATCH')
    mass=float(spec.get('dominant_mass_target',0) or 0); family=str(spec.get('page_family') or '')
    if family in ('COVER','SECTION_OPENER') and str(spec.get('dominant_form') or '')=='HERO_IMAGE':
        if not .90<=mass<=1.0: blockers.append('SEMANTIC_MASTER_HERO_MASS_NOT_FULL_BLEED')
    elif not .32<=mass<=.68: blockers.append('SEMANTIC_MASTER_DOMINANT_MASS_OUT_OF_BAND')
    levels=(spec.get('typographic_hierarchy') or spec.get('typography') or {}).get('levels') or []
    if len(levels)<3: blockers.append('SEMANTIC_MASTER_TYPE_HIERARCHY_BELOW_FLOOR')
    if not (spec.get('negative_space_zones') or spec.get('negative_space') or []): blockers.append('SEMANTIC_MASTER_NEGATIVE_SPACE_NOT_TYPED')
    visible=re.sub(r'<script[\s\S]*?</script>|<style[\s\S]*?</style>',' ',txt,flags=re.I); visible=re.sub(r'<[^>]+>',' ',visible); visible=' '.join(visible.split())
    for token in FORBIDDEN_VISIBLE:
        if token.lower() in visible.lower(): blockers.append('SEMANTIC_MASTER_INTERNAL_VOCAB_VISIBLE:'+token)
    node_count=txt.count('data-node-id='); region_count=txt.count('data-region-id='); artifact_count=txt.count('data-artifact-type=')
    content_slot_count=len(re.findall(r'data-content-slot=["\'][^"\']+["\']',txt))
    measured=node_count+content_slot_count+artifact_count  # static chrome/region markers are not content-bearing proof
    visible_chars=len(re.sub(r'\s+','',visible))
    if family not in ('COVER','SECTION_OPENER') and (artifact_count<1 or content_slot_count<2 or visible_chars<40): blockers.append('SEMANTIC_MASTER_CONTENT_BEARING_FLOOR_NOT_MET')
    topo_nodes=len(((spec.get('topology') or {}).get('nodes') or [])); form=str(spec.get('dominant_form') or '')
    if topo_nodes>int((spec.get('acceptance') or {}).get('max_topology_nodes_per_page',8)): blockers.append('SEMANTIC_MASTER_TOPOLOGY_EXCEEDS_PAGE_CAPACITY')
    if form not in {'TABLE','CHART','STATEMENT_BLOCK','HERO_IMAGE'} and topo_nodes and node_count!=topo_nodes: blockers.append('SEMANTIC_MASTER_TOPOLOGY_NODE_COUNT_MISMATCH')
    if form=='TABLE' and len(re.findall(r'<tr(?:\s|>)',txt,re.I))<max(1,min(topo_nodes or 1,3)): blockers.append('SEMANTIC_MASTER_TABLE_ROW_FLOOR_NOT_MET')
    if form=='CHART' and txt.count('data-evidence-ref=')<max(1,min(topo_nodes or 1,3)): blockers.append('SEMANTIC_MASTER_CHART_EVIDENCE_BAR_FLOOR_NOT_MET')
    if form=='STATEMENT_BLOCK' and ('proof-strip' not in txt or visible_chars<60): blockers.append('SEMANTIC_MASTER_STATEMENT_PROOF_FLOOR_NOT_MET')
    if form=='HERO_IMAGE' and 'data-asset-id="PRIMARY_VISUAL"' not in txt: blockers.append('SEMANTIC_MASTER_HERO_ASSET_REQUIRED')
    return {'status':'PASS' if not blockers else 'BLOCKED','html_master_path':str(p),'html_master_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'blockers':sorted(set(blockers)),'warnings':warnings,'measured_object_count':measured,'node_count':node_count,'region_count':region_count,'artifact_count':artifact_count,'composition_spec_sha256':declared,'visible_content_char_count':visible_chars,'recomputed_composition_spec_sha256':expected,'html_declared_composition_spec_sha256':html_declared,'rule':'Semantic master must be instrumented, content-bearing, and byte/hash-bound to the exact PageCompositionSpec before pixel review.'}
