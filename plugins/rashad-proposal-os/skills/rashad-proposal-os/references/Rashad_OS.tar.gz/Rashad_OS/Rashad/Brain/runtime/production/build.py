# -*- coding: utf-8 -*-
import pathlib, sys, importlib
HTML = pathlib.Path(__file__).parent / "html"


def toc_data():
    """Pagination is DERIVED from the built page registry, never hand-typed.
    40_RFP..._DEPTH_CONTRACTS role 03: 'update after pagination changes'; the prior
    deck carried numbers built for 44 pages and shipped with 46. Visible labels are
    the canonical Arabic names owned by 33_ARABIC_VISIBLE_LANGUAGE_PURITY_GATE."""
    idx = {name: i for i, (name, _) in enumerate(collect(), 1)}
    P = lambda k: idx.get(k, 0)
    return [
        ("الفصل الأول — فهم الفرصة وقرار الإدارة المبكر", [
            ("ماذا تشتري الجهة فعليًا؟", "طبيعة ما يُشترى والقراءة التنفيذية للفرصة", P("p02_narrative")),
            ("صورة الفرصة في دقيقة واحدة", "المقاييس الحاسمة وما تعنيه للقرار", P("p04_snapshot1")),
            ("الجدول الزمني وضغط التقديم", "التواريخ والتعارضات والموعد الداخلي", P("p06_dates1")),
        ]),
        ("الفصل الثاني — ما الذي يطلبه العميل فعلًا؟", [
            ("اكتمال مستندات المنافسة وما يحتاج إلى حسم", "المستلم والمفقود والمتعارض وأثر كل فجوة", P("p08_coverage")),
            ("أهداف المشروع والنتائج التي تتوقعها الجهة", "الاحتياج والأهداف ومعايير النجاح", P("p09_need")),
            ("القراءة الاستراتيجية للفرصة", "إعادة تركيب المتطلبات في منطق أعمال", P("p10_strategic")),
            ("نطاق المشروع ومجالات العمل", "المسارات والاعتماديات وحدود المسؤولية", P("p11_scope1")),
            ("كيف سينتقل المشروع من التأسيس إلى التشغيل؟", "المراحل والبوابات والمسار الحرج", P("p13_journey")),
        ]),
        ("الفصل الثالث — حجم الالتزام والتنفيذ", [
            ("المخرجات والكميات: ما الذي سنلتزم بتسليمه فعليًا؟", "تفسير بنود الكميات وربطها بالقبول", P("p14_boq1")),
            ("متطلبات الحل التقني والبيانات والتكامل", "المعمارية والتكاملات والأمن والتشغيل", P("p17_tech1")),
            ("القدرات المطلوبة لتنفيذ المشروع", "الأدوار والأحجام والفجوات وأثرها", P("p20_team1")),
        ]),
        ("الفصل الرابع — كيف نفوز؟", [
            ("كيف سيُقيَّم العرض وما الذي يصنع التفوق؟", "المعايير والأوزان وما يجب أن يراه المُقيّم", P("p22_eval1")),
            ("جاهزية التأهيل والأدلة الداعمة", "ما هو متاح وما هو ناقص ومالك كل فجوة", P("p24_qual1")),
            ("الالتزامات والمخاطر التجارية والمالية", "محركات التكلفة والضمانات والغرامات", P("p26_comm1")),
        ]),
        ("الفصل الخامس — استراتيجية التقديم والتنفيذ", [
            ("استراتيجية الاستجابة للمنافسة", "محاور الفوز والأدلة التي تثبتها", P("p29_strategy1")),
            ("خطة إعداد العرض حتى التقديم", "ما أُنجز بالفعل وما يتطلب قرارًا بشريًا", P("p31_gantt1")),
            ("تصور تنفيذ المشروع بعد الترسية", "المسار من التعبئة حتى نقل المعرفة", P("p33_contract1")),
        ]),
        ("الفصل السادس — المخاطر والقرار", [
            ("ما الذي قد يهدد الفوز أو التنفيذ؟", "المخاطر المادية بأسبابها ومعالجاتها ومالكيها", P("p35_risk1")),
            ("الاستفسارات التي يجب حسمها قبل التقديم", "ما يتغيّر فعليًا باختلاف الإجابة", P("p38_clar1")),
            ("الافتراضات والفجوات المؤثرة على القرار", "ما نفترضه ولماذا وأثره ومالك إغلاقه", P("p40_assume")),
            ("ماذا تكشف طريقة إعداد المنافسة عن عملية الشراء؟", "بصمة الإعداد ونضج الشراء وأثرهما", P("p41_author1")),
            ("قرار الدخول وشروط النجاح", "التوصية وشروطها والإجراءات التالية", P("p43_decision1")),
        ]),
    ]


def collect():
    import pages_a as A
    pages = [
        ("p01_cover", A.cover),
        ("p02_narrative", A.narrative),
        ("p03_toc", lambda pg, t: A.toc(pg, t, toc_data())),
        ("p04_snapshot1", A.snapshot1),
        ("p05_snapshot2", A.snapshot2),
        ("p06_dates1", A.dates1),
        ("p07_dates2", A.dates2),
        ("p08_coverage", A.coverage),
        ("p09_need", A.need),
        ("p10_strategic", A.strategic),
        ("p11_scope1", A.scope1),
        ("p12_scope2", A.scope2),
        ("p13_journey", A.journey),
    ]
    try:
        import pages_b as B
        pages += [
            ("p14_boq1", B.boq1), ("p15_boq2", B.boq2), ("p16_boq3", B.boq3), ("p16b_boq4", B.boq4),
            ("p17_tech1", B.tech1), ("p18_tech2", B.tech2), ("p19_tech3", B.tech3),
            ("p20_team1", B.team1), ("p21_team2", B.team2),
            ("p22_eval1", B.eval1), ("p23_eval2", B.eval2),
            ("p24_qual1", B.qual1), ("p25_qual2", B.qual2),
            ("p26_comm1", B.comm1), ("p27_comm2", B.comm2), ("p27b_comm2b", B.comm2b), ("p28_comm3", B.comm3), ("p28b_comm3b", B.comm3b),
        ]
    except ImportError:
        pass
    try:
        import pages_c as Cc
        pages += [
            ("p29_strategy1", Cc.strategy1), ("p30_strategy2", Cc.strategy2),
            ("p31_gantt1", Cc.gantt1), ("p32_gantt2", Cc.gantt2),
            ("p33_contract1", Cc.contract1), ("p34_contract2", Cc.contract2),
            ("p35_risk1", Cc.risk1), ("p36_risk2", Cc.risk2), ("p37_risk3", Cc.risk3),
            ("p38_clar1", Cc.clar1), ("p39_clar2", Cc.clar2),
            ("p40_assume", Cc.assume),
            ("p41_author1", Cc.author1), ("p42_author2", Cc.author2),
            ("p43_decision1", Cc.decision1), ("p44_decision2", Cc.decision2),
        ]
    except ImportError:
        pass
    return pages


# `rail` was searched and rejected at concept critique: the 430px title rail forced
# awkward Arabic title wrapping and cramped card columns. Two frames survive.
RAIL = set()
BANNER = {"p05_snapshot2", "p07_dates2", "p11_scope1", "p15_boq2", "p16_boq3", "p16b_boq4",
          "p18_tech2", "p20_team1", "p22_eval1", "p23_eval2", "p24_qual1", "p27_comm2",
          "p27b_comm2b", "p28b_comm3b", "p30_strategy2", "p32_gantt2", "p40_assume", "p42_author2", "p44_decision2",
          "p25_qual2", "p35_risk1", "p36_risk2", "p37_risk3", "p38_clar1", "p39_clar2",
          "p08_coverage", "p14_boq1", "p21_team2", "p33_contract1"}


def main():
    import compose
    HTML.mkdir(exist_ok=True)
    for f in HTML.glob("*.html"):
        f.unlink()
    pages = collect()
    total = len(pages)
    for i, (name, fn) in enumerate(pages, 1):
        compose.CURRENT_LAYOUT["v"] = ("rail" if name in RAIL else
                                       "banner" if name in BANNER else "standard")
        (HTML / f"{name}.html").write_text(fn(i, total), encoding="utf-8")
    print(f"built {total} pages")


if __name__ == "__main__":
    main()
