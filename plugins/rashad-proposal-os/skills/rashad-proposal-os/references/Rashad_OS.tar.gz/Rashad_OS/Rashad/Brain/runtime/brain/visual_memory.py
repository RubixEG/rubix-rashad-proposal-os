from __future__ import annotations
import hashlib,json
from brain.spec_divergence import distance as structural_distance

def _struct(obj):
    fa=obj.get('focal_anchor') or {}
    return {'dominant_form':obj.get('dominant_form'),'dominant_bbox':obj.get('dominant_bbox'),'focal_zone':fa.get('zone') or obj.get('focal_point'),'eye_path':obj.get('eye_path') or obj.get('reading_path'),'mass_plan':obj.get('mass_plan'),'imagery_mode':(obj.get('imagery') or {}).get('mode') if isinstance(obj.get('imagery'),dict) else None,'structural_signature':obj.get('structural_signature')}

def fingerprint(obj): return hashlib.sha256(json.dumps(_struct(obj),sort_keys=True,separators=(',',':')).encode()).hexdigest()

def variety_check(current, history, max_consecutive_same=1, min_structural_distance=0.12):
    fp=fingerprint(current); hist=list(history or []); hist_fp=[fingerprint(x) for x in hist]
    consecutive=0
    for x in reversed(hist_fp):
        if x==fp: consecutive+=1
        else: break
    distances=[structural_distance(current,x) for x in hist]
    nearest=min(distances) if distances else 1.0
    repeated=consecutive>=max_consecutive_same or nearest<float(min_structural_distance)
    reason='REPEATED_VISUAL_GRAMMAR' if consecutive>=max_consecutive_same else ('NEAR_TEMPLATE_VISUAL_GRAMMAR' if nearest<float(min_structural_distance) else None)
    return {'status':'BLOCKED' if repeated else 'PASS','fingerprint':fp,'prior_consecutive_same':consecutive,'nearest_structural_distance':round(nearest,4),'required_min_structural_distance':float(min_structural_distance),'all_structural_distances':[round(x,4) for x in distances],'reason':reason,'content_fields_excluded':True}
