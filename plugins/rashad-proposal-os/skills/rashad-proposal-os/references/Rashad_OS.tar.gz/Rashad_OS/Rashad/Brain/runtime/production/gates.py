# -*- coding: utf-8 -*-
"""Executable QA gates for the Rashad production organ.

Every detector DECLARES the authority it implements (86_V7_3_3 AUTHORITY COVERAGE
& GATE MAPPING CONTRACT). A required authority with zero implementing detectors is
NOT_EXECUTED — never PASS. Status taxonomy is 42_EVIDENCE_BACKED_GATE_STATUS:
GATE_DEFINED | NOT_EXECUTED | PASS | FAIL | BLOCKED | N_A, and PASS requires
executed=true AND evidence_id AND evidence_timestamp.
"""
import json, math, pathlib, re, hashlib, datetime, itertools, collections

BUILD = pathlib.Path(__file__).parent
SG = BUILD / "scene"
PNG = BUILD / "png"
EV = BUILD / "evidence"
W, H = 1600, 900

# --------------------------------------------------------------------------- #
GATE_AUTHORITY_MAP = {
 "G00_INSTRUMENTATION":   ["01_ACTIVE_RUNTIME/62_PRODUCTION_INSTRUMENTATION_CONTRACT.md",
                           "01_ACTIVE_RUNTIME/61_REQUIRED_INSTRUMENTATION_AND_NO_VACUOUS_PASS.md"],
 "G01_CANVAS_BOUNDS":     ["03_ARTIFACT_ENGINE/61_DETERMINISTIC_GEOMETRY_ENGINE.md",
                           "03_ARTIFACT_ENGINE/48_RENDER_PARITY_AND_OVERFLOW_BLOCKER.md"],
 "G02_SAFE_AREA":         ["03_ARTIFACT_ENGINE/61_DETERMINISTIC_GEOMETRY_ENGINE.md",
                           "01_ACTIVE_RUNTIME/60_RENDER_QA_THREAT_MODEL_AND_CONSTANTS.md"],
 "G03_REGION_CONTAINMENT":["03_ARTIFACT_ENGINE/46_RENDERING_FIDELITY_LAYOUT_SAFETY_AND_PRODUCTION_QA.md"],
 "G04_COLLISION":         ["03_ARTIFACT_ENGINE/61_DETERMINISTIC_GEOMETRY_ENGINE.md",
                           "03_ARTIFACT_ENGINE/46_RENDERING_FIDELITY_LAYOUT_SAFETY_AND_PRODUCTION_QA.md",
                           "01_ACTIVE_RUNTIME/29_PRODUCTION_EXECUTION_FIREWALL.md"],
 "G05_OCCLUSION":         ["01_ACTIVE_RUNTIME/60_RENDER_QA_THREAT_MODEL_AND_CONSTANTS.md"],
 "G06_MICRO_ANCHOR":      ["01_ACTIVE_RUNTIME/60_RENDER_QA_THREAT_MODEL_AND_CONSTANTS.md",
                           "01_ACTIVE_RUNTIME/62_PRODUCTION_INSTRUMENTATION_CONTRACT.md"],
 "G07_TYPE_FLOOR":        ["01_ACTIVE_RUNTIME/83_V7_3_2_EXECUTABLE_DEPTH_COUNCIL_AND_RELEASE_ENFORCEMENT_LAW.md"],
 "G08_FONT_RESOLUTION":   ["03_ARTIFACT_ENGINE/62_TEXT_FIT_AND_FONT_PREFLIGHT_ENGINE.md",
                           "01_ACTIVE_RUNTIME/82_V7_3_VISUAL_PRODUCTION_ORGAN_AND_COMPOSITION_INTELLIGENCE_LAW.md"],
 "G09_TEXT_FIT":          ["03_ARTIFACT_ENGINE/62_TEXT_FIT_AND_FONT_PREFLIGHT_ENGINE.md",
                           "03_ARTIFACT_ENGINE/71_AUTO_REPAIR_AND_PAGE_SPLIT_POLICY.md"],
 "G10_NUMERAL_PURITY":    ["01_ACTIVE_RUNTIME/29_PRODUCTION_EXECUTION_FIREWALL.md",
                           "01_ACTIVE_RUNTIME/70_V7_MONOLINGUAL_OUTPUT_AND_NAMING_AUTHORITY.md",
                           "01_ACTIVE_RUNTIME/46_GOLDEN_VISUAL_MASTER_PAGE_GENERATION_CONTRACT.md"],
 "G11_LANG_PURITY":       ["01_ACTIVE_RUNTIME/33_ARABIC_VISIBLE_LANGUAGE_PURITY_GATE.md",
                           "01_ACTIVE_RUNTIME/70_V7_MONOLINGUAL_OUTPUT_AND_NAMING_AUTHORITY.md",
                           "01_ACTIVE_RUNTIME/75_V7_0_2_OWNER_ARABIC_EXECUTIVE_TERMINOLOGY_AND_NAMING_LAW.md"],
 "G12_COBRAND":           ["00_CHAT_MIRROR_KERNEL/16_COBRAND_LOGO_DIRECTOR.md",
                           "03_ARTIFACT_ENGINE/76_OPTICAL_LOGO_MEASUREMENT_ALGORITHM.md",
                           "01_ACTIVE_RUNTIME/48_NATIVE_OVERLAY_AND_COBRAND_EXACTNESS_CONTRACT.md",
                           "01_ACTIVE_RUNTIME/45_CROSS_FORMAT_BIDI_CONNECTOR_AND_COBRAND_PRECEDENCE_CONTRACT.md"],
 "G13_SURFACE_LUMINANCE": ["01_ACTIVE_RUNTIME/29_PRODUCTION_EXECUTION_FIREWALL.md",
                           "00_CHAT_MIRROR_KERNEL/01_OWNER_POLICY.md"],
 "G14_RTL_SEQUENCE":      ["03_ARTIFACT_ENGINE/63_DIRECTIONAL_LAYOUT_ENGINE.md",
                           "03_ARTIFACT_ENGINE/64_RTL_STRUCTURAL_QA_AND_NO_MIRROR_REGISTRY.md"],
 "G15_BIDI_ISLANDS":      ["03_ARTIFACT_ENGINE/74_CROSS_FORMAT_BIDI_RUN_ORDER_CONTRACT.md"],
 "G16_TOPOLOGY":          ["03_ARTIFACT_ENGINE/75_CONNECTOR_SEMANTICS_AND_ENDPOINT_CONTRACT.md",
                           "03_ARTIFACT_ENGINE/47_ARTIFACT_INTEGRITY_AUDITOR.md",
                           "03_ARTIFACT_ENGINE/43_ARTIFACT_EXECUTION_PROOF_AND_NO_DOWNGRADE_GATE.md"],
 "G17_CARD_GRAMMAR":      ["03_ARTIFACT_ENGINE/79_NO_CARD_DEFAULT_AND_ARTIFACT_ESCALATION.md",
                           "03_ARTIFACT_ENGINE/84_CARD_GRAMMAR_CONTROL_AND_ARTIFACT_RICHNESS_LOCK.md",
                           "03_ARTIFACT_ENGINE/37_LEGACY_PROPOSAL_ANTI_PATTERN_LIBRARY.md"],
 "G18_DOMINANT_MASS":     ["01_ACTIVE_RUNTIME/82_V7_3_VISUAL_PRODUCTION_ORGAN_AND_COMPOSITION_INTELLIGENCE_LAW.md",
                           "00_CHAT_MIRROR_KERNEL/14_COMPILED_ALWAYS_ON_CONTEXT.md"],
 "G19_DECK_DIVERSITY":    ["01_ACTIVE_RUNTIME/82_V7_3_VISUAL_PRODUCTION_ORGAN_AND_COMPOSITION_INTELLIGENCE_LAW.md",
                           "07_GOVERNANCE_AND_QA/44_DECK_CONTINUITY_AND_STYLE_REGRESSION_GATE.md",
                           "07_GOVERNANCE_AND_QA/47_DECK_LEVEL_CONTINUITY_EXECUTABLE_QA_CONTRACT.md"],
 "G20_TYPE_HIERARCHY":    ["01_ACTIVE_RUNTIME/82_V7_3_VISUAL_PRODUCTION_ORGAN_AND_COMPOSITION_INTELLIGENCE_LAW.md",
                           "07_GOVERNANCE_AND_QA/72_V7_TOTAL_QUALITY_OPERATING_MODEL.md"],
 "G21_EDITABILITY_CLASS": ["03_ARTIFACT_ENGINE/40_CANONICAL_ARTIFACT_VOCABULARY_AND_MAPPING.md",
                           "01_ACTIVE_RUNTIME/83_V7_3_2_EXECUTABLE_DEPTH_COUNCIL_AND_RELEASE_ENFORCEMENT_LAW.md",
                           "01_ACTIVE_RUNTIME/48_NATIVE_OVERLAY_AND_COBRAND_EXACTNESS_CONTRACT.md"],
 "G22_DURATION_CLASS":    ["01_ACTIVE_RUNTIME/86_V7_3_3_RASHAD_PURPOSE_AND_TIME_TO_VALUE_LAW.md",
                           "01_ACTIVE_RUNTIME/85_V7_3_3_OWNER_AUTHORIZED_ROLES_30_TO_32.md"],
 "G23_REDUNDANCY":        ["01_ACTIVE_RUNTIME/85_V7_3_3_OWNER_AUTHORIZED_ROLES_30_TO_32.md",
                           "03_ARTIFACT_ENGINE/142_V7_CONSULTING_INTELLIGENCE_BRAIN.md"],
 "G24_SOURCE_BINDING":    ["03_ARTIFACT_ENGINE/43_ARTIFACT_EXECUTION_PROOF_AND_NO_DOWNGRADE_GATE.md",
                           "01_ACTIVE_RUNTIME/64_V6_DOCUMENT_INSTRUCTION_ISOLATION_AND_PROMPT_INJECTION_FIREWALL.md"],
 "G25_PARITY":            ["03_ARTIFACT_ENGINE/66_VISUAL_REGRESSION_AND_PARITY_ENGINE.md",
                           "03_ARTIFACT_ENGINE/83_CROSS_FORMAT_RASTER_PARITY_RUNTIME_CONTRACT.md",
                           "03_ARTIFACT_ENGINE/45_VISUAL_FIDELITY_CONTRACT.md",
                           "07_GOVERNANCE_AND_QA/33_VISUAL_PARITY_BRIDGE_ACCEPTANCE_GATE.md"],
 "G26_HANDOFF_BINDING":   ["01_ACTIVE_RUNTIME/81_V7_2_1_EXACT_ARTIFACT_HANDOFF_LOCK.md",
                           "07_GOVERNANCE_AND_QA/84_V7_2_1_DELIVERED_FILE_BINDING_QA.md"],
 "G27_ASSET_PROVENANCE":  ["03_ARTIFACT_ENGINE/65_ASSET_HASH_AND_BRAND_PREFLIGHT.md",
                           "03_ARTIFACT_ENGINE/82_GOVERNED_MASTER_AND_LOGO_TRANSFORM_INTEGRITY.md"],
 "G28_PAGENUM_GEOMETRY":  ["01_ACTIVE_RUNTIME/48_NATIVE_OVERLAY_AND_COBRAND_EXACTNESS_CONTRACT.md",
                           "01_ACTIVE_RUNTIME/46_GOLDEN_VISUAL_MASTER_PAGE_GENERATION_CONTRACT.md"],
 "G29_ROLE_DEPTH":        ["01_ACTIVE_RUNTIME/40_RFP_SUMMARY_24_ROLE_DEPTH_CONTRACTS.md",
                           "07_GOVERNANCE_AND_QA/34_RFP_SUMMARY_DEPTH_ACCEPTANCE_GATE.md",
                           "01_ACTIVE_RUNTIME/76_V7_0_2_RFP_SUMMARY_EXECUTIVE_DECISION_DOSSIER_SKELETON.md"],
 "G30_COVER_CONTRACT":    ["00_CHAT_MIRROR_KERNEL/15_COVER_ART_DIRECTOR.md",
                           "01_ACTIVE_RUNTIME/39_ARABIC_COVER_COMPOSITION_AUTHORITY.md",
                           "01_ACTIVE_RUNTIME/53_COVER_TOPIC_RELEVANCE_CONTRACT.md",
                           "01_ACTIVE_RUNTIME/14_IMAGE_GENERATION_POLICY.md",
                           "03_ARTIFACT_ENGINE/73_GENERATED_ASSET_ADMISSION_QA.md",
                           "03_ARTIFACT_ENGINE/72_IMAGE_GENERATION_ISOLATION_GATE.md",
                           "03_ARTIFACT_ENGINE/15_VISUAL_ASSET_BRIEF_SCHEMA.md",
                           "01_ACTIVE_RUNTIME/15_IMAGE_BATCH_AND_PHASE_POLICY.md",
                           "01_ACTIVE_RUNTIME/44_IMAGE_GENERATION_ISOLATION_AND_ASSET_QA_CONTRACT.md",
                           "03_ARTIFACT_ENGINE/14_IMAGE_GENERATION_DECISION_ENGINE.md",
                           "01_ACTIVE_RUNTIME/59_IMAGE_LAST_TURN_ORCHESTRATION_CONTRACT.md"],
}

PT_FLOOR = {"TITLE": 24.0, "BODY": 16.0, "TABLE": 14.0, "LABEL": 12.0, "SOURCE": 10.0}
SAFE = 26.0                       # px safe margin on the 1600x900 canvas
AR = "٠-٩"
ARABIC = re.compile(r"[؀-ۿ]")
WESTERN = re.compile(r"[0-9]")


def _rects_overlap(a, b, tol=0.75):
    return (a["x"] < b["x"] + b["w"] - tol and b["x"] < a["x"] + a["w"] - tol and
            a["y"] < b["y"] + b["h"] - tol and b["y"] < a["y"] + a["h"] - tol)


def _area(b):
    return max(0.0, b["w"]) * max(0.0, b["h"])


def _inter(a, b):
    return (max(0.0, min(a["x"]+a["w"], b["x"]+b["w"]) - max(a["x"], b["x"])) *
            max(0.0, min(a["y"]+a["h"], b["y"]+b["h"]) - max(a["y"], b["y"])))


LABEL_CLS = {"lab", "kick", "ch", "chip", "u", "ttl", "elab", "nsub", "hp-t", "cvk"}
SOURCE_CLS = {"src", "pgno", "cvby", "foot"}
TITLE_CLS = {"h1", "cvtitle", "metric"}


def _own_role(el):
    d = el.get("data", {})
    if d.get("type-role") in PT_FLOOR:
        return d["type-role"]
    cls = set((el.get("cls", "") or "").split())
    if d.get("header-role") == "TITLE" or cls & TITLE_CLS:
        return "TITLE"
    if el.get("tag") == "th":
        return "LABEL"                       # column header is a label, not table body
    if el.get("tag") == "td":
        return "TABLE"
    if d.get("content-slot") in ("source", "pagenum") or cls & SOURCE_CLS:
        return "SOURCE"
    if cls & LABEL_CLS:
        return "LABEL"
    return None


def role_of(el, byid=None):
    """Type-strength role per 83_V7_3_2 clause 3 (title>=24, body>=16, table>=14,
    label>=12, source>=10 pt). An unclassified inline run inherits the role of its
    nearest classified ancestor — a <b> inside a label is a label."""
    r = _own_role(el)
    if r:
        return r
    if byid:
        cur, guard = el.get("pid"), 0
        while cur and cur in byid and guard < 12:
            guard += 1
            r = _own_role(byid[cur])
            if r:
                return r
            cur = byid[cur].get("pid")
    return "BODY"


# --------------------------------------------------------------------------- #
class Result:
    def __init__(self):
        self.pages = {}
        self.deck = {}

    def add(self, page, gate, status, measured, findings=None, note=""):
        self.pages.setdefault(page, {})[gate] = {
            "status": status, "measured_object_count": measured,
            "findings": findings or [], "note": note}


def run():
    files = sorted(SG.glob("*.json"))
    scenes = {f.stem: json.loads(f.read_text(encoding="utf-8")) for f in files}
    R = Result()
    ts = datetime.datetime.now(datetime.timezone.utc).isoformat()

    # ---------------- per page ---------------- #
    for name, d in scenes.items():
        els = d["els"]
        pg = d["page"]
        pid = pg.get("page-id", name)
        mode = pg.get("page-mode", "")
        # The release/draft mark is a GOVERNANCE OVERLAY required by 66_V6_2 to be
        # visible on every frame; it is deliberately outside the content safe area and
        # is not page content, so it is excluded from content gates (and only from them).
        els = [e for e in els
               if "draftmark" not in (e.get("cls") or "").split()
               and not (e.get("pid") and any(
                   "draftmark" in (x.get("cls") or "").split() and x["id"] == e["pid"]
                   for x in d["els"]))]
        byid = {e["id"]: e for e in els if e.get("id")}
        blocks = [e for e in els if e.get("disp") not in ("inline", "inline-block", None)
                  and e["box"]["w"] > 1 and e["box"]["h"] > 1]

        # G00 instrumentation conformance level
        has_container = bool(pg.get("page-id") and pg.get("page-mode") and pg.get("canvas"))
        has_hdr = any(e["data"].get("header-role") for e in els)
        has_region = any(e["data"].get("region-id") for e in els)
        nodes = [e for e in els if e["data"].get("node-id")]
        slots = [e for e in els if e["data"].get("content-slot")]
        stress = [e for e in els if "stress-grow" in e["data"]]
        words = len(" ".join((e.get("text", {}).get("s") or "") for e in els).split())
        lvl = "L0"
        if has_container and has_hdr and has_region:
            lvl = "L1"
        if lvl == "L1" and nodes:
            lvl = "L2"
        if lvl == "L2" and slots and (stress or words <= 40):
            lvl = "L3"
        required = "L1" if mode in ("COVER", "DIVIDER", "NAVIGATION") else "L3"
        ok = ({"L0": 0, "L1": 1, "L2": 2, "L3": 3}[lvl] >= {"L1": 1, "L3": 3}[required])
        modelled = [e for e in nodes if e["data"].get("node-origin") != "AUTO_STRUCTURAL"]
        R.add(name, "G00_INSTRUMENTATION", "PASS" if ok else "FAIL",
              len(els), [] if ok else [f"level={lvl} required={required}"],
              f"level={lvl} nodes={len(nodes)} (modelled={len(modelled)}, "
              f"auto_structural={len(nodes)-len(modelled)}) slots={len(slots)} "
              f"stress={len(stress)}")
        R.pages[name]["_modelled_nodes"] = len(modelled)

        # G01 canvas bounds
        off = [{"cls": e["cls"], "box": e["box"], "txt": (e.get("text", {}).get("s") or "")[:40]}
               for e in blocks
               if e["box"]["x"] < -0.6 or e["box"]["y"] < -0.6
               or e["box"]["x"] + e["box"]["w"] > W + 0.6
               or e["box"]["y"] + e["box"]["h"] > H + 0.6]
        R.add(name, "G01_CANVAS_BOUNDS", "FAIL" if off else "PASS", len(blocks), off[:6])

        # G02 safe area — text-bearing objects must sit inside the safe margin
        tb = [e for e in blocks if e.get("text")]
        vio = [{"cls": e["cls"], "box": e["box"], "txt": e["text"]["s"][:36]} for e in tb
               if e["box"]["x"] < SAFE - 0.6 or e["box"]["y"] < SAFE - 0.6
               or e["box"]["x"] + e["box"]["w"] > W - SAFE + 0.6
               or e["box"]["y"] + e["box"]["h"] > H - SAFE + 0.6]
        R.add(name, "G02_SAFE_AREA", "FAIL" if vio else "PASS", len(tb), vio[:6],
              f"safe_margin={SAFE}px")

        # G03 region containment — TRUE descendants only (resolved via the scene
        # graph parent chain), never a geometric guess
        regions = [e for e in els if e["data"].get("region-id")]
        def _descendants(root_id):
            kids = [e for e in els if e.get("pid") == root_id]
            out = list(kids)
            for k in kids:
                out += _descendants(k["id"])
            return out
        esc = []
        for r in regions:
            rb = r["box"]
            if rb["h"] < 2:
                continue
            for e in _descendants(r["id"]):
                if e["box"]["w"] < 1 or e["box"]["h"] < 1:
                    continue
                if e.get("disp", "").startswith("inline"):
                    continue
                dy = e["box"]["y"] + e["box"]["h"] - (rb["y"] + rb["h"])
                if dy > 1.5:
                    esc.append({"region": r["data"]["region-id"], "cls": e["cls"],
                                "over": round(dy, 1),
                                "txt": (e.get("text", {}) or {}).get("s", "")[:36]})
        R.add(name, "G03_REGION_CONTAINMENT", "FAIL" if esc else "PASS", len(regions), esc[:8])

        # G04 collision — accidental overlap between painted sibling blocks
        paint = [e for e in blocks if e.get("paint") and e["paint"].get("fill")
                 and e["data"].get("overlap-policy") != "ALLOW"]
        cols = []
        for a, b in itertools.combinations(paint, 2):
            if _rects_overlap(a["box"], b["box"]):
                ia = _inter(a["box"], b["box"])
                # containment (one inside the other) is intentional nesting
                if ia > 0.92 * min(_area(a["box"]), _area(b["box"])):
                    continue
                if ia < 150:
                    continue
                cols.append({"a": a["cls"][:24], "b": b["cls"][:24], "inter_px2": round(ia, 1)})
        R.add(name, "G04_COLLISION", "FAIL" if cols else "PASS", len(paint), cols[:8],
              "classified ACCIDENTAL_COLLISION unless nested or overlap-policy=ALLOW")

        # G05 occlusion — text covered by a later opaque painted block
        occ = []
        txts = [e for e in blocks if e.get("text") and e["text"]["s"]]
        opaque = [e for e in blocks if e.get("paint") and e["paint"].get("fillA", 0) > 0.85]
        for t in txts:
            for o in opaque:
                if o is t or _area(o["box"]) <= _area(t["box"]):
                    continue
                if o["z"] > t["z"] and _inter(t["box"], o["box"]) > 0.35 * _area(t["box"]):
                    occ.append({"txt": t["text"]["s"][:30], "by": o["cls"][:24],
                                "z": [t["z"], o["z"]]})
        R.add(name, "G05_OCCLUSION", "FAIL" if occ else "PASS", len(txts), occ[:6])

        # G06 micro-element anchor containment
        owners = {e["data"]["node-id"]: e for e in els if e["data"].get("node-id")}
        micro = [e for e in els if e["data"].get("owner-id")]
        bad = [{"owner": e["data"]["owner-id"], "cls": e["cls"][:20]} for e in micro
               if e["data"]["owner-id"] in owners
               and _inter(e["box"], owners[e["data"]["owner-id"]]["box"]) < 0.9 * _area(e["box"])]
        R.add(name, "G06_MICRO_ANCHOR", "FAIL" if bad else ("PASS" if micro else "N_A"),
              len(micro), bad[:6])

        # G07 type strength floors
        tiny = []
        for e in els:
            t = e.get("text")
            if not t or not t["s"]:
                continue
            r = role_of(e, byid)
            if t["pt"] < PT_FLOOR[r] - 0.05:
                tiny.append({"role": r, "pt": t["pt"], "floor": PT_FLOOR[r],
                             "cls": e["cls"][:22], "txt": t["s"][:34]})
        R.add(name, "G07_TYPE_FLOOR", "FAIL" if tiny else "PASS",
              sum(1 for e in els if e.get("text") and e["text"]["s"]), tiny[:8])

        # G08 font resolution — no silent fallback
        fams = collections.Counter(e["text"]["family"] for e in els
                                   if e.get("text") and e["text"]["s"])
        badf = {k: v for k, v in fams.items() if k not in ("PlexAr",)}
        R.add(name, "G08_FONT_RESOLUTION", "FAIL" if badf else "PASS", sum(fams.values()),
              [{"family": k, "n": v} for k, v in badf.items()])

        # G09 text fit — clipped content
        clip = [{"cls": e["cls"][:22], "txt": e["text"]["s"][:30]} for e in els
                if e.get("text") and e.get("of") in ("hidden", "clip")
                and e["text"].get("lines", 1) and e["box"]["h"] < 4]
        R.add(name, "G09_TEXT_FIT", "FAIL" if clip else "PASS", len(els), clip[:6])

        # G10 numeral purity — western digits in Arabic prose outside declared islands
        leak = []
        for e in els:
            t = e.get("text")
            if not t or not t["s"]:
                continue
            if e["data"].get("numeral-policy") == "PRESERVE":
                continue
            if "keep" in (e["cls"] or "").split() or "ltr" in (e["cls"] or "").split():
                continue
            if WESTERN.search(t["s"]):
                leak.append({"cls": e["cls"][:22], "txt": t["s"][:44]})
        R.add(name, "G10_NUMERAL_PURITY", "FAIL" if leak else "PASS",
              sum(1 for e in els if e.get("text") and e["text"]["s"]), leak[:10],
              "target western_numeral_leakage=0")

        # G11 visible-language purity — avoidable Latin in headings/labels
        AVOID = re.compile(r"\b(Strategic|Reading|Snapshot|Overview|Summary|Workstream|Treatment|"
                           r"Gate|High|Medium|Low|Critical|Finding|Council|Observation|Management|"
                           r"Conclusion|Win|Strategy|Risk|Scope|Timeline|Roadmap)\b", re.I)
        lang = []
        for e in els:
            t = e.get("text")
            if not t or not t["s"]:
                continue
            if role_of(e, byid) in ("TITLE", "LABEL") and AVOID.search(t["s"]):
                lang.append({"cls": e["cls"][:20], "txt": t["s"][:44]})
        R.add(name, "G11_LANG_PURITY", "FAIL" if lang else "PASS",
              sum(1 for e in els if e.get("text")), lang[:8],
              "avoidable_english_heading=0 / avoidable_english_label=0")

        # G12 co-brand
        cb = next((e for e in els if "cobrand" in (e["cls"] or "").split()), None)
        marks = [e for e in els if e["tag"] == "img" and "mark" in (e["cls"] or "").split()]
        f12 = []
        if cb is None:
            f12.append("COBRAND_CLUSTER_ABSENT")
        else:
            if cb["data"].get("cobrand-order") != "RUBIX_LEFT__CLIENT_RIGHT":
                f12.append("ORDER_NOT_DECLARED")
            rub = next((m for m in marks if "rubix" in (m["cls"] or "").split()), None)
            cli = next((m for m in marks if "client" in (m["cls"] or "").split()), None)
            if rub is None:
                f12.append("RUBIX_MARK_ABSENT")
            else:
                # alpha-measured visible height (76_OPTICAL_LOGO_MEASUREMENT_ALGORITHM)
                vis = rub["box"]["h"] * 0.4947
                if vis < 33.6:
                    f12.append(f"VISIBLE_WORDMARK_HEIGHT_{vis:.1f}px_BELOW_0.28in_FLOOR")
                nat = rub["img"]["natW"] / rub["img"]["natH"]
                got = rub["box"]["w"] / rub["box"]["h"]
                if abs(nat - got) / nat > 0.005:
                    f12.append(f"ASPECT_DRIFT_{abs(nat-got)/nat*100:.2f}%")
                if cli and rub["box"]["x"] > cli["box"]["x"]:
                    f12.append("RUBIX_NOT_FAR_LEFT")
                if cb["box"]["x"] > W * 0.5 and mode != "COVER":
                    f12.append("CLUSTER_NOT_ON_LEFT_HALF")
                elif cb["box"]["x"] > W * 0.5:
                    R.pages.setdefault(name, {})["_cover_cobrand_exception"] = (
                        "DOCUMENTED PAGE-FAMILY EXCEPTION (65_V6_1_PAGE_EXECUTION_DOSSIER): "
                        "39_ARABIC_COVER_COMPOSITION_AUTHORITY places the native identity zone "
                        "on the physical RIGHT for an Arabic cover and keeps the hero zone free "
                        "of overlaid chrome; the cluster sits top-left OF THAT ZONE, Rubix still "
                        "far-left inside it.")
        R.add(name, "G12_COBRAND", "FAIL" if f12 else "PASS", len(marks), f12,
              "client mark: OPTIONAL — issuing entity is unnamed in all five sources")

        # G13 surface luminance — no black / near-black canvas
        from PIL import Image
        im = Image.open(PNG / f"{name}.png").convert("RGB").resize((80, 45))
        px = list(im.getdata())
        dom = collections.Counter(px).most_common(1)[0]
        def _lin(c):
            c = c / 255.0
            return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
        Y = 0.2126*_lin(dom[0][0]) + 0.7152*_lin(dom[0][1]) + 0.0722*_lin(dom[0][2])
        R.add(name, "G13_SURFACE_LUMINANCE", "FAIL" if Y <= 0.04 else "PASS", len(px),
              [] if Y > 0.04 else [{"Y": round(Y, 4), "rgb": dom[0]}],
              f"dominant_rgb={dom[0]} Y={Y:.4f} share={dom[1]/len(px):.2f}")

        # G14 RTL sequence — semantic seq must descend in physical x
        seqs = collections.defaultdict(list)
        for e in els:
            g = e["data"].get("seq-group")
            if g:
                seqs[g].append((int(e["data"].get("seq", 0)), e["box"]["x"], e["cls"]))
        f14 = []
        for g, items in seqs.items():
            items.sort()
            xs = [x for _, x, _ in items]
            if any(xs[i] <= xs[i+1] for i in range(len(xs)-1)):
                f14.append({"group": g, "x_by_seq": xs})
        R.add(name, "G14_RTL_SEQUENCE", "FAIL" if f14 else ("PASS" if seqs else "N_A"),
              sum(len(v) for v in seqs.values()), f14,
              "RTL invariant: x(seq1) > x(seq2) > ...")

        # G15 bidi islands — Latin/technical runs must sit in a declared island
        f15 = []
        for e in els:
            t = e.get("text")
            if not t or not t["s"]:
                continue
            cls = (e["cls"] or "").split()
            if "ltr" in cls or "keep" in cls or "num" in cls:
                continue
            if ARABIC.search(t["s"]) and re.search(r"[A-Za-z]{2,}", t["s"]) and not t.get("mixed"):
                f15.append({"cls": e["cls"][:20], "txt": t["s"][:44]})
        R.add(name, "G15_BIDI_ISLANDS", "FAIL" if f15 else "PASS",
              sum(1 for e in els if e.get("text")), f15[:8])

        # G16 topology — declared edges must resolve to declared nodes
        edges = []
        for sv in d.get("svg", []):
            for sh in sv["shapes"]:
                if sh["data"].get("edge-id"):
                    edges.append(sh["data"])
        nodeids = {e["data"]["node-id"] for e in els if e["data"].get("node-id")}
        for sv in d.get("svg", []):
            for sh in sv["shapes"]:
                if sh["data"].get("node-id"):
                    nodeids.add(sh["data"]["node-id"])
        f16 = [{"edge": e.get("edge-id"), "missing": [x for x in (e.get("source"), e.get("target"))
                                                      if x and x not in nodeids]}
               for e in edges
               if any(x and x not in nodeids for x in (e.get("source"), e.get("target")))]
        R.add(name, "G16_TOPOLOGY", "FAIL" if f16 else ("PASS" if edges else "N_A"),
              len(edges), f16[:8], f"nodes={len(nodeids)} edges={len(edges)}")

        # G17 card grammar (page level) — share of body mass held by equal cards
        body = next((e for e in els if e["data"].get("region-id") == "DOMINANT"), None)
        cards = [e for e in els if "card" in (e["cls"] or "").split()]
        share = 0.0
        if body and _area(body["box"]):
            share = sum(_area(c["box"]) for c in cards) / _area(body["box"])
        R.add(name, "G17_CARD_GRAMMAR", "GATE_DEFINED", len(cards), [],
              f"card_mass_share={share:.2f} (deck-level verdict below)")
        R.pages[name]["_card_share"] = round(share, 3)
        R.pages[name]["_cards"] = len(cards)

        # G18 dominant mass
        # Dominant visual mass = largest VISIBLE object inside the dominant region,
        # measured against the live region area. Invisible layout wrappers are not
        # objects and are excluded — otherwise a bare flex row reads as mass 1.0.
        dm = 0.0
        if body and _area(body["box"]):
            def _vis_desc(rid):
                kids = [e for e in els if e.get("pid") == rid]
                out = []
                for k in kids:
                    visible = ((k.get("paint") and (k["paint"].get("fill")
                                or any(v > 0.4 for v in (k["paint"].get("bw") or []))))
                               or k.get("table") or k.get("tag") == "img"
                               or "vwrap" in (k.get("cls") or "").split())
                    if visible:
                        out.append(k)
                    out += _vis_desc(k["id"])
                return out
            vis = [v for v in _vis_desc(body["id"])
                   if _area(v["box"]) < 0.995 * _area(body["box"])]
            if vis:
                dm = max(_area(v["box"]) for v in vis) / _area(body["box"])
        okm = 0.32 <= dm <= 0.68 or mode in ("COVER",)
        R.add(name, "G18_DOMINANT_MASS", "PASS" if okm else "FAIL", 1 if body else 0,
              [] if okm else [{"dominant_mass": round(dm, 3), "band": "0.32-0.68"}],
              f"dominant_mass={dm:.3f}")
        R.pages[name]["_dm"] = round(dm, 3)

        # G20 type hierarchy levels
        lv = sorted({round(e["text"]["pt"]) for e in els if e.get("text") and e["text"]["s"]})
        R.add(name, "G20_TYPE_HIERARCHY", "PASS" if len(lv) >= 3 else "FAIL", len(lv),
              [] if len(lv) >= 3 else [{"levels": lv}], f"levels={lv}")

        # G22 duration class declaration
        NUMWORD = ("واحد|اثنان|اثنين|ثلاثة|أربعة|خمسة|ستة|سبعة|ثمانية|تسعة|عشرة|"
                   "أحد عشر|اثنا عشر|ثلاث|أربع|خمس|ست|سبع|ثمان|تسع|عشر|بضعة|عدة")
        DUR = re.compile(r"(?:[" + AR + r"0-9]+|" + NUMWORD + r")\s*"
                         r"(?:أسبوع|أسبوعًا|أسبوعين|أسابيع|شهر|شهرًا|شهرين|أشهر|"
                         r"يوم|يومًا|يومين|أيام|سنة|سنوات|سنتين|ساعة|ساعات|دقيقة|دقائق)")
        f22 = []
        for e in els:
            t = e.get("text")
            if not t or not t["s"] or not DUR.search(t["s"]):
                continue
            # walk declared ancestors: any element on the page declaring a class that
            # geometrically contains this one satisfies the declaration
            ok22 = any(a["data"].get("duration-class")
                       and _inter(e["box"], a["box"]) > 0.85 * _area(e["box"])
                       for a in els)
            if not ok22:
                f22.append({"cls": e["cls"][:20], "txt": DUR.search(t["s"]).group()[:30],
                            "full": t["s"][:60]})
        R.add(name, "G22_DURATION_CLASS", "FAIL" if f22 else "PASS",
              sum(1 for e in els if e.get("text") and e["text"]["s"] and DUR.search(e["text"]["s"])),
              f22[:10], "classes: RASHAD_PRODUCTION_TIME|RUBIX_HUMAN_CALENDAR|CLIENT_CALENDAR|CONTRACT_CALENDAR")

        # G24 source binding
        srcs = [e for e in els if e["data"].get("content-slot") == "source"]
        need = mode not in ("COVER", "NAVIGATION")
        R.add(name, "G24_SOURCE_BINDING", "PASS" if (srcs or not need) else "FAIL",
              len(srcs), [] if (srcs or not need) else ["NO_SOURCE_LOCATOR_ON_ANALYTICAL_PAGE"])

        # G28 page-number geometry — owner instruction: bottom-left
        pn = next((e for e in els if e["data"].get("content-slot") == "pagenum"), None)
        f28 = []
        if pn is None:
            f28.append("PAGE_NUMBER_ABSENT")
        elif mode == "COVER":
            R.pages.setdefault(name, {})["_cover_pagenum_exception"] = (
                "COVER_PAGE_SPEC_EXCEPTION: page number sits at the bottom-left of the native "
                "identity zone; the physical page-left is the hero image zone, which "
                "15_COVER_ART_DIRECTOR keeps free of overlaid chrome.")
        else:
            if pn["box"]["x"] + pn["box"]["w"] > W * 0.5:
                f28.append(f"NOT_LEFT x={pn['box']['x']:.0f}")
            if pn["box"]["y"] < H * 0.5:
                f28.append(f"NOT_BOTTOM y={pn['box']['y']:.0f}")
        R.add(name, "G28_PAGENUM_GEOMETRY", "FAIL" if f28 else "PASS", 1 if pn else 0, f28)


        # G30 cover contract
        if mode == "COVER":
            hero = next((e for e in els if e["data"].get("node-id") == "N-HERO"), None)
            f30 = []
            if hero is None:
                f30.append("HERO_ABSENT")
            else:
                frac = hero["box"]["w"] / W
                if not (0.52 <= frac <= 0.58):
                    f30.append(f"HERO_ZONE_WIDTH_{frac:.3f}_OUTSIDE_0.52_0.58")
                if hero["box"]["x"] > W * 0.10:
                    f30.append(f"HERO_NOT_PHYSICAL_LEFT x={hero['box']['x']:.0f}")
                if hero["data"].get("asset-state") == "COVER_HERO_PENDING":
                    f30.append("COVER_HERO_PENDING — generated engagement hero not yet injected")
            R.add(name, "G30_COVER_CONTRACT", "FAIL" if f30 else "PASS", 1 if hero else 0, f30)
        else:
            R.add(name, "G30_COVER_CONTRACT", "N_A", 0, [])

    # ---------------- deck level ---------------- #
    order = sorted(scenes)
    # G17 deck verdict: >2 consecutive card-dominant analytical pages; deck dominance
    cardpg = [n for n in order if R.pages[n].get("_card_share", 0) > 0.55]
    runs, cur = [], []
    for n in order:
        if R.pages[n].get("_card_share", 0) > 0.55:
            cur.append(n)
        else:
            if len(cur) > 2:
                runs.append(cur[:])
            cur = []
    if len(cur) > 2:
        runs.append(cur)
    dom_share = len(cardpg) / len(order)
    f17 = []
    if runs:
        f17.append({"consecutive_card_runs": [r[0] + ".." + r[-1] for r in runs],
                    "limit": "max 2 consecutive"})
    if dom_share > 0.45:
        f17.append({"deck_card_dominance": round(dom_share, 2), "limit": 0.45})
    R.deck["G17_CARD_GRAMMAR"] = {"status": "FAIL" if f17 else "PASS",
                                  "measured_object_count": len(order), "findings": f17,
                                  "note": f"card_dominant_pages={len(cardpg)}/{len(order)}"}

    # G19 deck composition diversity — 4x4 mass fingerprint distance
    def fp(name):
        d = scenes[name]
        grid = [0.0] * 16
        for e in d["els"]:
            if not (e.get("paint") and e["paint"].get("fill")) and not e.get("text"):
                continue
            b = e["box"]
            a = _area(b)
            if a < 200 or a > 0.92 * W * H:
                continue
            cx, cy = b["x"] + b["w"] / 2, b["y"] + b["h"] / 2
            gi = min(3, max(0, int(cx / W * 4))) + 4 * min(3, max(0, int(cy / H * 4)))
            grid[gi] += a
        s = sum(grid) or 1.0
        return [g / s for g in grid]

    F = {n: fp(n) for n in order}
    dists = []
    for a, b in itertools.combinations(order, 2):
        dists.append(sum(abs(x - y) for x, y in zip(F[a], F[b])) / 2.0)
    near = sum(1 for x in dists if x < 0.12)
    diversity = 1.0 - (near / len(dists)) if dists else 0.0
    R.deck["G19_DECK_DIVERSITY"] = {
        "status": "PASS" if diversity >= 0.70 else "FAIL",
        "measured_object_count": len(order),
        "findings": [] if diversity >= 0.70 else [{"diversity": round(diversity, 3), "floor": 0.70}],
        "note": f"pairs={len(dists)} near_duplicate_pairs={near} diversity={diversity:.3f} tau=0.12"}

    # G23 redundancy — a fact asserted as new on >=4 pages
    def shingles(name):
        """Cross-page duplication of ASSERTIONS. Source locators, chapter eyebrows and
        page chrome are excluded: 43_ARTIFACT_EXECUTION_PROOF requires a source
        locator on every analytical page, so their repetition is mandated, not
        redundant (85_V7_3_3 ROLE-REDUNDANCY-AUDITOR may never delete a source trace)."""
        d = scenes[name]
        SKIP_SLOT = {"source", "pagenum", "question"}
        SKIP_CLASS = {"src", "pgno", "kick", "ch", "foot", "cvby"}
        txt = " ".join(
            ((e.get("text", {}) or {}).get("s") or "")
            for e in d["els"]
            if e["data"].get("content-slot") not in SKIP_SLOT
            and not (set((e.get("cls") or "").split()) & SKIP_CLASS))
        txt = re.sub(r"[^؀-ۿ٠-٩A-Za-z0-9 ]", " ", txt)
        w = [t for t in txt.split() if len(t) > 2]
        return {" ".join(w[i:i+6]) for i in range(len(w) - 5)}
    SH = {n: shingles(n) for n in order}
    cnt = collections.Counter()
    for n in order:
        for s in SH[n]:
            cnt[s] += 1
    rep = [{"shingle": s, "pages": c} for s, c in cnt.most_common() if c >= 4][:25]
    R.deck["G23_REDUNDANCY"] = {"status": "FAIL" if rep else "PASS",
                                "measured_object_count": len(order),
                                "findings": rep,
                                "note": "blocking threshold: same 6-gram asserted on >=4 pages"}

    # ---------------- coverage ---------------- #
    executed = set()
    for gname in GATE_AUTHORITY_MAP:
        st = [R.pages[n].get(gname, {}).get("status") for n in order]
        st += [R.deck.get(gname, {}).get("status")]
        if any(s in ("PASS", "FAIL") for s in st):
            executed.add(gname)
    not_exec = sorted(set(GATE_AUTHORITY_MAP) - executed)
    auth_with_detector = set()
    for g in executed:
        auth_with_detector |= set(GATE_AUTHORITY_MAP[g])

    ledger = json.loads((BUILD.parent / "os" / ".rashad" / "AUTHORITY_LOAD_LEDGER.json").read_text(encoding="utf-8")) \
        if (BUILD.parent / "os" / ".rashad" / "AUTHORITY_LOAD_LEDGER.json").exists() else {}
    required_auth = list((ledger.get("authorities") or {}).keys())
    task_led = BUILD.parent / "os" / ".rashad" / "TASK_ROUTED_AUTHORITY_LEDGER.json"
    if task_led.exists():
        required_auth += list(json.loads(task_led.read_text(encoding="utf-8"))["authorities"].keys())

    blockers = []
    for n in order:
        for g, v in R.pages[n].items():
            if isinstance(v, dict) and v.get("status") == "FAIL":
                blockers.append({"page": n, "gate": g, "n": len(v["findings"]),
                                 "sample": v["findings"][:2]})
    for g, v in R.deck.items():
        if v["status"] == "FAIL":
            blockers.append({"page": "__DECK__", "gate": g, "n": len(v["findings"]),
                             "sample": v["findings"][:2]})

    report = {
        "schema": "RASHAD_GATE_REPORT_V7_3_3",
        "evidence_id": "EVID-" + hashlib.sha256(
            ("|".join(sorted(scenes)) + ts).encode()).hexdigest()[:20],
        "evidence_timestamp": ts,
        "engagement": "PR-IC-2026-037",
        "pages": len(order),
        "gate_authority_map": GATE_AUTHORITY_MAP,
        "authority_coverage": {
            "required_authorities": len(required_auth),
            "authorities_with_detector": len(auth_with_detector & set(required_auth)),
            "gates_defined": len(GATE_AUTHORITY_MAP),
            "gates_executed": len(executed),
            "gates_not_executed": not_exec,
        },
        "deck_gates": R.deck,
        "page_gates": R.pages,
        "blockers": blockers,
        "blocker_count": len(blockers),
        "summary_line": (f"blockers: {len(blockers)} / gates_executed: {len(executed)} of "
                         f"{len(GATE_AUTHORITY_MAP)} / authorities_with_detector: "
                         f"{len(auth_with_detector & set(required_auth))} of {len(required_auth)}"),
    }
    EV.mkdir(exist_ok=True)
    (EV / "gate_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=1),
                                         encoding="utf-8")
    print(report["summary_line"])
    agg = collections.Counter(b["gate"] for b in blockers)
    for g, c in agg.most_common():
        print(f"  {g:26s} FAIL on {c} page(s)")
    return report


if __name__ == "__main__":
    run()
