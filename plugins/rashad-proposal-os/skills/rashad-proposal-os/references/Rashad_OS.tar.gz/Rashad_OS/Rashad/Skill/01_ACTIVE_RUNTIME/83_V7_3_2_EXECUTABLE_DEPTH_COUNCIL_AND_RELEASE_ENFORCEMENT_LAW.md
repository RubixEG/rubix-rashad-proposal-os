# V7.3.2 Executable Depth, Council and Release Enforcement Law

**STATUS: P0 HARD GLOBAL AUTHORITY — ROUTED**

This release is a remediation-only overlay. It adds no new proposal capability. It makes existing v7 authorities executable.

1. RFP Summary has 24 logical roles; physical page count is computed, never fixed.
2. Every role MUST satisfy the machine-readable compiled depth contract and its product-level detectors before visual production.
3. `STRENGTH_FLOOR_PT` is numeric and binding: Arabic/body 16pt, table body 14pt, labels 12pt, sources 10pt, title 24pt. If content cannot fit at the floor, split the logical role across additional pages (1–5).
4. Every material mandatory item and required analysis MUST carry evidence and page binding. A role cannot be marked complete because its authority markdown is well-formed.
5. The cognitive council runtime uses three permanent sentinels plus trigger-selected councils from `cognitive_councils_v1.json`. Registered is not executed.
6. Any OPEN finding with severity P0/P1/CRITICAL/HIGH is a blocking finding even when no reviewer emits a separate veto token.
7. Clarification-window state is computed from verified dates. CLOSED windows prohibit outbound clarification questions and require assumptions / decision deltas / treatments.
8. Conflicting source dates require an explicit contradiction-register entry before release.
9. No certification fixture, caller-declared criticality, environment-variable font waiver, or format-classification trick may weaken a USER_VISIBLE release gate.
10. Certification evidence is valid only when bound to the current source fingerprint, suite hash and run id. A clean non-resume run starts with no generated certification evidence.
11. Static source/string audits are authority-drift checks, not adversarial attacks and cannot close product findings alone.
12. Client-visible PPTX may be raster visual-mirror only when explicitly declared. If native editable PPTX is requested and the native reconstruction organ is unavailable, fail closed with `NATIVE_EDITABLE_PPTX_CAPABILITY_NOT_IMPLEMENTED`.
13. The delivered PPTX media must be byte-bound, in order, to the certified page renders.
14. Governing authorities MUST be routed or explicitly labelled NON_GOVERNING; self-declared HARD/P0/MANDATORY laws cannot silently remain outside routing.

Machine depth contract: `01_ACTIVE_RUNTIME/rfp_summary_depth_contract_v7_3_2.json`.
