from __future__ import annotations
from pathlib import Path
import json,re
HERE=Path(__file__).resolve(); RASHAD=HERE.parents[3]; SKILL=RASHAD/'Skill'
MANIFEST=SKILL/'ACTIVE_AUTHORITY_MANIFEST.json'; REGISTRY=SKILL/'01_ACTIVE_RUNTIME/AUTHORITY_ROUTING_REGISTRY_V7_3_2.json'
RX=re.compile(r'(?im)^\s*(?:\*\*)?(?:STATUS|TIER|AUTHORITY(?:\s+TIER)?|PRIORITY)(?:\*\*)?\s*[:=-]\s*.*\b(HARD|BLOCKING|MANDATORY|LAW|P0|IMMUTABLE|BINDING|CONSTITUTIONAL)\b')

def _j(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def detect_normative_declarations():
    rows=[]
    for p in SKILL.rglob('*.md'):
        t=p.read_text(encoding='utf-8',errors='ignore'); m=RX.search(t[:5000])
        if m: rows.append({'path':p.relative_to(SKILL).as_posix(),'declared_status':m.group(0).strip()})
    return sorted(rows,key=lambda x:x['path'])

def validate_authority_routing():
    detected=detect_normative_declarations(); reg=_j(REGISTRY); by={x.get('path'):x for x in reg.get('authorities',[])}
    dpaths={x['path'] for x in detected}; rpaths=set(by)
    missing=sorted(dpaths-rpaths); stale=sorted(rpaths-dpaths); invalid=[]
    allowed={'GLOBAL_ACTIVE','STRUCTURED_TASK_ROUTE','TASK_LOCAL_ROUTED_V7_3_2','CERTIFICATION_ONLY','NON_GOVERNING'}
    for p in sorted(dpaths&rpaths):
        row=by[p]
        if row.get('classification') not in allowed or not row.get('runtime_consumer') or not row.get('product_scopes'):
            invalid.append(p)
        if not (SKILL/p).exists(): invalid.append(p)
    ok=not missing and not stale and not invalid and reg.get('normative_declaration_count')==len(detected)
    return {'status':'PASS' if ok else 'BLOCKED','detected':len(detected),'registered':len(by),'missing':missing,'stale':stale,'invalid':sorted(set(invalid))}

def compile_authority_bundle(product='RFP_SUMMARY', *, include_text=False):
    check=validate_authority_routing()
    if check['status']!='PASS': return {'status':'BLOCKED','reason':'NORMATIVE_AUTHORITY_ROUTING_INCOMPLETE','routing_qa':check,'authorities':[]}
    reg=_j(REGISTRY); m=_j(MANIFEST); out=[]; seen=set()
    for p in m.get('global_authorities') or []:
        if p not in seen and (SKILL/p).exists(): out.append({'path':p,'route':'GLOBAL_ACTIVE'}); seen.add(p)
    for r in reg.get('authorities',[]):
        scopes=set(r.get('product_scopes') or [])
        if r.get('classification') in {'CERTIFICATION_ONLY','NON_GOVERNING'}: continue
        if not ({'ALL_PRODUCTS',product}&scopes): continue
        p=r['path']
        if p not in seen:
            row={'path':p,'route':r.get('classification'),'runtime_consumer':r.get('runtime_consumer')}
            if include_text: row['text']=(SKILL/p).read_text(encoding='utf-8',errors='ignore')
            out.append(row); seen.add(p)
    return {'status':'PASS','product':product,'authority_count':len(out),'routing_qa':check,'authorities':out}
