from __future__ import annotations
from pathlib import Path
from PIL import Image
import math,hashlib
from .projector import build_image_master_pptx
from brain.production_quality_judge import deterministic_deck_review

def make_montage(page_images,out_path,thumb_w=480):
    imgs=[]
    for p in page_images:
        im=Image.open(p).convert('RGB'); h=round(im.height*thumb_w/im.width); imgs.append(im.resize((thumb_w,h)))
    if not imgs: return {'status':'BLOCKED','reason':'NO_PAGE_IMAGES'}
    cols=3; rows=math.ceil(len(imgs)/cols); th=max(x.height for x in imgs); canvas=Image.new('RGB',(cols*thumb_w,rows*th),'white')
    for i,im in enumerate(imgs): canvas.paste(im,((i%cols)*thumb_w,(i//cols)*th))
    out=Path(out_path); out.parent.mkdir(parents=True,exist_ok=True); canvas.save(out,quality=95)
    return {'status':'PASS','montage_path':str(out),'montage_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'page_count':len(imgs)}

def assemble_certified_deck(page_promotions,out_dir,*,output_mode='RASTER_VISUAL_MIRROR_PPTX',classification='USER_VISIBLE_ARTIFACT_DRAFT',deck_artifact_council_execution=None,extra=None):
    """Production deck assembly. It cannot silently claim native editability."""
    if output_mode in {'NATIVE_EDITABLE_PPTX','EDITABLE_PPTX','MODE_C_NATIVE_EDITABLE'}:
        return {'status':'BLOCKED','reason':'NATIVE_EDITABLE_PPTX_CAPABILITY_NOT_IMPLEMENTED','requested_output_mode':output_mode}
    if output_mode not in {'RASTER_VISUAL_MIRROR_PPTX','VISUAL_MIRROR_PPTX'}:
        return {'status':'BLOCKED','reason':'UNSUPPORTED_OUTPUT_MODE','requested_output_mode':output_mode}
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    good=[x for x in page_promotions if x.get('status')=='PASS' and (x.get('production_page') or {}).get('render_path')]
    if len(good)!=len(page_promotions) or not good: return {'status':'BLOCKED','reason':'ALL_PAGES_MUST_BE_CERTIFIED_BEFORE_DECK_ASSEMBLY'}
    images=[Path(x['production_page']['render_path']) for x in good]
    proj=build_image_master_pptx(images,out/'Rashad_visual_mirror.pptx')
    if proj.get('status')!='PASS': return {'status':'BLOCKED','reason':'PPTX_PROJECTION_MEDIA_BINDING_FAILED','projection':proj}
    montage=make_montage(images,out/'deck_montage.jpg')
    if montage.get('status')!='PASS': return {'status':'BLOCKED','reason':'DECK_MONTAGE_FAILED','montage':montage}
    pages=[x['production_page'] for x in good]
    dr=deterministic_deck_review(montage['montage_path'],proj['pptx_sha256'],montage['montage_sha256'],pages)
    # Delayed import avoids circular import during page promotion.
    from artifact_delivery_orchestrator import build_delivery_dossier, authorize_delivery
    ex=dict(extra or {}); ex['projection_media_binding']={'status':proj['media_binding_status'],'source_page_render_hashes':proj['source_page_render_hashes'],'embedded_media_hashes':proj['embedded_media_hashes'],'projection_mode':proj['projection_mode'],'editable':False}
    dossier=build_delivery_dossier(proj['pptx_path'],good,dr,montage_path=montage['montage_path'],classification=classification,extra=ex,deck_artifact_council_execution=deck_artifact_council_execution)
    verdict=authorize_delivery(dossier,proj['pptx_path'],classification)
    return {'status':'PASS' if verdict.get('status')=='DELIVERY_ALLOWED' else 'BLOCKED','projection':proj,'montage':montage,'deck_review':dr,'dossier':dossier,'delivery':verdict,'pptx_path':proj['pptx_path']}
