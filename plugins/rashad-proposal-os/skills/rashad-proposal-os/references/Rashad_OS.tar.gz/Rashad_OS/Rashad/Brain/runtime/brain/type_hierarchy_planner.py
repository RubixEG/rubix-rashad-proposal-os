from __future__ import annotations
PRODUCTION_SCALE=(12,14,16,18,21,26,32,40,52,64)
def resolve_type_hierarchy(language='AR',dense=False):
    fam='Montserrat Arabic' if str(language).upper().startswith('AR') else 'Montserrat'
    levels=[{'role':'TITLE','px':52},{'role':'THESIS','px':26},{'role':'BODY','px':21},{'role':'SOURCE','px':14}]
    if dense: levels=[{'role':'TITLE','px':40},{'role':'THESIS','px':26},{'role':'BODY','px':18},{'role':'SOURCE','px':12}]
    assert all(x['px'] in PRODUCTION_SCALE for x in levels)
    return {'font_family':fam,'levels':levels,'min_distinct_levels':3,'scale':list(PRODUCTION_SCALE),'dense':bool(dense)}
