from __future__ import annotations
from pathlib import Path
import hashlib,json
from brain.pixel_truth import measure_render
from brain.semantic_master_gate import inspect_semantic_html_master

DIMS=(
    'message_clarity','five_second_comprehension','visual_form_fitness','simplicity',
    'executive_hierarchy','evidence_legibility','artifact_usefulness','specificity_to_page',
    'rtl_typography','brand_fidelity','production_quality'
)


def _sha_obj(v):
    return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,default=str,separators=(',',':')).encode()).hexdigest()


def deterministic_pixel_review(request:dict, actor_id='RASHAD-DETERMINISTIC-PIXEL-JUDGE'):
    """Production-path deterministic hard gate.

    v7.3.2 deliberately stops treating pixel density/entropy as a positive aesthetic score.
    The deterministic judge can only establish that the exact HTML/spec/graph/render satisfy
    production release invariants. Passing scores are emitted *only after* every invariant passes.
    An independent model/SME may add aesthetic preference, but cannot waive these blockers.
    """
    from brain.production_preexport_qa import run_production_preexport
    request=dict(request or {})
    path=Path(request.get('render_path') or '')
    expected=request.get('actual_render_hash')
    spec=request.get('composition_spec') or {}
    graph=request.get('semantic_graph') or {}
    pm=measure_render(path,expected_hash=expected)
    pre=run_production_preexport(
        request.get('html_master_path'), spec, graph, path,
        out_dir=request.get('preexport_qa_out_dir'),
        allow_font_waiver=bool(request.get('certification_font_waiver',False)),
        admitted_image_sha256=request.get('admitted_image_sha256') or request.get('image_asset_sha256'),
    )
    hard=[]
    if pm.get('status')!='PASS': hard.extend('PIXEL:'+x for x in pm.get('blockers',[]))
    if pre.get('status')!='PASS': hard.extend('PREEXPORT:'+x for x in pre.get('blockers',[]))
    hard=sorted(set(hard))
    passed=not hard
    scorecard=dict(pre.get('scorecard') or {})
    if not passed or any(k not in scorecard for k in DIMS):
        scorecard={k:40.0 for k in DIMS}
    artifact_truth=float(pre.get('artifact_truth_score',40.0 if not passed else 95.0)) if passed else 40.0
    ceqs=float(pre.get('ceqs_score',40.0 if not passed else 95.0)) if passed else 40.0
    basis={
        'schema':'RASHAD_REVIEW_BASIS_V1',
        'actual_render_hash':expected,
        'pixel_measurement_sha256':pm.get('measurement_sha256'),
        'composition_spec_sha256':spec.get('spec_sha256'),
        'production_preexport_qa_sha256':_sha_obj(pre),
        'production_profile_sha256':pre.get('profile_sha256'),
        'inspection_basis':['ACTUAL_RENDER_PIXELS','RECOMPUTED_SEMANTIC_MASTER','COMPOSITION_SPEC','SEMANTIC_GRAPH','PRODUCTION_V4_PREEXPORT_GATES'],
    }
    return {
        'status':'PASS' if passed else 'BLOCKED',
        'independent':True,
        'review_id':'DPIX-'+str(expected or '')[:16],
        'actor_id':actor_id,
        'actual_render_hash':expected,
        'scores':{k:round(float(scorecard.get(k,40.0)),2) for k in DIMS},
        'generic_layout_swap_test':'PASS' if passed else 'FAIL',
        'artifact_skeptic_test':'PASS' if passed else 'FAIL',
        'five_second_test':'PASS' if passed else 'FAIL',
        'hard_blockers':hard,
        'artifact_truth_score':round(artifact_truth,2),
        'ceqs_score':round(ceqs,2),
        'review_basis':basis,
        'pixel_measurement':pm,
        'semantic_master_qa':pre.get('semantic_master'),
        'production_preexport_qa':pre,
        'quality_authority':'PRODUCTION_PREEXPORT_GATE_V7_3_2',
    }

DECK_DIMS=('narrative_rhythm','visual_variety','executive_coherence','cross_page_specificity','density_rhythm','brand_consistency','rtl_consistency','overall_partner_grade')

def deterministic_deck_review(montage_path, deck_sha256, montage_sha256, pages, actor_id='RASHAD-DETERMINISTIC-DECK-JUDGE'):
    pm=measure_render(montage_path,expected_hash=montage_sha256)
    strategies=[p.get('selected_strategy') for p in (pages or []) if p.get('selected_strategy')]
    uniq=len(set(strategies)); n=max(1,len(strategies))
    hard=[]
    if pm.get('status')!='PASS': hard.extend('MONTAGE:'+x for x in pm.get('blockers',[]))
    if len(strategies)>=6 and uniq < min(5,max(3,round(len(strategies)*.35))): hard.append('INSUFFICIENT_STRATEGY_VARIETY')
    metrics=pm.get('metrics') or {}; occ=float(metrics.get('occupied_cell_ratio',0) or 0); ent=float(metrics.get('entropy_bits',0) or 0)
    variety=min(98.0,88.0+min(8.0,uniq/max(1,n)*18.0)+min(2.0,ent/2.0))
    density=min(97.0,89.0+min(8.0,occ*8.0))
    base=min(variety,density,95.0)
    if hard: base=40.0
    scores={k:round(base,2) for k in DECK_DIMS}
    basis={'schema':'RASHAD_DECK_REVIEW_BASIS_V1','deck_sha256':deck_sha256,'montage_sha256':montage_sha256,'pixel_measurement_sha256':pm.get('measurement_sha256'),'inspection_basis':['ACTUAL_MONTAGE_PIXELS','PAGE_STRATEGY_SET'],'page_count':len(pages or []),'strategy_count':uniq}
    return {'status':'PASS' if not hard else 'BLOCKED','independent':True,'review_id':'DDECK-'+str(deck_sha256 or '')[:14],'actor_id':actor_id,'deck_sha256':deck_sha256,'montage_sha256':montage_sha256,'scores':scores,'generic_deck_swap_test':'PASS' if not hard else 'FAIL','diagram_overuse_test':'PASS' if not hard else 'FAIL','hard_blockers':hard,'review_basis':basis,'montage_pixel_measurement':pm}
