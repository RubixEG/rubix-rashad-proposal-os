from __future__ import annotations
from pathlib import Path
from pptx import Presentation
from pptx.util import Inches
import hashlib,zipfile,re,xml.etree.ElementTree as ET
RNS={'r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships','p':'http://schemas.openxmlformats.org/presentationml/2006/main','a':'http://schemas.openxmlformats.org/drawingml/2006/main'}
RELNS='{http://schemas.openxmlformats.org/package/2006/relationships}'
def _sha_bytes(b): return hashlib.sha256(b).hexdigest()
def _sha(p): return _sha_bytes(Path(p).read_bytes())

def _embedded_hashes_in_slide_order(pptx_path):
    z=zipfile.ZipFile(pptx_path); out=[]
    slides=sorted([n for n in z.namelist() if re.fullmatch(r'ppt/slides/slide\d+\.xml',n)],key=lambda n:int(re.search(r'(\d+)',Path(n).stem).group(1)))
    for s in slides:
        num=re.search(r'(\d+)',Path(s).stem).group(1); relname=f'ppt/slides/_rels/slide{num}.xml.rels'
        rels={}
        if relname in z.namelist():
            rr=ET.fromstring(z.read(relname))
            for rel in rr.findall(f'{RELNS}Relationship'):
                rels[rel.get('Id')]=rel.get('Target')
        root=ET.fromstring(z.read(s)); pics=[]
        for pic in root.findall('.//p:pic',RNS):
            blip=pic.find('.//a:blip',RNS); rid=blip.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed') if blip is not None else None
            target=rels.get(rid)
            if target:
                # target is ../media/imageN.png relative to ppt/slides
                media='ppt/'+target.replace('../','') if target.startswith('../') else 'ppt/slides/'+target
                media=media.replace('ppt/media/../','ppt/')
                if media in z.namelist(): pics.append(_sha_bytes(z.read(media)))
        out.append(pics)
    return out

def verify_projection_media_binding(pptx_path, expected_source_hashes):
    p=Path(pptx_path); expected=list(expected_source_hashes or [])
    if not p.exists(): return {'status':'BLOCKED','reason':'PPTX_NOT_FOUND','embedded_media_hashes':[]}
    try: by_slide=_embedded_hashes_in_slide_order(p)
    except Exception as e: return {'status':'BLOCKED','reason':'PPTX_MEDIA_REINSPECTION_FAILED','detail':repr(e),'embedded_media_hashes':[]}
    embedded=[x[0] if len(x)==1 else None for x in by_slide]
    ok=len(embedded)==len(expected) and embedded==expected and all(x is not None for x in embedded)
    return {'status':'PASS' if ok else 'BLOCKED','pptx_sha256':_sha(p),'expected_source_hashes':expected,'embedded_media_hashes':embedded,'embedded_media_hashes_by_slide':by_slide,'reason':None if ok else 'DECK_MEDIA_NOT_BOUND_TO_CERTIFIED_PAGE_RENDERS'}

def build_image_master_pptx(page_images,out_path):
    page_images=[Path(x) for x in page_images]
    if not page_images or any(not x.exists() for x in page_images): return {'status':'BLOCKED','reason':'PAGE_IMAGE_MISSING'}
    source_hashes=[_sha(x) for x in page_images]
    prs=Presentation(); prs.slide_width=Inches(13.333333); prs.slide_height=Inches(7.5); blank=prs.slide_layouts[6]
    for img in page_images:
        s=prs.slides.add_slide(blank); s.shapes.add_picture(str(img),0,0,width=prs.slide_width,height=prs.slide_height)
    out=Path(out_path); out.parent.mkdir(parents=True,exist_ok=True); prs.save(out)
    embedded_by_slide=_embedded_hashes_in_slide_order(out)
    embedded=[x[0] if len(x)==1 else None for x in embedded_by_slide]
    binding_ok=len(embedded)==len(source_hashes) and embedded==source_hashes and all(x is not None for x in embedded)
    return {'status':'PASS' if binding_ok else 'BLOCKED','pptx_path':str(out),'pptx_sha256':_sha(out),'slide_count':len(page_images),'projection_mode':'RASTER_VISUAL_MIRROR_FROM_CERTIFIED_SEMANTIC_HTML_MASTER','source_page_render_hashes':source_hashes,'embedded_media_hashes':embedded,'embedded_media_hashes_by_slide':embedded_by_slide,'media_binding_status':'PASS' if binding_ok else 'BLOCKED','editable':False}
