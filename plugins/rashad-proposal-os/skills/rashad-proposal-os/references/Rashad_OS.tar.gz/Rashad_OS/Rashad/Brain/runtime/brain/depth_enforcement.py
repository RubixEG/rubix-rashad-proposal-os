from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, math, re

HERE=Path(__file__).resolve()
RASHAD=HERE.parents[3]
SKILL=RASHAD/'Skill'
CONTRACT_PATH=SKILL/'01_ACTIVE_RUNTIME/rfp_summary_depth_contract_v7_3_2.json'
SOURCE_PATH=SKILL/'01_ACTIVE_RUNTIME/40_RFP_SUMMARY_24_ROLE_DEPTH_CONTRACTS.md'

HIGH_SEVERITY={'P0','P1','CRITICAL','HIGH'}


def _sha(path:Path)->str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load_contract()->dict:
    d=json.loads(CONTRACT_PATH.read_text(encoding='utf-8'))
    if d.get('version')!='7.3.2' or d.get('status')!='ROUTED_MACHINE_READABLE_DEPTH_AUTHORITY':
        raise RuntimeError('DEPTH_CONTRACT_VERSION_OR_STATUS_INVALID')
    if d.get('source_authority_sha256')!=_sha(SOURCE_PATH):
        raise RuntimeError('DEPTH_CONTRACT_SOURCE_HASH_MISMATCH')
    if d.get('role_count')!=24 or d.get('mandatory_item_count')!=226:
        raise RuntimeError('DEPTH_CONTRACT_PROTECTED_COUNT_MISMATCH')
    return d

def role_contract(role_id:str)->dict:
    d=load_contract()
    for r in d['roles']:
        if r['canonical_id']==role_id:
            return r
    raise KeyError(role_id)

def strength_floor()->dict:
    return dict(load_contract()['strength_floor_pt'])

def pages_required(role_id:str, *, not_applicable_item_ids=None, applicable_item_ids=None)->dict:
    c=role_contract(role_id); floor=strength_floor()
    all_ids={x['id'] for x in c['mandatory_items']}
    na=set(not_applicable_item_ids or []) & all_ids
    if applicable_item_ids is not None:
        effective=set(applicable_item_ids) & all_ids
    else:
        effective=all_ids-na
    cap=int(floor['high_expansion_items_per_page_at_floor'] if role_id in set(load_contract()['high_expansion_roles']) else floor['standard_items_per_page_at_floor'])
    pages=max(int(floor['min_pages_per_role']), min(int(floor['max_pages_per_role']), math.ceil(max(1,len(effective))/max(1,cap))))
    return {'role_id':role_id,'mandatory_items_total':len(all_ids),'not_applicable_count':len(na),'effective_mandatory_items':len(effective),'items_per_page_at_floor':cap,'pages_required':pages,'strength_floor_pt':floor}


def _coverage_map(obj, key):
    raw=obj.get(key) or []
    if isinstance(raw,dict):
        return {str(k): (dict(v) if isinstance(v,dict) else {'status':str(v)}) for k,v in raw.items()}
    out={}
    for x in raw if isinstance(raw,list) else []:
        if isinstance(x,str): out[x]={'status':'COVERED'}
        elif isinstance(x,dict) and x.get('item_id'): out[str(x['item_id'])]=dict(x)
    return out

def _good_refs(rec):
    refs=rec.get('evidence_refs') or rec.get('source_refs') or []
    if isinstance(refs,str): refs=[refs]
    return [str(x).strip() for x in refs if str(x).strip()]

def _is_na(rec):
    return str(rec.get('status','')).upper() in {'NOT_APPLICABLE_WITH_EVIDENCE','N_A_WITH_EVIDENCE','NOT_APPLICABLE'}

def _is_covered(rec):
    return str(rec.get('status','COVERED')).upper() in {'COVERED','PASS','SATISFIED','VERIFIED'}

def _validate_rows(rows, required_fields, prefix, blockers):
    if not isinstance(rows,list) or not rows:
        blockers.append(prefix+'::ROWS_REQUIRED'); return
    for i,row in enumerate(rows,1):
        if not isinstance(row,dict): blockers.append(f'{prefix}::ROW_{i}_INVALID'); continue
        for f in required_fields:
            v=row.get(f)
            if v is None or (isinstance(v,str) and not v.strip()) or (isinstance(v,(list,dict)) and not v):
                blockers.append(f'{prefix}::ROW_{i}_MISSING_{f.upper()}')


def _special_role_checks(role_id, output, context, blockers, warnings):
    if role_id=='RISKS':
        _validate_rows(output.get('risk_rows') or output.get('risks'), ['risk','owner','treatment','residual_risk','evidence_refs'], 'DEPTH_RISK', blockers)
    elif role_id=='CLARIFICATIONS':
        rows=output.get('clarification_rows') or output.get('clarifications')
        _validate_rows(rows, ['observation','default_assumption','decision_delta','impact','treatment'], 'DEPTH_CLARIFICATION', blockers)
        cw=str((context or {}).get('clarification_window_status') or output.get('clarification_window_status') or '').upper()
        if cw=='CLOSED' and isinstance(rows,list):
            for i,row in enumerate(rows,1):
                if not isinstance(row,dict): continue
                if row.get('question_to_client') or str(row.get('disposition','')).upper() in {'SEND','ASK_CLIENT','OPEN_QUESTION'}:
                    blockers.append(f'DEPTH_CLARIFICATION::ROW_{i}_CLOSED_WINDOW_OUTBOUND_QUESTION_FORBIDDEN')
    elif role_id=='KEY_DATES':
        rows=output.get('date_fields') or output.get('dates')
        if not isinstance(rows,list) or not rows: blockers.append('DEPTH_DATE::DATE_FIELDS_REQUIRED')
        else:
            for i,row in enumerate(rows,1):
                if not isinstance(row,dict): continue
                vals=row.get('source_values') or []
                norm={str(x.get('value') if isinstance(x,dict) else x).strip() for x in vals if str(x).strip()}
                if len(norm)>1 and str(row.get('status','')).upper() not in {'CONFLICT','UNRESOLVED_CONFLICT','RESOLVED_CONFLICT'}:
                    blockers.append(f'DEPTH_DATE::ROW_{i}_MULTIPLE_SOURCE_VALUES_REQUIRE_CONFLICT_STATUS')
                if len(norm)>1 and not row.get('conflict_id'):
                    blockers.append(f'DEPTH_DATE::ROW_{i}_DATE_CONFLICT_REGISTER_ID_REQUIRED')
    elif role_id=='SOURCE_COVERAGE':
        _validate_rows(output.get('source_gap_rows') or output.get('gaps_conflicts'), ['classification','impact','owner','evidence_refs'], 'DEPTH_SOURCE_GAP', blockers)
    elif role_id=='BOQ_INTELLIGENCE':
        _validate_rows(output.get('boq_rows'), ['boq_item','scope_mapping','acceptance_logic','cost_driver','pricing_implication','evidence_refs'], 'DEPTH_BOQ', blockers)
    elif role_id=='TEAM_CAPACITY':
        _validate_rows(output.get('team_rows'), ['role','count','minimum_experience','availability_status','evidence_refs'], 'DEPTH_TEAM', blockers)
    elif role_id=='EVALUATION_WIN':
        _validate_rows(output.get('evaluation_rows'), ['criterion','weight_or_rule','evidence_required','win_action','evidence_refs'], 'DEPTH_EVALUATION', blockers)
    elif role_id=='QUALIFICATION_READINESS':
        _validate_rows(output.get('qualification_rows'), ['requirement','evidence_status','gap_or_action','evidence_refs'], 'DEPTH_QUALIFICATION', blockers)
    elif role_id=='COMMERCIAL_EXPOSURE':
        _validate_rows(output.get('cost_drivers'), ['driver','known_quantity_or_basis','confidence','commercial_effect','evidence_refs'], 'DEPTH_COMMERCIAL', blockers)
        tc=output.get('team_count'); months=output.get('contract_months')
        if tc is not None and months is not None:
            try:
                expected=float(tc)*float(months); actual=float(output.get('person_months'))
                if abs(actual-expected)>1e-6: blockers.append('DEPTH_COMMERCIAL::PERSON_MONTHS_DERIVATION_MISMATCH')
            except Exception: blockers.append('DEPTH_COMMERCIAL::PERSON_MONTHS_DERIVATION_REQUIRED_WHEN_TEAM_AND_DURATION_KNOWN')
    elif role_id=='TABLE_OF_CONTENTS':
        roles=output.get('active_role_ids') or []
        if len(set(roles))<24: blockers.append('DEPTH_TOC::ALL_ACTIVE_ROLES_REQUIRED')
    elif role_id=='COVER':
        if output.get('analytical_conclusions'): blockers.append('DEPTH_COVER::ANALYTICAL_CONCLUSIONS_FORBIDDEN')
    elif role_id=='BID_DECISION':
        _validate_rows(output.get('decision_gates'), ['gate','status','evidence_refs','decision_effect'], 'DEPTH_BID_DECISION', blockers)
        if not output.get('recommendation'): blockers.append('DEPTH_BID_DECISION::RECOMMENDATION_REQUIRED')


def validate_role_output(role_id:str, output:dict, *, context=None)->dict:
    c=role_contract(role_id); output=output or {}; blockers=[]; warnings=[]
    m=_coverage_map(output,'mandatory_item_coverage')
    a=_coverage_map(output,'analysis_item_coverage')
    all_m=[x['id'] for x in c['mandatory_items']]
    all_a=[x['id'] for x in c['required_analysis_items']]
    na=[]; applicable=[]
    for iid in all_m:
        rec=m.get(iid)
        if not rec:
            blockers.append('DEPTH_MANDATORY_ITEM_MISSING:'+iid); continue
        if _is_na(rec):
            if not _good_refs(rec) or not str(rec.get('rationale') or '').strip(): blockers.append('DEPTH_NA_REQUIRES_EVIDENCE_AND_RATIONALE:'+iid)
            na.append(iid)
        elif _is_covered(rec):
            applicable.append(iid)
            if not _good_refs(rec): blockers.append('DEPTH_MANDATORY_ITEM_EVIDENCE_MISSING:'+iid)
            if not (rec.get('page_ids') or rec.get('page_id')): blockers.append('DEPTH_MANDATORY_ITEM_PAGE_BINDING_MISSING:'+iid)
        else:
            blockers.append('DEPTH_MANDATORY_ITEM_NOT_SATISFIED:'+iid)
    for iid in all_a:
        rec=a.get(iid)
        if not rec or not _is_covered(rec): blockers.append('DEPTH_REQUIRED_ANALYSIS_MISSING:'+iid); continue
        if not _good_refs(rec): blockers.append('DEPTH_REQUIRED_ANALYSIS_EVIDENCE_MISSING:'+iid)
    if role_id!='COVER' and not str(output.get('management_implication') or '').strip(): blockers.append('DEPTH_MANAGEMENT_IMPLICATION_REQUIRED')
    if not str(output.get('artifact_intent') or c.get('artifact_expectation') or '').strip(): blockers.append('DEPTH_ARTIFACT_EXPECTATION_NOT_BOUND')
    page_ids=output.get('page_ids') or []
    if isinstance(page_ids,str): page_ids=[page_ids]
    req=pages_required(role_id,not_applicable_item_ids=na,applicable_item_ids=applicable or None)
    if len(set(page_ids))<req['pages_required']:
        blockers.append(f'DEPTH_EXPANSION_REQUIRED::{role_id}::REQUIRED_{req["pages_required"]}_ACTUAL_{len(set(page_ids))}')
    metrics=output.get('render_strength_metrics') or {}
    floor=strength_floor()
    for key,fkey in [('body_min_pt','body_min_pt'),('table_body_min_pt','table_body_min_pt'),('label_min_pt','label_min_pt')]:
        if key in metrics:
            try:
                if float(metrics[key])+1e-6<float(floor[fkey]): blockers.append('DEPTH_STRENGTH_FLOOR_VIOLATION:'+key)
            except Exception: blockers.append('DEPTH_STRENGTH_METRIC_INVALID:'+key)
    _special_role_checks(role_id,output,context or {},blockers,warnings)
    return {'status':'PASS' if not blockers else 'BLOCKED','role_id':role_id,'blockers':sorted(set(blockers)),'warnings':sorted(set(warnings)),'pages_required':req,'mandatory_covered':sum(1 for iid in all_m if iid in m and (_is_covered(m[iid]) or _is_na(m[iid]))),'mandatory_total':len(all_m),'analysis_covered':sum(1 for iid in all_a if iid in a and _is_covered(a[iid])),'analysis_total':len(all_a),'page_ids':list(dict.fromkeys(page_ids))}


def validate_engagement_depth(role_outputs:dict, role_plan=None, *, context=None)->dict:
    contract=load_contract(); planned={}
    for p in role_plan or []:
        if isinstance(p,dict) and p.get('role_id'): planned[p['role_id']]=p
    results=[]; blockers=[]
    for c in contract['roles']:
        rid=c['canonical_id']; plan=planned.get(rid,{})
        if plan.get('applicability')=='NOT_APPLICABLE_WITH_EVIDENCE':
            if not plan.get('evidence_refs') or not plan.get('rationale'): blockers.append('DEPTH_ROLE_NA_WITHOUT_EVIDENCE:'+rid)
            continue
        r=validate_role_output(rid,(role_outputs or {}).get(rid) or {},context=context); results.append(r)
        blockers.extend(f'{rid}::{x}' for x in r['blockers'])
    return {'status':'PASS' if not blockers else 'BLOCKED','blockers':blockers,'roles':results,'role_count_evaluated':len(results),'mandatory_total':sum(x['mandatory_total'] for x in results),'mandatory_covered':sum(x['mandatory_covered'] for x in results),'analysis_total':sum(x['analysis_total'] for x in results),'analysis_covered':sum(x['analysis_covered'] for x in results),'computed_page_minimum':sum(x['pages_required']['pages_required'] for x in results)}


def validate_page_depth_bindings(pages, role_outputs)->dict:
    """Product-level bridge: structured depth items must be bound to actual page ids and visible fragments.

    The semantic master later verifies each visible fragment exists in rendered HTML. This function
    prevents a role ledger from claiming depth that is not assigned to a delivered page.
    """
    blockers=[]; page_by={str(p.get('page_id')):p for p in pages or [] if p.get('page_id')}
    for rid,out in (role_outputs or {}).items():
        cov=_coverage_map(out,'mandatory_item_coverage')
        for iid,rec in cov.items():
            if _is_na(rec): continue
            pids=rec.get('page_ids') or ([rec.get('page_id')] if rec.get('page_id') else [])
            frag=str(rec.get('visible_text_fragment') or '').strip()
            if not frag: blockers.append('DEPTH_PRODUCT_BINDING_VISIBLE_FRAGMENT_REQUIRED:'+iid)
            for pid in pids:
                p=page_by.get(str(pid))
                if not p: blockers.append('DEPTH_PRODUCT_BINDING_PAGE_NOT_DELIVERED:'+iid+':'+str(pid)); continue
                ids=set(p.get('depth_item_ids') or [])
                if iid not in ids: blockers.append('DEPTH_PRODUCT_BINDING_ITEM_NOT_ON_PAGE:'+iid+':'+str(pid))
                binds=p.get('depth_item_bindings') or []
                b=next((x for x in binds if isinstance(x,dict) and x.get('item_id')==iid),None)
                if not b or str(b.get('visible_text_fragment') or '').strip()!=frag:
                    blockers.append('DEPTH_PRODUCT_BINDING_FRAGMENT_MISMATCH:'+iid+':'+str(pid))
    return {'status':'PASS' if not blockers else 'BLOCKED','blockers':sorted(set(blockers)),'page_count':len(page_by)}
