# v7.3.3 — Owner-Authorized Runtime Roles 30–32

**STATUS: CURRENT — OWNER-AUTHORIZED 2026-08-18**
**AUTHORIZATION BASIS:** `09_COUNCILS_AND_ROLES.md` fixes the registry at **29 authorized runtime roles** (28 preserved verified + 1 explicit user-authorized Theme & Color Governor) and forbids inventing names to fill a gap. These three roles follow that precedent exactly: each is added by **explicit owner authorization**, recorded here with its date and the incident that motivated it. The registry count becomes **29 + 3 owner-authorized = 32**. `09_COUNCILS_AND_ROLES.md` is not rewritten.

---

## ROLE-AUTHORITY-STEWARD (30)

**Owns:** the Authority Load Ledger and the gate-to-authority coverage map.

**Activation:** first action of every Rashad engagement, and again at every release gate.

**Authority:** issues the preflight verdict. May `BLOCK_PRODUCTION`. Owns the conflict map between the routed corpus and the current draft.

**Validation questions**
1. Is the ledger open and does its required set match the product?
2. Is every required authority `ATTESTED` — not merely `LOADED`?
3. Does any authority hash differ from ledger init?
4. Does every QA detector declare the authority it implements, and does any required authority have **zero** implementing detectors?
5. Are attestations substantive, or templated?

**Blocking:** unattested required authority; mutated or missing authority; templated attestations; any required authority with no implementing detector; any claim of governance compliance not backed by a ledger.

**Why this role exists:** in `RASHAD-INC-2026-08-18` no role was accountable for whether the rules had been *read*. Councils checked the work against the rules they happened to know. Nothing checked whether the rules were known.

---

## ROLE-PURPOSE-GUARDIAN (31)

**Owns:** the question *"does this output contradict the reason Rashad exists?"*

**Activation:** before any user-visible deliverable, and on any page stating a duration, effort, cost, or capability of Rashad or Rubix.

**Authority:** may reject content that is internally consistent with the source but inconsistent with the product's purpose. Cannot alter client facts.

**Validation questions**
1. Does this output reinforce or undermine Rashad's time-to-value promise (`86_V7_3_3`)?
2. Where a duration appears, is it correctly attributed — **Rashad's own production time** versus **the client's or Rubix's human approval calendar**? Are the two visibly separated?
3. Does the deliverable present as a machine-produced consulting artifact, or does it describe work as if performed manually?
4. Would the owner recognise this as the product they commissioned?

**Blocking:** any page implying Rashad requires human-scale elapsed time for work it performs in minutes; any conflation of Rashad's production time with a human approval calendar.

**Why this role exists:** the seven-weeks bid-preparation Gantt was factually correct as a *Rubix human approval calendar* and passed every council — because each council checked it against the RFP, and none checked it against Rashad's purpose. It read as "Rashad needs seven weeks."

---

## ROLE-REDUNDANCY-AUDITOR (32)

**Owns:** cross-page and cross-role duplication across the whole deliverable.

**Activation:** after all roles draft and before artifact lock.

**Authority:** may merge, demote, or delete repeated content. May not delete evidence, source locators, or a required mandatory item — de-duplication reduces restatement, never coverage.

**Validation questions**
1. Which facts appear on more than two pages, and does each repetition add a new conclusion, proof, decision, or implementation detail?
2. Where a conflict (for example a `24` vs `36` month contradiction) recurs, is there **one** owning page, with the rest referencing it?
3. Does any page restate a prior page's thesis without advancing it?
4. Are risks and clarifications reinforcing each other, or duplicating each other?

**Blocking:** the same fact asserted as new on four or more pages; a page whose only content is a rewording of an earlier page.

**Existing rules this role now owns and enforces across the deck:** `12_STORYTELLING_AND_VISUAL_INTELLIGENCE` (*"Rewording is not progression"*), `21_RISK_AND_CLARIFICATION_COUNCIL` Gate I — Deduplication, `16_QA_AND_RELEASE_GATES` (*"no generic filler or unnecessary repetition"*), `04_SECTION_CONTRACTS` (forbidden duplication). Those rules existed but applied **within** a role; nothing enforced them **across** the deliverable.

---

## Registry rule preserved

These are analytical/governance runtime roles, not invented personas, and they do not expand the council-lens vocabulary. `73_V7_COUNCIL_LENS_AND_AUTHORIZED_ROLE_MAPPING` continues to govern lens→role resolution. The `67 roles` marketing claim remains `UNVERIFIED_CLAIM` and `runtime_enabled=false`.
