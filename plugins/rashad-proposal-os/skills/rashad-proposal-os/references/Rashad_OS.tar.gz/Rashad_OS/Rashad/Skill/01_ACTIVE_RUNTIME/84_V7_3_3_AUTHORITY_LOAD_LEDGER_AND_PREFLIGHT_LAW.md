# v7.3.3 — Authority Load Ledger & Preflight Law

**STATUS: CURRENT — OWNER-AUTHORIZED 2026-08-18 — BLOCKING**
**ROOT INCIDENT:** `RASHAD-INC-2026-08-18` — 69 authorities routed by the manifest; **2 read before production**. Every defect in that engagement (raster-only PPTX presented as a deck, co-brand order inverted, Western numerals in Arabic client-facing output, collision QA never instrumented, 93-family artifact catalogue unused, stale table of contents) traces to this single cause.
**EXECUTABLE BINDING:** `Rashad/Brain/runtime/brain/authority_preflight.py`

## 1. Why this law is executable and not declarative

The corpus already instructed, in plain language, that the manifest be loaded as the sole routing authority. That instruction was read and not executed. **A prose restatement of a prose rule that already failed cannot be the remedy.** `ACTIVE_AUTHORITY_MANIFEST.json` states the governing principle directly: *"No finding is closed by prose presence alone."*

This law therefore adds no new principle. It extends an existing Rashad doctrine — `Registered ≠ Routed ≠ Executed` — one level upward, from page elements to the authorities themselves:

| Layer | Existing rule | Source |
|---|---|---|
| Page element | `required=true AND actual_test_count=0 → FAIL_NOT_INSTRUMENTED` | `61_REQUIRED_INSTRUMENTATION_AND_NO_VACUOUS_PASS` |
| **Authority (new)** | `required=true AND attested=false → BLOCK_PRODUCTION` | this law |

## 2. The unit of proof is ATTESTATION, not LOADED

Opening a file costs nothing and proves nothing. A session can `cat` sixty-nine files and internalise none of them. Ledger states are therefore:

- `NOT_LOADED` — default.
- `LOADED` — bytes read. **Carries no authority and satisfies no gate.**
- `ATTESTED` — a written binding statement exists: *what this authority binds, and which page, artifact, or decision it governs in this engagement.*

Only `ATTESTED` satisfies the gate. Attestation is cheap to produce honestly (one line per authority) and expensive to fake, which is the required asymmetry.

## 3. Ledger contract

Ledger: `.rashad/AUTHORITY_LOAD_LEDGER.json`, schema `RASHAD_AUTHORITY_LOAD_LEDGER_V7_3_3`.

Per authority: `path · sha256 · exists · bytes · state · attestation · governs · attested_at`.

The `sha256` is captured at ledger init and re-verified at every gate. An authority mutated after attestation raises `AUTHORITY_MUTATED_SINCE_ATTESTATION`. An authority absent from the corpus raises `AUTHORITY_MISSING_FROM_CORPUS` — it is never silently dropped from the required set.

## 4. Preflight is the first action of the engagement

`authority_preflight.py --init <PRODUCT>` runs **before ingestion, before analysis, before any production**. The coverage line is emitted to the owner before work begins:

```
AUTHORITY LEDGER :: product=RFP_SUMMARY_ARTIFACT attested=69/69 (100%) status=PASS
```

Surfacing coverage to the owner is itself a control. In the root incident the owner had no way to see `2/69` until the artifact was already delivered.

## 5. Enforcement by stage

| Stage | Incomplete ledger |
|---|---|
| `USER_VISIBLE_ARTIFACT` · `RELEASE` · `HANDOFF` | **`BLOCK_PRODUCTION`** |
| `ADVISORY` · `INTERNAL_DRAFT` · `ANALYSIS` | `PROCEED_WITH_COVERAGE_BANNER` — output carries `AUTHORITY_COVERAGE_INCOMPLETE` naming the unattested files |

`CERTIFIED_FOR_HANDOFF` is unreachable while any required authority is unattested. The exact-artifact handoff guard (`81_V7_2_1`) and delivered-file binding QA (`84_V7_2_1`) must call `preflight("HANDOFF")` and propagate `BLOCK_HANDOFF` on any non-`PASS`.

## 6. Anti-gaming is part of the law

A control that is cheap to fake will be faked. The preflight independently blocks on:

- `ATTESTATION_TOO_THIN` — under 60 characters.
- `ATTESTATION_IS_FILENAME_ECHO` — restating the filename.
- `ATTESTATION_TEMPLATED` — more than two byte-identical attestations.
- `ATTESTATION_TEMPLATED_PREFIX` — over 60% of attestations sharing a 40-character prefix.

These exist because the failure they guard against is the failure that already occurred: satisfying the letter of a governance step while skipping its substance.

## 7. Scoped required sets

`01_ACTIVE_RUNTIME/authority_required_sets_v7_3_3.json` binds the mandatory set per product. **An unbounded requirement gets silently trimmed by the producer; a scoped requirement gets followed.** The root incident included an unstated, unilateral budget decision to read "the spine and infer the rest."

Client-visible artifact paths are `mode: ALL` — no scoping-down, because that is exactly the shortcut being remedied. Advisory paths carry a genuine subset.

## 8. Producer may not self-certify coverage

Consistent with Producer ≠ Judge: the producing session may write the ledger but may not declare its own coverage sufficient. `ROLE-AUTHORITY-STEWARD` (`85_V7_3_3`) owns the gate verdict. Where an independent reviewer is unavailable, the mechanical preflight result stands as the verdict and its output must be surfaced verbatim — never paraphrased as "governance checked."

## 9. Non-destructive

This law adds routing and gates only. It mutates no protected prompt, scope, mapping, skeleton, or brand knowledge.
