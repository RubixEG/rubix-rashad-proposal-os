from __future__ import annotations
import json
from pathlib import Path
from .utils import load

HERE=Path(__file__).resolve().parent
CONTRACT_PATH=HERE/'contracts'/'cognitive_councils_v1.json'

def _contract():
    d=json.loads(CONTRACT_PATH.read_text(encoding='utf-8'))
    if d.get('architecture')!='DECISION_DOMAIN_COUNCILS_OVER_AUTHORIZED_V7_LENSES':
        raise RuntimeError('COGNITIVE_COUNCIL_CONTRACT_INVALID')
    return d

def route(role:str, critical=True, rendered=False, deck=False, final_release=False):
    d=_contract(); ordered=[]
    def add(x):
        if x not in ordered: ordered.append(x)
    # Sentinels are permanent on critical work. Epistemic truth is also on all analytical roles.
    if critical:
        for x in d.get('always_on_critical',[]): add(x)
    elif role not in ('COVER','TABLE_OF_CONTENTS'):
        add('C03_EPISTEMIC_TRUTH')
    # Trigger by the canonical role id or special runtime trigger.
    for c in d.get('councils',[]):
        ts=set(c.get('triggers') or [])
        if role in ts: add(c['id'])
        if '*ANALYTICAL*' in ts and role not in ('COVER','TABLE_OF_CONTENTS'): add(c['id'])
        if '*RENDERED_ANALYTICAL*' in ts and rendered and role not in ('COVER','TABLE_OF_CONTENTS'): add(c['id'])
        if '*RENDERED*' in ts and rendered: add(c['id'])
        if '*DECK*' in ts and deck: add(c['id'])
        if '*FINAL_RELEASE*' in ts and final_release: add(c['id'])
    # Final meta sentinel remains last for coverage/groupthink review.
    if critical:
        if 'C15_META_COGNITION_INTEGRITY' in ordered:
            ordered.remove('C15_META_COGNITION_INTEGRITY')
        ordered.append('C15_META_COGNITION_INTEGRITY')
    return ordered

def validate_route(route_ids, contracts_path=None):
    d=_contract() if contracts_path is None else load(contracts_path)
    known={x['id'] for x in d['councils']}; missing=[x for x in route_ids if x not in known]
    return {'status':'PASS' if not missing else 'FAIL','missing':missing,'route':route_ids,'contract_sha256':__import__('hashlib').sha256(CONTRACT_PATH.read_bytes()).hexdigest()}

def natural_trigger_coverage(role_ids):
    d=_contract(); seen=set()
    for r in role_ids:
        seen.update(route(r,critical=True,rendered=True,deck=True,final_release=True))
    known={x['id'] for x in d['councils']}
    return {'status':'PASS' if seen==known else 'FAIL','seen':sorted(seen),'missing':sorted(known-seen),'count':len(seen),'total':len(known)}
