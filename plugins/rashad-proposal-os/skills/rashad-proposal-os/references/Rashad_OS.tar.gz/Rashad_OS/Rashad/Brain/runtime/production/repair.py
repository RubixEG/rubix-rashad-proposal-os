# -*- coding: utf-8 -*-
"""Bounded fit-repair loop (71_AUTO_REPAIR_AND_PAGE_SPLIT_POLICY, ladder steps 1-3).

Measures the real render, and where a page still collides or escapes its region,
steps that PAGE ONLY down a micro-spacing ladder and re-measures. Typography is
never reduced. A page that still fails at the last rung is reported as
CANNOT_RENDER_WITHOUT_SEMANTIC_LOSS and returned upstream for a page split —
it is not clipped, hidden or shrunk.
"""
import json, pathlib, subprocess, sys, datetime

BUILD = pathlib.Path(__file__).parent
EV = BUILD / "evidence"
MAXLVL = 3


def _run(mod):
    r = subprocess.run([sys.executable, str(BUILD / mod)], capture_output=True, text=True,
                       cwd=str(BUILD))
    if r.returncode != 0:
        print(r.stdout[-2000:], r.stderr[-2000:])
        raise SystemExit(f"{mod} failed")
    return r.stdout


def failing(report):
    out = {}
    for pg, gs in report["page_gates"].items():
        bad = [g for g in ("G03_REGION_CONTAINMENT", "G04_COLLISION", "G02_SAFE_AREA",
                           "G01_CANVAS_BOUNDS")
               if isinstance(gs.get(g), dict) and gs[g]["status"] == "FAIL"]
        if bad:
            out[pg] = bad
    return out


def main():
    """Sweep the ladder once per rung and LOCK each page at the lowest rung that
    resolves it. A rung that does not resolve a page is discarded for that page —
    repair never leaves a page worse than it started."""
    locked, history = {}, []
    (BUILD / "repair_levels.json").write_text("{}", encoding="utf-8")
    _run("build.py"); _run("extract.py"); _run("gates.py")
    rep = json.loads((EV / "gate_report.json").read_text(encoding="utf-8"))
    pid_of = {pg: json.loads((BUILD / "scene" / f"{pg}.json").read_text(encoding="utf-8"))["page"]["page-id"]
              for pg in rep["page_gates"]}
    open_pages = set(failing(rep))
    history.append({"rung": 0, "failing": sorted(open_pages), "blockers": rep["blocker_count"]})
    print(f"rung 0: fit-failing = {len(open_pages)}  blockers = {rep['blocker_count']}")
    for lvl in range(1, MAXLVL + 1):
        if not open_pages:
            break
        trial = dict(locked)
        for pg in open_pages:
            trial[pid_of[pg]] = lvl
        (BUILD / "repair_levels.json").write_text(json.dumps(trial), encoding="utf-8")
        _run("build.py"); _run("extract.py"); _run("gates.py")
        rep = json.loads((EV / "gate_report.json").read_text(encoding="utf-8"))
        still = set(failing(rep))
        resolved = open_pages - still
        for pg in resolved:
            locked[pid_of[pg]] = lvl
        open_pages = open_pages & still
        history.append({"rung": lvl, "resolved": sorted(resolved),
                        "still_failing": sorted(open_pages), "blockers": rep["blocker_count"]})
        print(f"rung {lvl}: resolved {len(resolved)}, still failing {len(open_pages)}")
    (BUILD / "repair_levels.json").write_text(json.dumps(locked), encoding="utf-8")
    _run("build.py"); _run("extract.py"); _run("gates.py")
    rep = json.loads((EV / "gate_report.json").read_text(encoding="utf-8"))
    unresolved = sorted(failing(rep))
    rec = {"schema": "RASHAD_REPAIR_HISTORY_V7_3_3",
           "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
           "ladder": "71_AUTO_REPAIR steps 1-3 (micro-spacing only; typography untouched)",
           "sweep": history,
           "locked_repair_levels": locked,
           "final_blockers": rep["blocker_count"],
           "unresolved": unresolved,
           "unresolved_disposition": (
               "CANNOT_RENDER_WITHOUT_SEMANTIC_LOSS — returned upstream for role expansion "
               "(page split); not clipped, hidden or type-reduced" if unresolved else "NONE")}
    (EV / "repair_history.json").write_text(json.dumps(rec, ensure_ascii=False, indent=1),
                                            encoding="utf-8")
    print("final blockers:", rep["blocker_count"], "unresolved:", unresolved)
    return


def _old_main():
    levels = {}
    history = []
    for it in range(MAXLVL + 1):
        _run("build.py"); _run("extract.py"); _run("gates.py")
        rep = json.loads((EV / "gate_report.json").read_text(encoding="utf-8"))
        fails = failing(rep)
        history.append({"iteration": it, "repair_levels": dict(levels),
                        "failing_pages": {k: v for k, v in fails.items()},
                        "blockers": rep["blocker_count"]})
        print(f"iter {it}: fit-failing pages = {len(fails)}  total blockers = {rep['blocker_count']}")
        if not fails:
            break
        if it == MAXLVL:
            break
        # step the failing pages down one rung
        for pg in fails:
            pid = rep["page_gates"][pg].get("G00_INSTRUMENTATION", {})
            levels[pg] = min(MAXLVL, levels.get(pg, 0) + 1)
        # write the level map keyed by page-id for compose
        pid_map = {}
        for pg, lv in levels.items():
            sg = json.loads((BUILD / "scene" / f"{pg}.json").read_text(encoding="utf-8"))
            pid_map[sg["page"]["page-id"]] = lv
        (BUILD / "repair_levels.json").write_text(json.dumps(pid_map), encoding="utf-8")
    unresolved = [p for p in failing(json.loads((EV / "gate_report.json").read_text(encoding="utf-8")))]
    rec = {"schema": "RASHAD_REPAIR_HISTORY_V7_3_3",
           "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
           "ladder": "71_AUTO_REPAIR steps 1-3 (micro-spacing only; typography untouched)",
           "iterations": history,
           "final_repair_levels": levels,
           "unresolved": unresolved,
           "unresolved_disposition": (
               "CANNOT_RENDER_WITHOUT_SEMANTIC_LOSS — returned upstream for role expansion "
               "(page split) rather than clipping or type reduction" if unresolved else "NONE")}
    (EV / "repair_history.json").write_text(json.dumps(rec, ensure_ascii=False, indent=1),
                                            encoding="utf-8")
    print("unresolved:", unresolved)


if __name__ == "__main__":
    main()
