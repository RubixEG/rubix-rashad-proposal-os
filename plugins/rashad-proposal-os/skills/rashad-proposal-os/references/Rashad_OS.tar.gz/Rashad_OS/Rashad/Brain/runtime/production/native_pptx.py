# -*- coding: utf-8 -*-
"""Native editable PPTX adapter.

83_V7_3_2 clause 12: a client-visible PPTX may be a raster visual mirror ONLY when
explicitly declared; where native editable PPTX is requested and the native
reconstruction organ is unavailable it must fail closed with
NATIVE_EDITABLE_PPTX_CAPABILITY_NOT_IMPLEMENTED. The owner requested editable
slides, so this module IS that organ.

60_CANONICAL_PAGE_SCENE_GRAPH: this adapter consumes the SAME resolved scene graph
the instrumented master was measured from. It may not reorder nodes, change the
artifact family, recompute hierarchy, or invent a fallback layout.
45_VISUAL_FIDELITY_CONTRACT: editable PowerPoint may use a different native object
model but must remain a projection of the same approved geometry.
"""
import base64, io, json, pathlib, re, hashlib
from pptx import Presentation
from pptx.util import Emu, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.oxml.ns import qn
import copy

BUILD = pathlib.Path(__file__).parent
SG = BUILD / "scene"
OUT = BUILD / "out"
EV = BUILD / "evidence"
PXE = 7620                      # EMU per CSS px on a 1600x900 -> 13.333x7.5in canvas
FONT = "IBM Plex Sans Arabic"


def E(px):
    return Emu(int(round(px * PXE)))


def rgb(h):
    h = (h or "#000000").lstrip("#")
    return RGBColor(int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))


def _css_rgb(v):
    m = re.match(r"rgba?\(([^)]+)\)", v or "")
    if not m:
        return v if (v or "").startswith("#") else None
    p = [float(x) for x in m.group(1).split(",")]
    if len(p) > 3 and p[3] < 0.03:
        return None
    return "#%02X%02X%02X" % (int(p[0]), int(p[1]), int(p[2]))


def _set_font(run, size_pt, bold, color, name=FONT):
    f = run.font
    f.size = Pt(size_pt)
    f.bold = bold
    f.color.rgb = rgb(color)
    f.name = name
    # complex-script typeface — Arabic shaping in PowerPoint reads <a:cs>, not <a:latin>
    rPr = run._r.get_or_add_rPr()
    for tag in ("a:cs", "a:ea"):
        el = rPr.find(qn(tag))
        if el is None:
            el = rPr.makeelement(qn(tag), {})
            rPr.append(el)
        el.set("typeface", name)


def _rtl(par, align="r"):
    pPr = par._p.get_or_add_pPr()
    pPr.set("rtl", "1")
    pPr.set("algn", {"r": "r", "l": "l", "ctr": "ctr", "just": "just"}[align])


def _textbox(slide, box, text, pt, weight, color, align, dirn, lh=None,
             anchor=MSO_ANCHOR.MIDDLE, pad=1.5, runs=None):
    x0, y0 = max(0.0, box["x"] - pad), max(0.0, box["y"] - pad)
    w0 = min(1600.0 - x0, box["w"] + 2 * pad)
    h0 = min(900.0 - y0, box["h"] + 2 * pad)
    tb = slide.shapes.add_textbox(E(x0), E(y0), E(w0), E(h0))
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    tf.vertical_anchor = anchor
    p = tf.paragraphs[0]
    a = "r" if dirn == "rtl" else "l"
    if align == "center":
        a = "ctr"
    elif align == "left":
        a = "l"
    elif align == "right":
        a = "r"
    _rtl(p, a) if dirn == "rtl" else setattr(
        p, "alignment", {"l": PP_ALIGN.LEFT, "r": PP_ALIGN.RIGHT, "ctr": PP_ALIGN.CENTER}[a])
    if lh:
        p.line_spacing = lh
    if runs:
        for rr in runs:
            if not rr.get("s"):
                continue
            run = p.add_run()
            run.text = rr["s"]
            _set_font(run, rr.get("pt", pt), str(rr.get("weight", weight)) in
                      ("600", "700", "bold", "800"), rr.get("color", color))
    else:
        r = p.add_run()
        r.text = text
        _set_font(r, pt, str(weight) in ("600", "700", "bold", "800"), color)
    return tb


def _rect(slide, box, fill, line=None, lw=1.0, radius=0):
    shp = slide.shapes.add_shape(
        MSO_SHAPE.ROUNDED_RECTANGLE if radius >= 3 else MSO_SHAPE.RECTANGLE,
        E(box["x"]), E(box["y"]), E(box["w"]), E(box["h"]))
    if radius >= 3 and box["h"] > 0:
        adj = min(0.5, radius / min(box["w"], box["h"]))
        try:
            shp.adjustments[0] = adj
        except Exception:
            pass
    if fill:
        shp.fill.solid(); shp.fill.fore_color.rgb = rgb(fill)
    else:
        shp.fill.background()
    if line:
        shp.line.color.rgb = rgb(line); shp.line.width = Pt(lw)
    else:
        shp.line.fill.background()
    shp.shadow.inherit = False
    return shp


def _line(slide, x1, y1, x2, y2, color, lw):
    from pptx.enum.shapes import MSO_CONNECTOR
    c = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, E(x1), E(y1), E(x2), E(y2))
    c.line.color.rgb = rgb(color); c.line.width = Pt(max(0.5, lw * 0.75))
    return c


def _freeform(slide, pts, color, lw, dash=None):
    from pptx.util import Emu as _E
    b = slide.shapes.build_freeform(E(pts[0][0]), E(pts[0][1]), scale=1.0)
    b.add_line_segments([(E(x), E(y)) for x, y in pts[1:]], close=False)
    shp = b.convert_to_shape()
    shp.fill.background()
    shp.line.color.rgb = rgb(color); shp.line.width = Pt(max(0.5, lw * 0.75))
    if dash and dash not in ("none", ""):
        shp.line.dash_style = 4       # DASH
    shp.shadow.inherit = False
    return shp


SKIP_CLS = {"pad", "hdr", "headtext", "body", "foot", "col", "row", "grow", "g", "g2",
            "g3", "g4", "g5", "gfill", "fill", "vwrap", "cvid", "cvmid", "cvfoot",
            "railwrap", "slide", "cover", "cvhero"}


def build(deck_name="Rashad_RFP_Summary_PR-IC-2026-037_NATIVE.pptx", order=None):
    prs = Presentation()
    prs.slide_width = Emu(12192000)
    prs.slide_height = Emu(6858000)
    blank = prs.slide_layouts[6]
    files = order or sorted(SG.glob("*.json"))
    stats = {"slides": 0, "shapes": 0, "text": 0, "pictures": 0, "vectors": 0}
    for f in files:
        d = json.loads(pathlib.Path(f).read_text(encoding="utf-8"))
        s = prs.slides.add_slide(blank)
        bg = s.background
        bg.fill.solid(); bg.fill.fore_color.rgb = rgb("#FFFFFF")
        # ---- HTML layer, in document order (= paint order) ----
        for el in d["els"]:
            box = el["box"]
            if box["w"] < 0.5 or box["h"] < 0.5:
                continue
            cls = set((el.get("cls") or "").split())
            p = el.get("paint")
            if p:
                fill = p.get("fill") if p.get("fillA", 0) > 0.02 else None
                bw = p.get("bw") or [0, 0, 0, 0]
                uniform = len(set(bw)) == 1 and bw[0] > 0.4
                if fill or uniform:
                    _rect(s, box, fill, p.get("bc") if uniform else None,
                          bw[0] if uniform else 1.0, p.get("radius", 0))
                    stats["shapes"] += 1
                if not uniform:
                    t, r_, b_, l_ = bw
                    if t > 0.4:
                        _line(s, box["x"], box["y"], box["x"] + box["w"], box["y"], p["bc"], t); stats["vectors"] += 1
                    if b_ > 0.4:
                        _line(s, box["x"], box["y"] + box["h"], box["x"] + box["w"], box["y"] + box["h"], p["bc"], b_); stats["vectors"] += 1
                    if l_ > 0.4:
                        _line(s, box["x"], box["y"], box["x"], box["y"] + box["h"], p["bc"], l_); stats["vectors"] += 1
                    if r_ > 0.4:
                        _line(s, box["x"] + box["w"], box["y"], box["x"] + box["w"], box["y"] + box["h"], p["bc"], r_); stats["vectors"] += 1
            if el.get("tag") == "img" and el.get("imgFull", "").startswith("data:"):
                head, b64 = el["imgFull"].split(",", 1)
                s.shapes.add_picture(io.BytesIO(base64.b64decode(b64)),
                                     E(box["x"]), E(box["y"]), E(box["w"]), E(box["h"]))
                stats["pictures"] += 1
            t = el.get("text")
            if t and t["s"]:
                txt = t["full"] if (t.get("block") or t.get("mixed")) and t["full"] else t["s"]
                _textbox(s, box, txt, t["pt"], t["weight"], t["color"],
                         t.get("align"), t.get("dir"),
                         lh=(t["lh"] / t["px"]) if t.get("px") else None,
                         runs=t.get("runs"))
                stats["text"] += 1
        # ---- vector layer ----
        for sv in d.get("svg", []):
            for sh in sv["shapes"]:
                st = _css_rgb(sh.get("stroke"))
                fl = _css_rgb(sh.get("fill"))
                if sh["t"] == "rect" and fl:
                    _rect(s, sh["box"], fl, st, sh.get("sw", 0), sh.get("rx", 0)); stats["vectors"] += 1
                elif sh["t"] == "circle" and fl:
                    b = sh["box"]
                    shp = s.shapes.add_shape(MSO_SHAPE.OVAL, E(b["x"]), E(b["y"]), E(b["w"]), E(b["h"]))
                    shp.fill.solid(); shp.fill.fore_color.rgb = rgb(fl); shp.line.fill.background()
                    shp.shadow.inherit = False
                    stats["vectors"] += 1
                elif sh["t"] == "line" and sh.get("p") and st:
                    _line(s, *sh["p"], st, sh.get("sw", 1)); stats["vectors"] += 1
                elif sh["t"] == "path" and sh.get("poly") and st:
                    _freeform(s, sh["poly"], st, sh.get("sw", 1), sh.get("dash")); stats["vectors"] += 1
                elif sh["t"] == "text" and sh.get("s"):
                    b = sh["box"]
                    pad_x = 6
                    box = {"x": b["x"] - pad_x, "y": b["y"] - 3,
                           "w": b["w"] + 2 * pad_x, "h": b["h"] + 6}
                    al = {"start": "right", "middle": "center", "end": "left"}.get(
                        sh.get("anchor", "start"), "right")
                    _textbox(s, box, sh["s"], sh.get("pt", 14), sh.get("weight", "400"),
                             _css_rgb(sh.get("color")) or "#1A1A1A", al, "rtl")
                    stats["text"] += 1
        stats["slides"] += 1
    OUT.mkdir(exist_ok=True)
    path = OUT / deck_name
    prs.save(str(path))
    sha = hashlib.sha256(path.read_bytes()).hexdigest()
    stats.update({"file": path.name, "sha256": sha, "bytes": path.stat().st_size,
                  "editability_class": "FULLY_NATIVE",
                  "raster_pictures": stats["pictures"],
                  "note": "Every analytical object is a native PowerPoint shape or text "
                          "frame. Pictures are the verified brand mark and the cover hero "
                          "only (14_IMAGE_GENERATION_POLICY: native/hybrid analytical core)."})
    (EV / "native_pptx_build.json").write_text(json.dumps(stats, ensure_ascii=False, indent=1),
                                               encoding="utf-8")
    print(json.dumps(stats, ensure_ascii=False))
    return path


if __name__ == "__main__":
    build()
