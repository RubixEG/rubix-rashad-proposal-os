# -*- coding: utf-8 -*-
"""Rashad v7.3.2 — Rubix light-first consulting artifact design system (RTL).
Canvas 1600x900 CSS px -> 960x540 pt (PPT 16:9). Scale px*0.6 = pt.
Strength floor (BLOCKING): title>=24pt(40px), body>=16pt(26.7px),
table body>=14pt(23.3px), label>=12pt(20px), source>=10pt(16.7px).
Palette authority: 08_BRAND_CURRENT/RUBIX_ARTIFACT_PALETTE.md
"""
import base64, os, pathlib

BUILD = pathlib.Path(__file__).parent
FONTS = BUILD / "fonts"

C = dict(
    white="#FFFFFF", warm="#FAF9FA",
    mag8="#F8EDF3", pur8="#F5EEF5", blu8="#F0F4FA", tea8="#EBF4F5",
    org8="#FEF2EE", red8="#FBEEF0", nav8="#EDEFF4",
    magenta="#A42365", mag15="#F1DEE8",
    purple="#822B83", pur15="#ECDFEC",
    teal="#077381", tea15="#DAEAEC",
    blue="#407ABE", blu15="#E2EBF5",
    orange="#F15A26", org15="#FDE6DE",
    red="#D32A45", red15="#F8DFE3",
    navy="#203B70", nav15="#DEE2EA",
    ink="#1A1A1A", ink2="#3D3D3D", muted="#6F6F73", hair="#E6E2E4",
)


def _b64(p):
    return base64.b64encode(open(p, "rb").read()).decode()


def font_faces():
    out = []
    for w in (300, 400, 500, 600, 700):
        for sub in ("arabic", "latin"):
            f = FONTS / f"ibm-plex-sans-arabic-{sub}-{w}-normal.woff2"
            if not f.exists():
                continue
            rng = ("U+0600-06FF,U+0750-077F,U+0870-088E,U+08A0-08FF,U+FB50-FDFF,U+FE70-FEFF,U+200F,U+2010-2011"
                   if sub == "arabic" else "U+0000-00FF,U+0131,U+2000-206F,U+2074,U+20AC,U+2122,U+2212")
            out.append(
                "@font-face{font-family:'PlexAr';font-style:normal;font-weight:%d;"
                "src:url(data:font/woff2;base64,%s) format('woff2');unicode-range:%s;font-display:block}"
                % (w, _b64(f), rng))
    return "".join(out)


def asset_uri(name):
    p = BUILD / name
    return "data:image/png;base64," + _b64(p)


BASE_CSS = """
*{margin:0;padding:0;box-sizing:border-box}
html,body{width:1600px;height:900px;overflow:hidden}
body{font-family:'PlexAr',sans-serif;background:#fff;color:%(ink)s;
 direction:rtl;text-align:right;-webkit-font-smoothing:antialiased;
 font-feature-settings:"liga" 1,"calt" 1;text-rendering:geometricPrecision}
.slide{position:relative;width:1600px;height:900px;overflow:hidden;background:%(white)s}
.ltr{direction:ltr;unicode-bidi:isolate;display:inline-block}
.num{direction:ltr;unicode-bidi:isolate;display:inline-block;font-variant-numeric:tabular-nums}

/* ---------- page frame ---------- */
.pad{position:absolute;inset:0;padding:28px 58px 29px 58px;display:flex;flex-direction:column}
.hdr{display:flex;align-items:flex-start;gap:40px;flex:none;position:relative;min-height:78px}
.headtext{flex:1 1 auto;min-width:0;padding-left:210px}
/* Co-brand cluster — physical TOP-LEFT (owner override 2026-08-20).
   Rubix far-left inside the cluster; NEVER mirrored by RTL (16_COBRAND / 64_NO_MIRROR). */
.cobrand{position:absolute;left:0;top:0;display:flex;flex-direction:row;align-items:center;
 gap:13px;direction:ltr;height:74px}
.cobrand .mark{flex:none;object-fit:contain}
/* height 74px -> alpha-measured visible wordmark 36.6px = 0.305in on a 7.5in slide,
   above the 0.28in floor in 29_PRODUCTION_EXECUTION_FIREWALL v2.2 logo geometry gate. */
.cobrand .rubix{height:74px;width:auto}
.cobrand .sep{width:1px;height:26px;background:%(hair)s;flex:none}
.cobrand .client{height:74px;width:auto}
.cobrand .client.slot{display:none}
.cobrand:not(:has(.client:not(.slot))) .sep{display:none}
.kick{font-size:20px;font-weight:600;letter-spacing:.02em;color:%(magenta)s;line-height:1.2}
.kick .ch{color:%(muted)s;font-weight:500}
.h1{font-size:43px;font-weight:600;line-height:1.18;color:%(ink)s;letter-spacing:-.005em;margin-top:7px;max-width:1150px}
.h1 em{font-style:normal;color:%(magenta)s}
.pgno{font-size:18px;color:%(muted)s;font-weight:500;white-space:nowrap;flex:none;direction:ltr}
.rule{height:3px;background:%(magenta)s;width:96px;margin:12px 0 0 0;flex:none}

/* answer-first thesis bar */
.thesis{margin-top:14px;flex:none;display:flex;gap:16px;align-items:flex-start;
 background:%(mag8)s;border-right:5px solid %(magenta)s;padding:10px 18px;border-radius:3px}
.thesis .lab{font-size:20px;font-weight:700;color:%(magenta)s;white-space:nowrap;padding-top:2px}
.thesis .txt{font-size:27px;font-weight:500;line-height:1.36;color:%(ink)s}
.thesis.risk{background:%(red8)s;border-color:%(red)s}
.thesis.risk .lab{color:%(red)s}
.thesis.warn{background:%(org8)s;border-color:%(orange)s}
.thesis.warn .lab{color:%(orange)s}
.thesis.ok{background:%(tea8)s;border-color:%(teal)s}
.thesis.ok .lab{color:%(teal)s}

.body{flex:1 1 auto;margin-top:11px;min-height:0;display:flex;flex-direction:column}
.foot{flex:none;display:flex;flex-direction:row-reverse;justify-content:space-between;
 align-items:flex-end;gap:34px;border-top:1px solid %(hair)s;padding-top:7px;margin-top:8px}
.src{font-size:17px;color:%(muted)s;line-height:1.35;max-width:1290px;text-align:right}
.src b{color:%(ink2)s;font-weight:600}

.body.banner{margin-top:16px}
.thesis.bottom{margin-top:14px}

/* ---------- primitives ---------- */
.chip{display:inline-flex;align-items:center;gap:8px;font-size:20px;font-weight:600;
 padding:5px 13px;border-radius:100px;line-height:1.3;white-space:nowrap}
.c-mag{background:%(mag15)s;color:%(magenta)s}
.c-pur{background:%(pur15)s;color:%(purple)s}
.c-tea{background:%(tea15)s;color:%(teal)s}
.c-blu{background:%(blu15)s;color:%(blue)s}
.c-org{background:%(org15)s;color:%(orange)s}
.c-red{background:%(red15)s;color:%(red)s}
.c-nav{background:%(nav15)s;color:%(navy)s}
.c-gry{background:#EFEDEE;color:%(ink2)s}

.card{background:%(warm)s;border:1px solid %(hair)s;border-radius:6px;padding:11px 17px}
.card.tint-mag{background:%(mag8)s;border-color:%(mag15)s}
.card.tint-tea{background:%(tea8)s;border-color:%(tea15)s}
.card.tint-blu{background:%(blu8)s;border-color:%(blu15)s}
.card.tint-pur{background:%(pur8)s;border-color:%(pur15)s}
.card.tint-org{background:%(org8)s;border-color:%(org15)s}
.card.tint-red{background:%(red8)s;border-color:%(red15)s}
.card.tint-nav{background:%(nav8)s;border-color:%(nav15)s}
.card .ttl{font-size:24px;font-weight:600;color:%(ink)s;line-height:1.24}
.card .sub{font-size:27px;font-weight:400;color:%(ink2)s;line-height:1.26;margin-top:4px}

.lab{font-size:20px;font-weight:600;color:%(muted)s;letter-spacing:.01em}
.metric{font-size:56px;font-weight:600;line-height:1;color:%(ink)s;letter-spacing:-.02em}
.metric.sm{font-size:44px}
.metric .u{font-size:24px;font-weight:500;color:%(ink2)s;margin-inline-start:6px}
.p{font-size:27px;line-height:1.28;color:%(ink2)s}
.p.sm{font-size:27px}
.p.ink{color:%(ink)s}
strong{font-weight:600;color:%(ink)s}

/* table */
table.t{width:100%%;border-collapse:collapse;table-layout:fixed}
table.t th{font-size:20px;font-weight:600;color:%(muted)s;text-align:right;padding:0 14px 10px 14px;
 border-bottom:2px solid %(ink)s;vertical-align:bottom;line-height:1.25}
table.t td{font-size:24px;color:%(ink2)s;padding:9px 13px;border-bottom:1px solid %(hair)s;
 vertical-align:top;line-height:1.35}
table.t td.k{color:%(ink)s;font-weight:600}
table.t tr.alt td{background:%(warm)s}
table.t td.c,table.t th.c{text-align:center}
table.t.dense td{font-size:24px;padding:9px 12px}
table.t.tight td{font-size:24px;padding:5px 11px;line-height:1.24}
table.t.tight th{font-size:20px;padding-bottom:7px}
table.t.dense th{font-size:20px}

.dot{display:inline-block;width:12px;height:12px;border-radius:50%%;vertical-align:middle;margin-inline-end:8px}

/* grids */
.g{display:grid;gap:11px}
.g2{grid-template-columns:repeat(2,1fr)}
.g3{grid-template-columns:repeat(3,1fr)}
.g4{grid-template-columns:repeat(4,1fr)}
.g5{grid-template-columns:repeat(5,1fr)}
.fill{height:100%%}
.col{display:flex;flex-direction:column;gap:10px}
.row{display:flex;gap:12px}
.grow{flex:1 1 auto;min-height:0;min-width:0}
.gfill{flex:1 1 auto;min-height:0;grid-auto-rows:1fr;align-content:stretch}

.draftmark{position:absolute;left:0;top:0;width:100%%;height:100%%;pointer-events:none;z-index:9}
.draftmark i{position:absolute;left:50%%;top:0;transform:translateX(-50%%);
 background:%(red)s;color:#fff;font-size:17px;font-weight:700;letter-spacing:.12em;
 padding:3px 16px 4px;border-radius:0 0 5px 5px;font-style:normal;direction:ltr}

/* vector relational layer */
svg.flow{display:block;width:100%%;height:100%%;overflow:visible}
svg.flow .nlab{font-family:'PlexAr',sans-serif;fill:%(ink)s}
svg.flow .nsub{font-family:'PlexAr',sans-serif;fill:%(ink2)s}
svg.flow .elab{font-family:'PlexAr',sans-serif;fill:%(muted)s;font-size:19px}
svg.flow .edge{fill:none;stroke:%(muted)s;stroke-width:2.2}
svg.flow .edge.strong{stroke:%(magenta)s;stroke-width:3}
svg.flow .edge.soft{stroke:%(hair)s;stroke-width:2;stroke-dasharray:5 5}
.vwrap{flex:1 1 auto;min-height:0;position:relative}

/* bar */
.bar{height:14px;border-radius:100px;background:%(hair)s;overflow:hidden;display:flex}
.bar i{display:block;height:100%%}
"""


def css():
    return font_faces() + (BASE_CSS % C)


def page(inner, extra_css=""):
    return f"""<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="utf-8">
<style>{css()}{extra_css}</style></head><body>{inner}</body></html>"""
