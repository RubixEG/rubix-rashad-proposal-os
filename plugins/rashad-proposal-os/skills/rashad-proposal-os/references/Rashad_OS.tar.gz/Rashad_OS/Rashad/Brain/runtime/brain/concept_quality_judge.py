from __future__ import annotations
import copy, hashlib, json
from brain.composition_spec import validate_page_composition_spec

SCHEMA='RASHAD_CONCEPT_ADMISSION_PROOF_V1'

def _h(obj):
    return hashlib.sha256(json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':'),default=str).encode('utf-8')).hexdigest()

def _spec_hash(spec):
    payload={k:v for k,v in dict(spec or {}).items() if k not in {'spec_sha256','validation'}}
    return _h(payload)

def _candidate(search_result,candidate_id):
    candidates=list(search_result.get('mutations') or [])+list(search_result.get('hypotheses') or [])
    return next((x for x in candidates if isinstance(x,dict) and x.get('id')==candidate_id),None)

def _universe(search_result):
    rows=[]
    for stage,key in (('INITIAL','hypotheses'),('REFINED','mutations')):
        for x in (search_result.get(key) or []):
            if not isinstance(x,dict): continue
            rows.append((stage,x.get('id'),x.get('structural_signature'),(x.get('composition_spec') or {}).get('spec_sha256')))
    return rows

def with_candidate_spec(search_result,candidate_id,composition_spec):
    out=copy.deepcopy(search_result or {})
    hit=False
    for key in ('mutations','hypotheses'):
        for x in (out.get(key) or []):
            if isinstance(x,dict) and x.get('id')==candidate_id:
                x['composition_spec']=copy.deepcopy(composition_spec)
                x['structural_signature']=(composition_spec or {}).get('structural_signature') or x.get('structural_signature')
                hit=True
    return out if hit else None

def evaluate_concept_candidate(search_result, candidate_id, content_pack=None, semantic_graph=None):
    """Deterministic *admission* judge for a selected concept.

    This is intentionally not an aesthetic scorer.  It verifies that an independent
    selector can only promote a candidate whose composition spec, content binding,
    evidence surface, topology and search diversity are mechanically real.  A caller
    supplied numeric score has no release authority.
    """
    cp=dict(content_pack or {}); graph=dict(semantic_graph or {})
    c=_candidate(search_result or {},candidate_id)
    blockers=[]
    if not c:
        return {'status':'BLOCKED','candidate_id':candidate_id,'blockers':['CONCEPT_CANDIDATE_NOT_FOUND'],'score':0.0}
    spec=dict(c.get('composition_spec') or {})
    v=validate_page_composition_spec(spec) if spec else {'status':'BLOCKED','errors':['MISSING_SPEC']}
    if v.get('status')!='PASS': blockers.append('CONCEPT_COMPOSITION_SPEC_INVALID')
    declared=str(spec.get('spec_sha256') or '')
    recomputed=_spec_hash(spec) if spec else ''
    if not declared or declared!=recomputed: blockers.append('CONCEPT_COMPOSITION_SPEC_HASH_MISMATCH')
    cb=spec.get('content_binding') or {}
    source_id=str(cb.get('source_id') or '').strip()
    proofs=int(cb.get('proof_point_count',0) or 0)
    if not source_id: blockers.append('CONCEPT_SOURCE_IDENTITY_REQUIRED')
    if proofs<1: blockers.append('CONCEPT_PROOF_POINT_REQUIRED')
    expected_nodes=len([x for x in (graph.get('nodes') or []) if isinstance(x,dict)])
    expected_edges=len([x for x in (graph.get('edges') or []) if isinstance(x,dict)])
    topo=spec.get('topology') or {}
    actual_nodes=len(topo.get('nodes') or []); actual_edges=len(topo.get('edges') or [])
    # No silent loss of semantic graph objects.  Page splitting must happen upstream.
    if actual_nodes!=expected_nodes: blockers.append('CONCEPT_TOPOLOGY_NODE_BINDING_MISMATCH')
    if actual_edges!=expected_edges: blockers.append('CONCEPT_TOPOLOGY_EDGE_BINDING_MISMATCH')
    hyps=[x for x in (search_result.get('hypotheses') or []) if isinstance(x,dict)]
    muts=[x for x in (search_result.get('mutations') or []) if isinstance(x,dict)]
    signatures={str(x.get('structural_signature') or '') for x in hyps if x.get('structural_signature')}
    refined_signatures={str(x.get('structural_signature') or '') for x in muts if x.get('structural_signature')}
    initial_ok=len(hyps)>=5 and len(signatures)>=5
    refined_ok=(not muts) or (len(muts)>=4 and len(refined_signatures)>=4)
    if not initial_ok or not refined_ok: blockers.append('CONCEPT_SEARCH_DIVERSITY_NOT_PROVEN')
    if not (cp.get('evidence') or cp.get('evidence_refs') or source_id): blockers.append('CONCEPT_EVIDENCE_SURFACE_REQUIRED')
    levels=((spec.get('typographic_hierarchy') or {}).get('levels') or [])
    if len(levels)<3: blockers.append('CONCEPT_TYPE_HIERARCHY_NOT_PROVEN')
    basis={
      'spec_integrity':30 if v.get('status')=='PASS' and declared==recomputed else 0,
      'content_binding':20 if source_id and proofs>=1 else 0,
      'topology_binding':15 if actual_nodes==expected_nodes and actual_edges==expected_edges else 0,
      'search_diversity':15 if initial_ok and refined_ok else 0,
      'evidence_surface':10 if (cp.get('evidence') or cp.get('evidence_refs') or source_id) else 0,
      'type_hierarchy':10 if len(levels)>=3 else 0,
    }
    score=float(sum(basis.values()))
    core={
      'schema':SCHEMA,'candidate_id':candidate_id,'composition_spec_sha256':declared,
      'recomputed_composition_spec_sha256':recomputed,'search_universe_sha256':_h(_universe(search_result or {})),
      'initial_candidate_count':len(hyps),'refined_candidate_count':len(muts),
      'content_digest':str(spec.get('content_digest') or ''),'semantic_graph_sha256':_h(graph),
      'basis':basis,'score':score,'blockers':sorted(set(blockers)),
      'rule':'Concept admission is recomputed from the selected candidate and current search/content/graph. Caller-declared scores have no release authority.'
    }
    core['proof_sha256']=_h(core)
    return {'status':'PASS' if not blockers and score>=90 else 'BLOCKED',**core}

def validate_concept_admission(search_result, content_pack=None, semantic_graph=None):
    fj=(search_result or {}).get('final_independent_judgment') or {}
    cid=fj.get('winner_candidate_id')
    if not cid or fj.get('independent') is not True or not fj.get('judge_invocation_id'):
        return {'status':'BLOCKED','blockers':['INDEPENDENT_CONCEPT_SELECTION_NOT_PROVEN']}
    actual=evaluate_concept_candidate(search_result,cid,content_pack,semantic_graph)
    supplied=fj.get('concept_admission_proof') or {}
    blockers=[]
    if actual.get('status')!='PASS': blockers.extend(actual.get('blockers') or ['CONCEPT_ADMISSION_NOT_PASS'])
    if supplied.get('schema')!=SCHEMA: blockers.append('CONCEPT_ADMISSION_PROOF_REQUIRED')
    if supplied.get('proof_sha256')!=actual.get('proof_sha256'): blockers.append('CONCEPT_ADMISSION_PROOF_MISMATCH')
    if supplied.get('candidate_id')!=cid: blockers.append('CONCEPT_ADMISSION_WINNER_MISMATCH')
    if supplied.get('composition_spec_sha256')!=actual.get('composition_spec_sha256'): blockers.append('CONCEPT_ADMISSION_SPEC_MISMATCH')
    return {'status':'PASS' if not blockers else 'BLOCKED','blockers':sorted(set(blockers)),'recomputed':actual,'supplied':supplied}

def attach_concept_admission(search_result, candidate_id, content_pack=None, semantic_graph=None, *, judge_invocation_id='DETERMINISTIC-CONCEPT-ADMISSION', composition_spec_override=None):
    """QA/host helper: attach a recomputable admission proof to an independently selected candidate."""
    source=search_result
    if composition_spec_override is not None:
        source=with_candidate_spec(search_result,candidate_id,composition_spec_override)
        if source is None: return {'status':'BLOCKED','reason':'CONCEPT_CANDIDATE_NOT_FOUND_FOR_SPEC_REBIND'}
    proof=evaluate_concept_candidate(source,candidate_id,content_pack,semantic_graph)
    if proof.get('status')!='PASS': return {'status':'BLOCKED','reason':'CONCEPT_NOT_ADMISSIBLE','concept_admission':proof}
    out=copy.deepcopy(source)
    prior=dict(out.get('final_independent_judgment') or {})
    prior.update({'winner_candidate_id':candidate_id,'independent':True,'judge_invocation_id':prior.get('judge_invocation_id') or judge_invocation_id,'concept_admission_proof':proof})
    # Numeric score is retained only for observability/backward compatibility, never as authority.
    prior['score']=proof['score']
    out['final_independent_judgment']=prior
    return {'status':'PASS','search_result':out,'concept_admission':proof}
