from __future__ import annotations
from pathlib import Path
from io import BytesIO
import hashlib, json, math, copy
from PIL import Image
import numpy as np

SCHEMA='RASHAD_PIXEL_MEASUREMENT_V1'
# Content-addressed measurement cache. The file SHA is still recomputed on every path
# verification, so changing bytes cannot reuse a prior measurement. Only the expensive
# pixel-statistics pass is memoized for identical immutable content.
_MEASUREMENT_CACHE={}
_MEASUREMENT_CACHE_MAX=128

def _cached_measurement(render_sha256):
    x=_MEASUREMENT_CACHE.get(render_sha256)
    return copy.deepcopy(x) if x is not None else None

def _store_measurement(render_sha256, record):
    if not render_sha256 or not isinstance(record,dict): return
    if len(_MEASUREMENT_CACHE)>=_MEASUREMENT_CACHE_MAX:
        try: _MEASUREMENT_CACHE.pop(next(iter(_MEASUREMENT_CACHE)))
        except Exception: _MEASUREMENT_CACHE.clear()
    _MEASUREMENT_CACHE[render_sha256]=copy.deepcopy(record)

def sha256_file(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def _entropy(gray):
    hist=np.bincount(gray.ravel(), minlength=256).astype(float)
    p=hist[hist>0]/max(1.0,hist.sum())
    return float(-(p*np.log2(p)).sum()) if len(p) else 0.0

def _measure_image(im:Image.Image, render_sha256:str|None=None):
    im=im.convert('RGB')
    # Normalize to a bounded analysis size; layout truth does not require full-resolution arrays.
    if im.width>960 or im.height>540:
        im.thumbnail((960,540),Image.Resampling.BILINEAR)
    a=np.asarray(im).astype(np.float32)
    gray=(.2126*a[:,:,0]+.7152*a[:,:,1]+.0722*a[:,:,2])
    # Distance from the canvas-like local mode. White/off-white blank pages are both caught.
    q=(a//16).astype(np.int16)
    packed=q[:,:,0]*256+q[:,:,1]*16+q[:,:,2]
    vals,counts=np.unique(packed,return_counts=True)
    mode=int(vals[int(np.argmax(counts))])
    mr=((mode//256)%16)*16+8; mg=((mode//16)%16)*16+8; mb=(mode%16)*16+8
    dist=np.sqrt(((a-np.array([mr,mg,mb],dtype=np.float32))**2).sum(axis=2))
    noncanvas=float((dist>22).mean())
    std=float(gray.std())
    ent=_entropy(gray.astype(np.uint8))
    gx=np.abs(np.diff(gray,axis=1)); gy=np.abs(np.diff(gray,axis=0))
    edge=float(((gx>18).mean()+(gy>18).mean())/2.0)
    # Spatial occupancy: number of 6x4 cells containing meaningful ink.
    occ=0; total=24
    H,W=dist.shape
    for r in range(4):
        for c in range(6):
            cell=dist[r*H//4:(r+1)*H//4,c*W//6:(c+1)*W//6]
            if cell.size and float((cell>22).mean())>=.006: occ+=1
    occ_ratio=occ/total
    blockers=[]
    if noncanvas < .004: blockers.append('PIXEL_PAGE_EFFECTIVELY_BLANK')
    if std < 4.0: blockers.append('PIXEL_DYNAMIC_RANGE_TOO_LOW')
    if ent < .32: blockers.append('PIXEL_INFORMATION_ENTROPY_TOO_LOW')
    if edge < .0008: blockers.append('PIXEL_EDGE_DENSITY_TOO_LOW')
    if occ_ratio < .125: blockers.append('PIXEL_SPATIAL_OCCUPANCY_TOO_LOW')
    metrics={
        'width':im.width,'height':im.height,'noncanvas_fraction':round(noncanvas,6),
        'gray_std':round(std,4),'entropy_bits':round(ent,4),'edge_fraction':round(edge,6),
        'occupied_cell_ratio':round(occ_ratio,4),'canvas_mode_rgb':[mr,mg,mb]
    }
    core={'schema':SCHEMA,'render_sha256':render_sha256,'metrics':metrics,'blockers':blockers}
    core['measurement_sha256']=hashlib.sha256(json.dumps(core,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    core['status']='PASS' if not blockers else 'BLOCKED'
    return core

def measure_render(path, expected_hash=None):
    p=Path(path or '')
    if not p.exists(): return {'schema':SCHEMA,'status':'BLOCKED','blockers':['PIXEL_RENDER_FILE_MISSING']}
    actual=sha256_file(p)
    if expected_hash and actual!=expected_hash:
        return {'schema':SCHEMA,'status':'BLOCKED','render_sha256':actual,'blockers':['PIXEL_RENDER_HASH_MISMATCH']}
    cached=_cached_measurement(actual)
    if cached is not None: return cached
    try:
        with Image.open(p) as im: record=_measure_image(im,actual)
        _store_measurement(actual,record)
        return record
    except Exception as e:
        return {'schema':SCHEMA,'status':'BLOCKED','render_sha256':actual,'blockers':['PIXEL_RENDER_DECODE_FAILED:'+type(e).__name__]}

def measure_image_bytes(blob:bytes, expected_hash=None):
    actual=hashlib.sha256(blob).hexdigest()
    if expected_hash and actual!=expected_hash:
        return {'schema':SCHEMA,'status':'BLOCKED','render_sha256':actual,'blockers':['PIXEL_RENDER_HASH_MISMATCH']}
    cached=_cached_measurement(actual)
    if cached is not None: return cached
    try:
        with Image.open(BytesIO(blob)) as im: record=_measure_image(im,actual)
        _store_measurement(actual,record)
        return record
    except Exception as e:
        return {'schema':SCHEMA,'status':'BLOCKED','render_sha256':actual,'blockers':['PIXEL_RENDER_DECODE_FAILED:'+type(e).__name__]}

def verify_measurement(record, path, expected_hash=None):
    fresh=measure_render(path,expected_hash=expected_hash)
    if fresh.get('status')!='PASS': return fresh
    supplied=record or {}
    if supplied.get('schema')!=SCHEMA: return {'status':'BLOCKED','blockers':['PIXEL_MEASUREMENT_SCHEMA_REQUIRED'],'fresh':fresh}
    if supplied.get('render_sha256')!=fresh.get('render_sha256'): return {'status':'BLOCKED','blockers':['PIXEL_MEASUREMENT_RENDER_BINDING_MISMATCH'],'fresh':fresh}
    if supplied.get('measurement_sha256')!=fresh.get('measurement_sha256'): return {'status':'BLOCKED','blockers':['PIXEL_MEASUREMENT_RECOMPUTE_MISMATCH'],'fresh':fresh}
    return fresh
