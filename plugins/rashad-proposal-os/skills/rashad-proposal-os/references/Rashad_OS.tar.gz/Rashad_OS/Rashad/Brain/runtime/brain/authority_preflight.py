# -*- coding: utf-8 -*-
"""
Rashad v7.3.3 — AUTHORITY LOAD LEDGER & PREFLIGHT (executable)

Extends the existing Rashad doctrine `Registered != Routed != Executed` one level
UP: from page elements to the authorities themselves.

61_REQUIRED_INSTRUMENTATION_AND_NO_VACUOUS_PASS already refuses to let a PAGE
claim PASS for something it did not measure:
    required=true AND actual_test_count=0 -> FAIL_NOT_INSTRUMENTED
This module applies the identical rule to the SESSION:
    required=true AND attested=false     -> BLOCK_PRODUCTION

Root incident: RASHAD-INC-2026-08-18 — 69 authorities routed, 2 read before
production. Every downstream defect (raster-only PPTX, co-brand order, Western
numerals, uninstrumented collision QA, 93-family catalogue unused) traces here.

Design constraints, learned from that incident:
  1. Opening a file proves nothing. ATTESTATION (a written binding statement)
     is the unit of proof, not LOADED.
  2. The producer cannot self-certify. The gate is mechanical and hash-bound.
  3. Anti-gaming is mandatory: templated / trivial / recycled attestations are
     themselves a blocker. A control that is cheap to fake will be faked.
"""
from __future__ import annotations
import hashlib, json, os, pathlib, re, sys, datetime

SKILL_ROOT = pathlib.Path(os.environ.get("RASHAD_SKILL_ROOT", "")) if os.environ.get("RASHAD_SKILL_ROOT") else None
if SKILL_ROOT is None:
    here = pathlib.Path(__file__).resolve()
    for p in here.parents:
        if (p / "Rashad" / "Skill" / "ACTIVE_AUTHORITY_MANIFEST.json").exists():
            SKILL_ROOT = p / "Rashad" / "Skill"; break
        if (p / "Skill" / "ACTIVE_AUTHORITY_MANIFEST.json").exists():
            SKILL_ROOT = p / "Skill"; break
    if SKILL_ROOT is None:
        SKILL_ROOT = here.parents[4] / "Rashad" / "Skill"

MANIFEST = SKILL_ROOT / "ACTIVE_AUTHORITY_MANIFEST.json"
REQUIRED_SETS = SKILL_ROOT / "01_ACTIVE_RUNTIME" / "authority_required_sets_v7_3_3.json"
LEDGER_DIR = pathlib.Path(os.environ.get("RASHAD_LEDGER_DIR", pathlib.Path.cwd() / ".rashad"))
LEDGER = LEDGER_DIR / "AUTHORITY_LOAD_LEDGER.json"

MIN_ATTESTATION_CHARS = 60
MAX_IDENTICAL_ATTESTATIONS = 2       # >2 byte-identical attestations = templated
MAX_SHARED_PREFIX_RATIO = 0.60       # >60% of attestations sharing a 40-char prefix = templated

BLOCKING_STAGES = {"USER_VISIBLE_ARTIFACT", "RELEASE", "HANDOFF"}
WARNING_STAGES = {"ADVISORY", "INTERNAL_DRAFT", "ANALYSIS"}


def _sha(p: pathlib.Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def _now() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def manifest_authorities() -> list[str]:
    return json.loads(MANIFEST.read_text(encoding="utf-8"))["global_authorities"]


def required_set(product: str) -> list[str]:
    if REQUIRED_SETS.exists():
        sets = json.loads(REQUIRED_SETS.read_text(encoding="utf-8"))["required_authority_sets"]
        if product in sets:
            spec = sets[product]
            if spec.get("mode") == "ALL":
                return manifest_authorities()
            return spec["authorities"]
    return manifest_authorities()


# --------------------------------------------------------------------------- #
def init_ledger(product: str, engagement: str = "") -> dict:
    LEDGER_DIR.mkdir(parents=True, exist_ok=True)
    req = required_set(product)
    rows = {}
    for rel in req:
        f = SKILL_ROOT / rel
        rows[rel] = {
            "state": "NOT_LOADED",
            "sha256": _sha(f) if f.exists() else None,
            "exists": f.exists(),
            "bytes": f.stat().st_size if f.exists() else 0,
            "attestation": None,
            "governs": None,
            "attested_at": None,
        }
    led = {
        "schema": "RASHAD_AUTHORITY_LOAD_LEDGER_V7_3_3",
        "product": product,
        "engagement": engagement,
        "opened_at": _now(),
        "skill_root": str(SKILL_ROOT),
        "required_count": len(req),
        "authorities": rows,
    }
    LEDGER.write_text(json.dumps(led, ensure_ascii=False, indent=1), encoding="utf-8")
    return led


def _load() -> dict:
    if not LEDGER.exists():
        raise SystemExit("LEDGER_ABSENT :: run `authority_preflight.py --init <PRODUCT>` "
                         "as the FIRST action of the engagement. Production is blocked.")
    return json.loads(LEDGER.read_text(encoding="utf-8"))


def attest(rel: str, attestation: str, governs: str) -> dict:
    led = _load()
    if rel not in led["authorities"]:
        raise SystemExit(f"NOT_IN_REQUIRED_SET :: {rel}")
    row = led["authorities"][rel]
    f = SKILL_ROOT / rel
    if not f.exists():
        row["state"] = "MISSING_FROM_CORPUS"
        LEDGER.write_text(json.dumps(led, ensure_ascii=False, indent=1), encoding="utf-8")
        raise SystemExit(f"AUTHORITY_MISSING_FROM_CORPUS :: {rel}")
    cur = _sha(f)
    if row["sha256"] and cur != row["sha256"]:
        raise SystemExit(f"AUTHORITY_MUTATED_SINCE_LEDGER_INIT :: {rel}")
    a = (attestation or "").strip()
    if len(a) < MIN_ATTESTATION_CHARS:
        raise SystemExit(f"ATTESTATION_TOO_THIN :: {rel} :: need >= {MIN_ATTESTATION_CHARS} chars "
                         f"stating what this authority BINDS in this engagement")
    # filename echo: the attestation adds nothing beyond the file's own name.
    stem_tokens = {t for t in re.split(r"[^a-z0-9\u0600-\u06ff]+",
                                       pathlib.Path(rel).stem.lower()) if len(t) > 2}
    STOP = {"the", "and", "for", "this", "that", "with", "its", "are", "was",
            "governs", "binds", "authority", "engagement", "rashad", "v7"}
    a_tokens = {t for t in re.split(r"[^a-z0-9\u0600-\u06ff]+", a.lower())
                if len(t) > 2 and t not in STOP}
    if a_tokens and len(a_tokens - stem_tokens) / len(a_tokens) < 0.35:
        raise SystemExit(f"ATTESTATION_IS_FILENAME_ECHO :: {rel} :: "
                         f"adds no content beyond the filename")
    if len(a_tokens) < 8:
        raise SystemExit(f"ATTESTATION_TOO_FEW_DISTINCT_TERMS :: {rel} :: "
                         f"{len(a_tokens)} distinct terms; restatement is not attestation")
    row.update(state="ATTESTED", attestation=a, governs=governs, sha256=cur, attested_at=_now())
    LEDGER.write_text(json.dumps(led, ensure_ascii=False, indent=1), encoding="utf-8")
    return row


# --------------------------------------------------------------------------- #
def _anti_gaming(led: dict) -> list[str]:
    """A control that is cheap to fake will be faked. These checks exist because
    the failure they guard against is the failure that already happened."""
    out = []
    atts = [r["attestation"] for r in led["authorities"].values()
            if r["state"] == "ATTESTED" and r["attestation"]]
    if not atts:
        return out
    from collections import Counter
    dup = Counter(atts)
    for txt, k in dup.items():
        if k > MAX_IDENTICAL_ATTESTATIONS:
            out.append(f"ATTESTATION_TEMPLATED :: {k} identical attestations :: '{txt[:48]}...'")
    pref = Counter(a[:40] for a in atts)
    top, n = pref.most_common(1)[0]
    if len(atts) >= 8 and n / len(atts) > MAX_SHARED_PREFIX_RATIO:
        out.append(f"ATTESTATION_TEMPLATED_PREFIX :: {n}/{len(atts)} share prefix '{top[:36]}...'")
    return out


def preflight(stage: str = "USER_VISIBLE_ARTIFACT") -> dict:
    led = _load()
    rows = led["authorities"]
    attested = [k for k, v in rows.items() if v["state"] == "ATTESTED"]
    missing = [k for k, v in rows.items() if v["state"] != "ATTESTED"]
    mutated, absent = [], []
    for k, v in rows.items():
        f = SKILL_ROOT / k
        if not f.exists():
            absent.append(k)
        elif v["sha256"] and _sha(f) != v["sha256"]:
            mutated.append(k)

    blockers = []
    if missing:
        blockers.append(f"AUTHORITY_COVERAGE_INCOMPLETE :: {len(missing)}/{len(rows)} not attested")
    if mutated:
        blockers.append(f"AUTHORITY_MUTATED_SINCE_ATTESTATION :: {len(mutated)}")
    if absent:
        blockers.append(f"AUTHORITY_MISSING_FROM_CORPUS :: {len(absent)}")
    blockers += _anti_gaming(led)

    if not blockers:
        status = "PASS"
    elif stage.upper() in BLOCKING_STAGES:
        status = "BLOCK_PRODUCTION"
    else:
        status = "PROCEED_WITH_COVERAGE_BANNER"

    return {
        "status": status,
        "stage": stage.upper(),
        "product": led["product"],
        "required": len(rows),
        "attested": len(attested),
        "coverage_ratio": round(len(attested) / max(1, len(rows)), 3),
        "unattested": sorted(missing),
        "mutated": mutated,
        "absent_from_corpus": absent,
        "blockers": blockers,
        "banner": (None if not blockers else
                   f"AUTHORITY_COVERAGE_INCOMPLETE — {len(attested)}/{len(rows)} authorities attested. "
                   f"This output is NOT governed by the full routed corpus."),
    }


def gate_coverage(gate_map: dict) -> dict:
    """Every QA detector must declare which authority it implements.
    An authority with no implementing detector is NOT_EXECUTED — never PASS.
    This is the check whose absence let `0 blockers` mean `nothing was measured`."""
    led = _load()
    implemented = set()
    for gate, auths in (gate_map or {}).items():
        implemented.update(auths)
    required = set(led["authorities"].keys())
    uncovered = sorted(required - implemented)
    return {
        "authorities_required": len(required),
        "authorities_with_detector": len(required & implemented),
        "authorities_not_executed": uncovered,
        "status": "PASS" if not uncovered else "NOT_EXECUTED",
        "rule": "required authority with zero implementing detector = NOT_EXECUTED, never PASS",
    }


def summary_line() -> str:
    r = preflight("ADVISORY")
    return (f"AUTHORITY LEDGER :: product={r['product']} "
            f"attested={r['attested']}/{r['required']} ({int(r['coverage_ratio']*100)}%) "
            f"status={r['status']}")


# --------------------------------------------------------------------------- #
if __name__ == "__main__":
    a = sys.argv[1:]
    if not a or a[0] in ("-h", "--help"):
        print(__doc__)
        print("usage:\n"
              "  --init <PRODUCT> [engagement]     open the ledger (FIRST action, mandatory)\n"
              "  --status                          coverage summary\n"
              "  --list-unattested                 what still blocks production\n"
              "  --attest <rel_path> <binding> <governs>\n"
              "  --gate <STAGE>                    PASS | BLOCK_PRODUCTION | banner\n")
        sys.exit(0)
    cmd = a[0]
    if cmd == "--init":
        led = init_ledger(a[1], a[2] if len(a) > 2 else "")
        print(json.dumps({"opened": True, "product": led["product"],
                          "required_count": led["required_count"],
                          "ledger": str(LEDGER)}, ensure_ascii=False))
    elif cmd == "--status":
        print(json.dumps(preflight("ADVISORY"), ensure_ascii=False, indent=1))
    elif cmd == "--list-unattested":
        for x in preflight("ADVISORY")["unattested"]:
            print(x)
    elif cmd == "--attest":
        print(json.dumps(attest(a[1], a[2], a[3] if len(a) > 3 else ""), ensure_ascii=False))
    elif cmd == "--gate":
        r = preflight(a[1] if len(a) > 1 else "USER_VISIBLE_ARTIFACT")
        print(json.dumps(r, ensure_ascii=False, indent=1))
        sys.exit(0 if r["status"] == "PASS" else 2)
    else:
        raise SystemExit(f"unknown command {cmd}")
