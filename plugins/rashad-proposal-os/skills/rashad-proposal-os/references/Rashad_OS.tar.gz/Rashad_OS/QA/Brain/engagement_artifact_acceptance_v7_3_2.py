from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'Rashad/Brain/runtime'))
from brain.product_inspector import inspect_pptx
FIX=ROOT/'QA/Runtime/fixtures/engagement'; CERT=ROOT/'QA/Certification'
rows=[]
for name in ['REDF_2610089_CLAUDE_NEGATIVE_BASELINE.pptx','REDF_2610089_CODEX_NEGATIVE_BASELINE.pptx']:
    p=FIX/name; r=inspect_pptx(p)
    rows.append({'name':name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size_bytes':p.stat().st_size,'acceptance_status':r.get('status'),'blocker_count':len(r.get('blockers') or []),'blockers':r.get('blockers') or []})
out={'suite':'REAL_ENGAGEMENT_ARTIFACT_ACCEPTANCE_V7_3_2','status':'PASS' if len(rows)==2 and all(x['acceptance_status']=='BLOCKED' for x in rows) else 'FAIL','artifacts':rows,'fixture_policy':'VENDORED_REAL_BYTES_PINNED_BY_SOURCE_FINGERPRINT'}
CERT.mkdir(exist_ok=True); (CERT/'ENGAGEMENT_ARTIFACT_ACCEPTANCE_V7_3.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(out,ensure_ascii=False,indent=2)); raise SystemExit(0 if out['status']=='PASS' else 1)
