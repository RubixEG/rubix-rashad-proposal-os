#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import copy,hashlib,json,sys,tempfile
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'Rashad/Brain/runtime')); sys.path.insert(0,str(Path(__file__).parent))
from brain.actual_output_qa import evaluate_page_output
from brain.pixel_truth import measure_render
from brain.composition_spec import build_page_composition_spec
from brain.production.composer import compose_html
from brain.production.renderer import render_composition_page
from brain.production.projector import build_image_master_pptx
from brain.product_inspector import inspect_pptx
from brain.semantic_master_gate import inspect_semantic_html_master
from brain.imagery_director import build_image_request,validate_image_plate
from brain.visual_memory import variety_check
from brain.repair_engine import repair_spec
from brain.production_quality_judge import deterministic_pixel_review
from brain.concept_quality_judge import attach_concept_admission
from brain.orchestrator import run_brain
from brain.provider import ScriptedTestProvider
from brain.visual_search import generate_hypotheses
from brain.artifact_council_runtime import execute_artifact_councils
from artifact_delivery_orchestrator import promote_page_to_production
from delivery_test_fixtures_v7_2 import page,review

OUT=ROOT/'QA/Certification/V7_3_1_TRUTH_CLOSURE_RED_TEAM.json'

def add(rows,name,ok,detail=None): rows.append({'name':name,'status':'PASS' if ok else 'FAIL','detail':detail})
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def graph():
    return {'nodes':[{'id':'N1','label':'الاستكشاف','type':'PROCESS'},{'id':'N2','label':'القرار','type':'DECISION'},{'id':'N3','label':'التنفيذ','type':'PROCESS'},{'id':'N4','label':'القياس','type':'MEASURE'}],
            'edges':[{'id':'E1','source':'N1','target':'N2','relation':'FLOWS_TO'},{'id':'E2','source':'N2','target':'N3','relation':'APPROVES'},{'id':'E3','source':'N3','target':'N4','relation':'FLOWS_TO'},{'id':'E4','source':'N4','target':'N1','relation':'FEEDS_BACK'}]}
def spec_for(strategy='SYSTEM_LED',idx=1):
    h={'id':'H1','communication_strategy':strategy,'strategy_family':'RELATIONAL' if strategy in {'SYSTEM_LED','ARCHITECTURE_LED','JOURNEY_LED','PROCESS_LED','SEQUENCE_LED'} else 'ANALYTICAL','page_fingerprint':'RT'}
    cp={'page_id':'P01','language':'AR','title':'قرار تنفيذي','thesis':'القرار مرتبط بدليل قابل للتحقق','proof_points':['دليل أول','دليل ثان','دليل ثالث']}
    return build_page_composition_spec(h,cp,graph(),variant_index=idx)

def main():
    rows=[]
    with tempfile.TemporaryDirectory() as td:
        td=Path(td)
        # 1 — blank page + forged high review can never pass user-visible QA.
        blank=td/'blank.png'; Image.new('RGB',(1920,1080),'white').save(blank); h=sha(blank); pm=measure_render(blank,h)
        pg=page(1,'SYSTEM_LED',blank);  pg.update({'render_path':str(blank),'pixel_measurement':pm,'composition_spec':spec_for('SYSTEM_LED',1),'composition_logic':'X'})
        forged=review(h,score=99,ind=True); forged['review_basis']={'schema':'RASHAD_REVIEW_BASIS_V1','actual_render_hash':h,'pixel_measurement_sha256':pm.get('measurement_sha256'),'inspection_basis':['ACTUAL_RENDER_PIXELS']}; pg['actual_pixel_review']=forged
        q=evaluate_page_output(pg,'USER_VISIBLE_ARTIFACT_DRAFT'); add(rows,'blank_page_forged_99_review_is_blocked',q.get('status')=='BLOCKED' and any('PIXEL_TRUTH::' in x for x in q.get('blockers',[])),q.get('blockers'))

        # 2 — raster-only deck does not escape pixel truth even with a valid semantic master.
        spec=spec_for('SYSTEM_LED',2); cp={'page_id':'P01','language':'AR','title':'منهجية التنفيذ','thesis':'نظام مترابط قابل للقياس','proof_points':['دليل أول','دليل ثان','دليل ثالث'],'source_note':'EV-1'}
        real=render_composition_page(spec,cp,graph(),td/'real',allow_test_font_fallback=True,emit_pdf=True)
        sm=inspect_semantic_html_master(real.get('html_master_path'),spec)
        blank2=td/'blank2.png'; im=Image.new('RGB',(1920,1080),'white'); im.putpixel((1,1),(250,250,250)); im.save(blank2)
        pr=build_image_master_pptx([blank2],td/'blank_raster.pptx')
        expected=[{'selected_strategy':'SYSTEM_LED','html_master_path':real.get('html_master_path'),'html_master_sha256':real.get('html_master_sha256'),'composition_spec_sha256':spec.get('spec_sha256'),'composition_spec':spec,'semantic_master_qa':sm}]
        pi=inspect_pptx(pr['pptx_path'],expected); add(rows,'blank_raster_deck_blocked_despite_valid_semantic_master',pi.get('status')=='BLOCKED' and any('RASTER_PIXEL' in x for x in pi.get('blockers',[])),pi.get('blockers'))

        # 3 — empty/vacuous semantic shell cannot satisfy semantic-master proof.
        empty=td/'empty.html'; empty.write_text(f'<html data-page-id="P01" data-page-mode="ARTIFACT_LED" data-composition-spec-sha256="{spec.get("spec_sha256")}"><body><div data-region-id="DOMINANT"></div></body></html>',encoding='utf-8')
        es=inspect_semantic_html_master(empty,spec); add(rows,'empty_semantic_master_blocked_with_zero_real_nodes',es.get('status')=='BLOCKED' and es.get('measured_object_count',99)==0 and any('CONTENT_BEARING_FLOOR' in x or 'TOPOLOGY_NODE_COUNT' in x for x in es.get('blockers',[])),es)

        # 4 — CHART_LED may never invent fallback data.
        cs=spec_for('CHART_LED',3); ccp={'page_id':'P01','language':'AR','title':'منطق التقييم','thesis':'الأوزان مبنية على المصدر','source_note':'EV-1','proof_points':['أ','ب','ج']}
        ch=compose_html(cs,ccp,graph(),td/'chart.html'); add(rows,'chart_without_bound_values_is_blocked',ch.get('status')=='BLOCKED' and 'CHART' in str(ch.get('reason','')),ch)

        # 5 — generated-image admission ignores provider self-attestation and requires independent asset-bound scan.
        asset=td/'logo123.png'; im=Image.new('RGB',(800,450),'white'); d=ImageDraw.Draw(im); d.text((100,180),'LOGO 123',fill='black'); im.save(asset)
        ispec=spec_for('SYSTEM_LED',4); ispec['imagery']['mode']='RASTER_AUGMENTED'; req=build_image_request(ispec,{'title':'اختبار'})['request']; ah=sha(asset)
        provider={'status':'PASS','asset_path':str(asset),'asset_sha256':ah,'ocr_text':'','contains_logo':False,'contains_digits':False,'provider_actor_id':'IMAGE-PROVIDER','proof':{'request_sha256':req['request_sha256']}}
        no_scan=validate_image_plate(provider,req,None)
        scan={'schema':'RASHAD_IMAGE_ADMISSION_SCAN_V1','status':'PASS','asset_sha256':ah,'scanner_actor_id':'INDEPENDENT-CV-SCANNER','ocr_text':'LOGO 123','contains_logo':True,'contains_digits':True,'contains_official_seal':False}
        spoof=validate_image_plate(provider,req,scan)
        add(rows,'provider_clean_metadata_without_scan_blocked',no_scan.get('status')=='BLOCKED' and (no_scan.get('admission_scan') or {}).get('scanner_actor_id')=='RASHAD-OCR-CV-SCANNER-V1' and 'GENERATED_IMAGE_CONTAINS_TEXT' in no_scan.get('blockers',[]),no_scan)
        add(rows,'logo_123_independent_scan_blocks_provider_spoof',spoof.get('status')=='BLOCKED' and 'GENERATED_IMAGE_CONTAINS_TEXT' in spoof.get('blockers',[]) and 'GENERATED_IMAGE_DIGITS_NOT_PROVEN_ABSENT' in spoof.get('blockers',[]),spoof)

        # 6 — structural distance threshold is actually enforced.
        a=spec_for('SYSTEM_LED',5); b=copy.deepcopy(a); b['content_digest']='DIFFERENT-CONTENT-ONLY'; b['spec_sha256']='ignored-for-distance'
        vm=variety_check(b,[a],max_consecutive_same=99,min_structural_distance=.99); add(rows,'near_template_visual_memory_blocks_at_configured_distance',vm.get('status')=='BLOCKED' and vm.get('reason')=='NEAR_TEMPLATE_VISUAL_GRAMMAR',vm)

        # 7 — missing evidence identity blocks rather than emitting synthetic EVIDENCE-BOUND.
        ss=spec_for('SYSTEM_LED',6); missing=compose_html(ss,{'page_id':'P01','language':'AR','title':'عنوان','thesis':'ادعاء مادي','proof_points':['دليل']},graph(),td/'missing_source.html')
        add(rows,'missing_source_identity_fail_closed',missing.get('status')=='BLOCKED' and 'SOURCE' in str(missing.get('reason','')),missing)

        # 8 — repair changes both composition spec and actual rendered pixels.
        rs=spec_for('SYSTEM_LED',7); rcp={'page_id':'P01','language':'AR','title':'منهجية التنفيذ','thesis':'نظام مترابط','proof_points':['أ','ب','ج'],'source_note':'EV-1'}
        r1=render_composition_page(rs,rcp,graph(),td/'repair_a',allow_test_font_fallback=True)
        repaired=repair_spec(rs,{'scores':{'visual_form_fitness':40,'production_quality':40},'blockers':['G18_CARD_TRUTH','G41_CONNECTOR_PATH_GEOMETRY']},2)
        r2=render_composition_page(repaired['spec'],rcp,graph(),td/'repair_b',allow_test_font_fallback=True)
        add(rows,'repair_mutates_spec_and_pixels',repaired.get('status')=='PASS' and repaired['spec'].get('spec_sha256')!=rs.get('spec_sha256') and r1.get('actual_render_hash')!=r2.get('actual_render_hash'),{'old_spec':rs.get('spec_sha256'),'new_spec':repaired.get('spec_sha256'),'old_render':r1.get('actual_render_hash'),'new_render':r2.get('actual_render_hash'),'ops':repaired.get('operations')})

        # 9 — the actual orchestrator closes a failed-review loop with a new spec/render, not identical rerendering.
        provider_rt=ScriptedTestProvider(); content={'page_id':'P99','language':'AR','title':'منهجية التنفيذ','thesis':'نظام مترابط تحكمه بوابات قرار','proof_points':['دليل مثبت','أثر على القرار','إجراء قبول'],'evidence':['E1'],'source_note':'EV-1'}; g=graph()
        task={'task_id':'V731-REPAIR-RT','rfp_role':'MANAGEMENT_DECISION','critical':True,'rendered':True,'question':'منهجية التنفيذ نظام مترابط قرار دليل','evidence':[{'id':'E1','source':'cert'}]}
        brain=run_brain(task,provider_rt); search=generate_hypotheses(g,content)
        hyp=next((x for x in search.get('hypotheses',[]) if x.get('communication_strategy')=='SYSTEM_LED'),None) or (search.get('hypotheses') or [None])[0]
        pre=execute_artifact_councils(g,content,provider_rt,'AR','PRE_CONCEPT'); art=execute_artifact_councils(g,content,provider_rt,'AR','ART_DIRECTION',prior={'strategy':hyp.get('communication_strategy') if hyp else None})
        search['artifact_council_execution']=pre; search['art_direction_execution']=art; search['final_independent_judgment']={'winner_candidate_id':hyp['id'],'independent':True,'judge_invocation_id':'V731-REPAIR-JUDGE','actual_render_hash':(hyp.get('concept_render') or {}).get('actual_render_hash')}; admitted=attach_concept_admission(search,hyp['id'],content,g,judge_invocation_id='V731-REPAIR-JUDGE'); search=admitted.get('search_result',search)
        calls={'n':0}
        def reviewer(req):
            calls['n']+=1; r=deterministic_pixel_review(req,actor_id='V731-REPAIR-PIXEL-JUDGE')
            if calls['n']==1:
                r['scores']['visual_form_fitness']=40; r['artifact_truth_score']=40; r['ceqs_score']=40; r['hard_blockers']=['G18_CARD_TRUTH']; r['status']='PASS'
            return r
        prom=promote_page_to_production(search,pixel_reviewer=reviewer,content_pack=content,semantic_graph=g,out_dir=td/'closed_loop',brain_session=brain,page_contract={'page_id':'P99','critical':True},artifact_intent={'strategy':hyp.get('communication_strategy'),'decision':'اختبار الإصلاح'},evidence_lineage={'E1':{'source':'cert'}},brand_preflight={'status':'PASS','rubix_asset_status':'VERIFIED'},artifact_provider=provider_rt,allow_test_font_fallback=True)
        hist=prom.get('repair_history') or []; render_hashes=[(x.get('render') or {}).get('actual_render_hash') for x in hist if (x.get('render') or {}).get('actual_render_hash')]; spec_hashes=[x.get('composition_spec_sha256') for x in hist if x.get('composition_spec_sha256')]
        add(rows,'orchestrator_failed_review_produces_changed_rerender',prom.get('status')=='PASS' and calls['n']>=2 and len(set(render_hashes))>=2 and len(set(spec_hashes))>=1 and prom['production_page']['composition_spec'].get('spec_sha256')!=hyp['composition_spec'].get('spec_sha256'),{'status':prom.get('status'),'reason':prom.get('reason'),'calls':calls['n'],'render_hashes':render_hashes,'history_len':len(hist),'initial_spec':hyp['composition_spec'].get('spec_sha256'),'final_spec':(prom.get('production_page') or {}).get('composition_spec',{}).get('spec_sha256')})

    out={'suite':'Rashad v7.3.1 Production Truth Closure Red Team','status':'PASS' if all(x['status']=='PASS' for x in rows) else 'FAIL','passed':sum(x['status']=='PASS' for x in rows),'total':len(rows),'tests':rows}
    OUT.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8'); print(json.dumps(out,ensure_ascii=False,indent=2)); return 0 if out['status']=='PASS' else 2
if __name__=='__main__': raise SystemExit(main())
