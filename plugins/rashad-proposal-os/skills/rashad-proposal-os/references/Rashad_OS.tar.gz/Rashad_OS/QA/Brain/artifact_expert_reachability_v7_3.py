#!/usr/bin/env python3
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[2]; sys.path.insert(0,str(ROOT/'Rashad/Brain/runtime'))
from brain.artifact_council_runtime import natural_role_coverage

r=natural_role_coverage()
out={
 'suite':'Artifact Expert Natural Reachability v7.3.2',
 'status':'PASS' if r.get('status')=='PASS' and r.get('registered_roles')==r.get('naturally_selectable_roles')==107 else 'FAIL',
 'registered_roles':r.get('registered_roles'),
 'naturally_selectable_roles':r.get('naturally_selectable_roles'),
 'executed_pairs':r.get('executed_pairs'),
 'unreachable':r.get('missing') or [],
 'method':'Natural deterministic routing sweep only. No requested role id is injected into the function under test.',
}
(ROOT/'QA/Certification/ARTIFACT_EXPERT_REACHABILITY_V7_3.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out,ensure_ascii=False,indent=2))
raise SystemExit(0 if out['status']=='PASS' else 1)
