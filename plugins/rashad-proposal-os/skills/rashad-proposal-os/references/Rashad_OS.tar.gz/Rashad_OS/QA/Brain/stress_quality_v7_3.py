#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import sys,json,random,hashlib,tempfile,copy
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'Rashad/Brain/runtime')); sys.path.insert(0,str(Path(__file__).parent))
from brain.actual_output_qa import evaluate_page_output,evaluate_deck_output
from brain.pixel_truth import measure_render, sha256_file
from brain.composition_spec import build_page_composition_spec
from hardened_delivery_fixture_v7_3_2 import build_projection_concept_admission
from PIL import Image,ImageDraw
OUT=ROOT/'QA/Certification'; random.seed(7302026)
STR=['STATEMENT_LED','NUMBER_LED','EVIDENCE_LED','TABLE_LED','CHART_LED','COMPARISON_LED','MATRIX_LED','DECISION_LED','SEQUENCE_LED','PROCESS_LED','SYSTEM_LED','ARCHITECTURE_LED','IMAGE_LED','HYBRID_EXHIBIT','SCORECARD_LED']
FAM={'STATEMENT_LED':'MINIMAL','NUMBER_LED':'MINIMAL','DECISION_LED':'MINIMAL','EVIDENCE_LED':'ANALYTICAL','TABLE_LED':'ANALYTICAL','CHART_LED':'ANALYTICAL','COMPARISON_LED':'ANALYTICAL','MATRIX_LED':'ANALYTICAL','SCORECARD_LED':'ANALYTICAL','SEQUENCE_LED':'RELATIONAL','PROCESS_LED':'RELATIONAL','SYSTEM_LED':'RELATIONAL','ARCHITECTURE_LED':'RELATIONAL','IMAGE_LED':'CREATIVE','HYBRID_EXHIBIT':'HYBRID'}

def hyps(seed):
    picks=['STATEMENT_LED','NUMBER_LED','EVIDENCE_LED','COMPARISON_LED','HYBRID_EXHIBIT']
    return [{'id':f'H{i+1}','communication_strategy':s,'strategy_family':FAM[s],'structural_signature':f'{seed}|{s}|{i}'} for i,s in enumerate(picks)]

def _make_hardened_png(path:Path, seed:int):
    path.parent.mkdir(parents=True,exist_ok=True)
    im=Image.new('RGB',(960,540),(248,248,248)); d=ImageDraw.Draw(im)
    # Real decoded pixels with distributed semantic-looking visual mass in every quarter.
    # Seed changes geometry/tones so hashes are distinct while all pages remain nonblank.
    accent=(164,35,101); teal=(7,115,129); navy=(32,59,112)
    off=(seed*17)%38
    d.rectangle((45,55,915,105),fill=(235,224,230),outline=accent,width=3)
    d.rectangle((55,145,430,390),fill=(226,235,245),outline=navy,width=4)
    d.rectangle((515,145,900,390),fill=(222,238,239),outline=teal,width=4)
    for i in range(4):
        y=175+i*46+((seed+i)%3)
        d.line((80,y,390-off//2,y),fill=navy,width=4)
        d.line((545,y,865-off//3,y),fill=teal,width=4)
    d.rectangle((120+off,420,840-off,470),fill=(247,238,243),outline=accent,width=3)
    d.line((120,495,840,495),fill=accent,width=5)
    im.save(path)
    return path

def _fixture_review(path:Path, seed:int):
    h=sha256_file(path); pm=measure_render(path,expected_hash=h)
    if pm.get('status')!='PASS': raise RuntimeError('HARDENED_PIXEL_FIXTURE_INVALID:'+repr(pm))
    scores={k:94.0 for k in ['message_clarity','five_second_comprehension','visual_form_fitness','simplicity','executive_hierarchy','evidence_legibility','artifact_usefulness','specificity_to_page','rtl_typography','brand_fidelity','production_quality']}
    basis={'schema':'RASHAD_REVIEW_BASIS_V1','actual_render_hash':h,'pixel_measurement_sha256':pm['measurement_sha256'],'inspection_basis':['ACTUAL_RENDER_PIXELS','HARDENED_STRESS_FIXTURE']}
    core={'status':'PASS','independent':True,'review_id':f'STRESS-REV-{seed:02d}','actor_id':'QA-V732-STRESS-FIXTURE-JUDGE','actual_render_hash':h,'scores':scores,'generic_layout_swap_test':'PASS','artifact_skeptic_test':'PASS','five_second_test':'PASS','hard_blockers':[],'artifact_truth_score':94.0,'ceqs_score':94.0,'review_basis':basis,'pixel_measurement':pm}
    core['review_execution_proof']={'schema':'RASHAD_REVIEW_EXECUTION_PROOF_V1','challenge_id':f'STRESS-CH-{seed:02d}','request_sha256':hashlib.sha256(json.dumps({'render':h,'measurement':pm['measurement_sha256'],'seed':seed},sort_keys=True).encode()).hexdigest(),'actual_render_hash':h,'reviewer_callable_origin':'QA_STRESS_HARDENED_PIXEL_FIXTURE','response_sha256':hashlib.sha256(json.dumps(core,sort_keys=True,default=str).encode()).hexdigest()}
    return core

def build_real_corpus(td:Path):
    cycle=['STATEMENT_LED','NUMBER_LED','EVIDENCE_LED','TABLE_LED','CHART_LED','COMPARISON_LED','MATRIX_LED','DECISION_LED','SEQUENCE_LED','PROCESS_LED','SYSTEM_LED','ARCHITECTURE_LED','IMAGE_LED','HYBRID_EXHIBIT','SCORECARD_LED']
    out=[]
    for i,strategy in enumerate(cycle,1):
        path=_make_hardened_png(td/f'hardened_{i:02d}.png',i); review=_fixture_review(path,i); h=review['actual_render_hash']
        cp={'page_id':f'CORPUS-{i:02d}','title':'Stress evidence','thesis':'Evidence supports decision','answer_first_thesis':'Evidence supports decision','management_question':'What next?','proof_points':['Evidence 1','Evidence 2','Evidence 3'],'evidence':['E1','E2','E3'],'source_note':'STRESS-SOURCE','language':'AR','numbers':[72,54,38,83] if strategy in {'NUMBER_LED','CHART_LED','SCORECARD_LED'} else []}
        if strategy=='CHART_LED': cp.update(chart_title='Trend',chart_categories=['A','B','C','D'],chart_unit='%')
        graph={'nodes':[{'id':'N1','label':'Evidence','type':'EVIDENCE'},{'id':'N2','label':'Decision','type':'DECISION'},{'id':'N3','label':'Action','type':'PROCESS'}], 'edges':[{'id':'E1','source':'N1','target':'N2','relation':'SUPPORTS'},{'id':'E2','source':'N2','target':'N3','relation':'ENABLES'}]}
        hyp={'id':f'STRESS-H{i:02d}','communication_strategy':strategy,'strategy_family':FAM[strategy],'page_fingerprint':f'STRESS-{i:02d}'}
        spec=build_page_composition_spec(hyp,cp,graph,variant_index=i,reference_grammar_ids=['STRESS-V732'])
        concept=build_projection_concept_admission({'page_id':cp['page_id'],'content_pack':cp,'semantic_graph':graph,'composition_spec':spec},strategy,i)
        if concept.get('status')!='PASS': raise RuntimeError('STRESS_CONCEPT_FIXTURE_INVALID:'+repr(concept))
        out.append({'page_id':cp['page_id'],'selected_render_hash':h,'selected_strategy':strategy,'selected_candidate_id':concept['selected_candidate_id'],'hypotheses':concept['search']['hypotheses'],'visual_concept_id':f'VC-CORPUS-{i:02d}','production_render_id':f'PR-CORPUS-{i:02d}','render_kind':'PRODUCTION_PAGE_RENDER','render_path':str(path),'pixel_measurement':review['pixel_measurement'],'composition_spec':spec,'composition_spec_sha256':spec.get('spec_sha256'),'composition_logic':spec.get('structural_signature') or spec.get('spec_sha256'),'concept_admission':concept['validation'],'concept_admission_proof':concept['proof'],'actual_pixel_review':review,'artifact_truth_score':94.0,'ceqs_score':94.0,'repair_required':False,'repair_history':[],'final_qa_round':1})
    return out

def main():
    crashes=0; unsafe_escaped=0; valid_failed=0; page_runs=4000; deck_runs=800; deck_page_evaluations=0
    mutations=['concept','no_pixel','wrong_hash','low_score','artifact_truth','ceqs','generic','skeptic','five_second','not_independent','repair_missing','hard_blocker','missing_render_path','missing_basis']
    with tempfile.TemporaryDirectory() as td0:
      corpus=build_real_corpus(Path(td0))
      for i in range(page_runs):
        try:
            p=copy.deepcopy(random.choice(corpus)); p['page_id']=f'P{i}'
            bad=random.random()<.72
            if bad:
                m=random.choice(mutations)
                if m=='concept':p['render_kind']='COMMUNICATION_STRATEGY_CONCEPT_RENDER_V3'
                elif m=='no_pixel':p['actual_pixel_review']={'status':'NOT_EXECUTED'}
                elif m=='wrong_hash':p['actual_pixel_review']['actual_render_hash']='0'*64
                elif m=='low_score':p['actual_pixel_review']['scores'][random.choice(list(p['actual_pixel_review']['scores']))]=random.randint(0,79)
                elif m=='artifact_truth':p['actual_pixel_review']['artifact_truth_score']=random.randint(0,89); p['artifact_truth_score']=p['actual_pixel_review']['artifact_truth_score']
                elif m=='ceqs':p['actual_pixel_review']['ceqs_score']=random.randint(0,89); p['ceqs_score']=p['actual_pixel_review']['ceqs_score']
                elif m=='generic':p['actual_pixel_review']['generic_layout_swap_test']='FAIL'
                elif m=='skeptic':p['actual_pixel_review']['artifact_skeptic_test']='FAIL'
                elif m=='five_second':p['actual_pixel_review']['five_second_test']='FAIL'
                elif m=='not_independent':p['actual_pixel_review']['independent']=False
                elif m=='repair_missing':p['repair_required']=True;p['repair_history']=[]
                elif m=='hard_blocker':p['actual_pixel_review']['hard_blockers']=['X']
                elif m=='missing_render_path':p.pop('render_path',None)
                elif m=='missing_basis':p['actual_pixel_review'].pop('review_basis',None)
            r=evaluate_page_output(p,'USER_VISIBLE_ARTIFACT_DRAFT')
            if bad and r['status']!='BLOCKED': unsafe_escaped+=1
            if not bad and r['status']!='PASS': valid_failed+=1
        except Exception: crashes+=1
      deck_mut=['duplicate_hash','diagram_overuse','same_run','low_variety','pixel_missing','generic_composition']
      for j in range(deck_runs):
        try:
            n=random.randint(8,len(corpus)); deck_page_evaluations+=n; pages=[copy.deepcopy(x) for x in random.sample(corpus,n)]; bad=random.random()<.76
            for i,p in enumerate(pages): p['page_id']=f'D{j:03d}-P{i+1:02d}'
            if bad:
                m=random.choice(deck_mut)
                if m=='duplicate_hash':
                    pages[-1]['selected_render_hash']=pages[0]['selected_render_hash'];pages[-1]['actual_pixel_review']['actual_render_hash']=pages[0]['selected_render_hash'];pages[-1]['render_path']=pages[0]['render_path'];pages[-1]['pixel_measurement']=copy.deepcopy(pages[0]['pixel_measurement']);pages[-1]['actual_pixel_review']['review_basis']=copy.deepcopy(pages[0]['actual_pixel_review']['review_basis'])
                elif m=='diagram_overuse':
                    for p in pages[:int(n*.75)]:p['selected_strategy']='SYSTEM_LED'
                elif m=='same_run':
                    for p in pages[:5]:p['selected_strategy']='STATEMENT_LED'
                elif m=='low_variety':
                    for i,p in enumerate(pages):p['selected_strategy']='STATEMENT_LED' if i%2 else 'NUMBER_LED'
                elif m=='pixel_missing':pages[random.randrange(n)]['actual_pixel_review']={'status':'NOT_EXECUTED'}
                elif m=='generic_composition':
                    for p in pages[:6]:p['composition_logic']='SAME'
            r=evaluate_deck_output(pages,visibility='INTERNAL')
            page_bad=any(evaluate_page_output(p,'USER_VISIBLE_ARTIFACT_DRAFT')['status']!='PASS' for p in pages)
            blocked=(r['status']=='BLOCKED' or page_bad)
            if bad and not blocked: unsafe_escaped+=1
            if not bad and blocked: valid_failed+=1
        except Exception: crashes+=1
    out={'suite':'V7.3 Artifact Stress Quality','status':'PASS' if crashes==0 and unsafe_escaped==0 and valid_failed==0 else 'FAIL','page_runs':page_runs,'deck_runs':deck_runs,'operations':page_runs+deck_runs,'crashes':crashes,'unsafe_escaped':unsafe_escaped,'valid_failed':valid_failed,'real_render_corpus_size':len(corpus),'hardened_user_visible_evaluations':page_runs+deck_page_evaluations,'current_quality_floors':['artifact_truth>=90','ceqs>=90'],'fixture_bypass_used':False}
    (OUT/'V7_3_STRESS_QUALITY_RESULTS.json').write_text(json.dumps(out,indent=2),encoding='utf8'); print(json.dumps(out,indent=2)); return 0 if out['status']=='PASS' else 2
if __name__=='__main__': raise SystemExit(main())
