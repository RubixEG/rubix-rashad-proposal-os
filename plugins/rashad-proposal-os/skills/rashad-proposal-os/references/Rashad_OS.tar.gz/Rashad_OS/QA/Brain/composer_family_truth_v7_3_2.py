#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import itertools,json,sys
ROOT=Path(__file__).resolve().parents[2]; QR=ROOT/'QA/Runtime'; BR=ROOT/'Rashad/Brain/runtime'
sys.path[:0]=[str(BR),str(QR),str(ROOT/'QA')]
from brain.composition_spec import build_page_composition_spec
from brain.spec_divergence import distance as structural_distance
from lib.certification_provenance import load_authenticated_json
OUT=ROOT/'QA/Certification/COMPOSER_FAMILY_TRUTH_V7_3_2.json'
REGISTRY=json.loads((ROOT/'Rashad/Brain/config/artifact_brain_expert_universe_v3.json').read_text(encoding='utf-8'))
STRATEGIES=list(REGISTRY['communication_strategy_universe'])
SUBDIR='COMPOSER_FAMILY_V7_3_2'

def _cp(st):
    cp={'page_id':'P01','page_role':'ARCHITECTURE','language':'AR','title':'منهجية التنفيذ المتكاملة',
        'thesis':'نظام مترابط يحول القرار إلى تنفيذ قابل للقياس والإثبات',
        'proof_points':['الحوكمة تحدد القرار','التنفيذ يحول القرار إلى عمل','القياس يثبت الأثر','المراجعة تغلق حلقة التحسين'],
        'executive_implication':'المقيّم يرى نظام تشغيل مترابطًا يمكن استمراره بعد انتهاء العقد',
        'source_note':'EV-0001','source_id':'EV-0001','output_classification':'USER_VISIBLE_ARTIFACT_DRAFT'}
    if st=='CHART_LED': cp.update(chart_values=[72,54,68,83],chart_evidence_refs=['EV-0001']*4,chart_categories=['الحوكمة','القياس','التنفيذ','التحسين'],chart_title='مؤشر جاهزية التنفيذ',chart_unit='٪')
    return cp

def main():
    rows=[]; auth=[]
    for st in STRATEGIES:
        name=f'{SUBDIR}/{st}.json'; d,v=load_authenticated_json(name)
        auth.append({'strategy':st,'evidence':name,'status':v.get('status'),'reason':v.get('reason'),'producer_suite':v.get('producer_suite')})
        if v.get('status')!='PASS': rows.append({'strategy':st,'status':'FAIL','stage':'EVIDENCE_AUTH','detail':v}); continue
        rows.append(d)
    graph=json.loads((QR/'fixtures/graph.json').read_text(encoding='utf-8'))
    profile=json.loads((QR/'config/profile_font_waiver.json').read_text(encoding='utf-8'))
    v4=json.loads((QR/'config/profile_v4.json').read_text(encoding='utf-8'))
    quality_bound=(profile.get('thresholds')==v4.get('thresholds') and profile.get('brand_lock')==v4.get('brand_lock'))
    tau=float((profile.get('thresholds') or {}).get('anti_template_tau',.085))
    specs=[]
    for i,st in enumerate(STRATEGIES):
        hyp={'id':f'H{i+1}','communication_strategy':st,'strategy_family':'RELATIONAL','page_fingerprint':f'V732-{st}'}
        specs.append(build_page_composition_spec(hyp,_cp(st),graph,variant_index=i,reference_grammar_ids=['V732-PRODUCTION-CERT']))
    pairs=[]
    for (i,a),(j,b) in itertools.combinations(enumerate(specs),2):
        dist=float(structural_distance(a,b)); pairs.append({'a':STRATEGIES[i],'b':STRATEGIES[j],'distance':round(dist,4),'required_min':tau,'status':'PASS' if dist>=tau else 'FAIL'})
    variety_ok=all(x['status']=='PASS' for x in pairs)
    all_ok=(len(rows)==len(STRATEGIES) and all(x.get('status')=='PASS' for x in rows) and all(x['status']=='PASS' for x in auth) and variety_ok and quality_bound)
    out={'suite':'Rashad v7.3.2 Full Communication-Strategy Production Truth Aggregator','status':'PASS' if all_ok else 'FAIL',
         'passed':sum(x.get('status')=='PASS' for x in rows),'total':len(STRATEGIES),
         'profile':'profile_font_waiver.json','production_v4_quality_bound':quality_bound,
         'evidence_authentication':auth,'strategies':rows,
         'anti_template':{'status':'PASS' if variety_ok else 'FAIL','tau':tau,'pairs':pairs},
         'execution':'CURRENT_RUN_AUTHENTICATED_FULL_STRATEGY_UNIVERSE_PROBES_PLUS_DIRECT_ANTI_TEMPLATE_COMPUTATION',
         'rules':['no family result can be consumed unless produced in the current FINAL_VERIFY run','font waiver may not change any production-v4 quality threshold','every registered communication strategy probe must pass','all pairwise structural distances meet production tau']}
    OUT.parent.mkdir(parents=True,exist_ok=True); OUT.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(out,ensure_ascii=False,indent=2)); return 0 if all_ok else 2
if __name__=='__main__': raise SystemExit(main())
