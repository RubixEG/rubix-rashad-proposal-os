#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import importlib.util,json,sys,tempfile
ROOT=Path(__file__).resolve().parents[2]; QA=ROOT/'QA'; CERT=QA/'Certification'
sys.path[:0]=[str(ROOT/'Rashad/Brain/runtime'),str(ROOT/'QA/Runtime'),str(QA)]
from lib.certification_provenance import load_authenticated_json, validate_evidence_file
from brain.authority_compiler import validate_authority_routing
from brain.depth_enforcement import load_contract
from brain.artifact_council_runtime import natural_role_coverage
from brain.router import natural_trigger_coverage
from brain.artifact_brain import STRATEGIES as RUNTIME_STRATEGIES

def _load_module(path,name):
    spec=importlib.util.spec_from_file_location(name,path); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def row(detector,status,basis,detail=None): return {'detector':detector,'status':status,'closure_basis':basis,'detail':detail}

def main():
    rows=[]
    # First authenticate producer evidence from THIS FINAL_VERIFY run before any replay.
    rt_record,rt_auth=load_authenticated_json('V7_3_2_ADVERSARIAL_CLOSURE.json')
    council_record,council_auth=load_authenticated_json('COUNCIL_DEPTH_ACCEPTANCE_V7_3_2.json')
    fam,fam_auth=load_authenticated_json('COMPOSER_FAMILY_TRUTH_V7_3_2.json')
    eng,eng_auth=load_authenticated_json('ENGAGEMENT_ARTIFACT_ACCEPTANCE_V7_3.json')
    rows.append(row('D-HERMETIC-REDTEAM-EVIDENCE-AUTH','PASS' if rt_auth.get('status')=='PASS' else 'FAIL','CURRENT_RUN_HASH_BOUND_EVIDENCE',rt_auth))
    rows.append(row('D-HERMETIC-COUNCIL-EVIDENCE-AUTH','PASS' if council_auth.get('status')=='PASS' else 'FAIL','CURRENT_RUN_HASH_BOUND_EVIDENCE',council_auth))

    # Then independently re-execute the behavioral suites to TEMP paths so the
    # authenticated producer records cannot be overwritten by the checker.
    with tempfile.TemporaryDirectory(prefix='rashad-v732-matrix-replay-') as td:
        td=Path(td)
        rtmod=_load_module(QA/'Brain/red_team_v7_3_2_remediation.py','v732_rt_matrix_replay')
        rcrc=rtmod.main(td/'redteam.json'); replay=json.loads((td/'redteam.json').read_text(encoding='utf-8'))
        for t in replay.get('tests',[]): rows.append(row('BEHAVIOR::'+t.get('name','UNKNOWN'),t.get('status'),'DIRECT_RUNTIME_REEXECUTION',t.get('detail')))
        cmod=_load_module(QA/'Brain/council_depth_acceptance_v7_3_2.py','v732_council_matrix_replay')
        ccrc=cmod.main(td/'council.json'); creplay=json.loads((td/'council.json').read_text(encoding='utf-8'))
        for t in creplay.get('tests',[]): rows.append(row('COUNCIL::'+t.get('name','UNKNOWN'),t.get('status'),'DIRECT_COUNCIL_SME_REEXECUTION',t.get('detail')))

    # The full authoritative communication-strategy universe is separately
    # executed and authenticated. Never hard-code a historical family count:
    # the runtime strategy registry and expert-universe registry must agree,
    # and certification must cover that exact universe in the current run.
    strategy_registry=json.loads((ROOT/'Rashad/Brain/config/artifact_brain_expert_universe_v3.json').read_text(encoding='utf-8'))
    registered_universe=list(strategy_registry.get('communication_strategy_universe') or [])
    runtime_universe=sorted(RUNTIME_STRATEGIES)
    registered_sorted=sorted(registered_universe)
    expected_count=len(registered_universe)
    certified_names=sorted(str(x.get('strategy')) for x in (fam.get('strategies') or []) if x.get('strategy'))
    universe_equal=(registered_sorted==runtime_universe==certified_names)
    ruler_ok=(fam_auth.get('status')=='PASS' and fam.get('status')=='PASS' and
              fam.get('passed')==expected_count and fam.get('total')==expected_count and
              universe_equal and fam.get('production_v4_quality_bound') is True and
              (fam.get('anti_template') or {}).get('status')=='PASS')
    rows.append(row('D-RULER-FULL-AUTHORITATIVE-STRATEGY-UNIVERSE','PASS' if ruler_ok else 'FAIL',
                    'AUTHENTICATED_CURRENT_RUN_FULL_AUTHORITATIVE_STRATEGY_UNIVERSE',
                    {'auth':fam_auth,'status':fam.get('status'),'passed':fam.get('passed'),'total':fam.get('total'),
                     'expected_count':expected_count,'runtime_count':len(runtime_universe),
                     'registered_runtime_equal':registered_sorted==runtime_universe,
                     'certified_universe_equal':certified_names==registered_sorted,
                     'anti_template':(fam.get('anti_template') or {}).get('status')}))
    # Governance-specific authority routing belongs in a governance detector.
    aq=validate_authority_routing(); rows.append(row('D-NORM-AUTHORITY-ROUTING-DRIFT','PASS' if aq.get('status')=='PASS' else 'FAIL','DIRECT_GOVERNANCE_EXECUTION',aq))
    contract=load_contract(); rows.append(row('D-FLOOR-DEPTH-CONTRACT-EXECUTABLE','PASS' if len(contract.get('roles') or [])==24 and contract.get('mandatory_item_count')==226 else 'FAIL','DIRECT_RUNTIME_EXECUTION',{'roles':len(contract.get('roles') or []),'mandatory_items':contract.get('mandatory_item_count')}))
    ar=natural_role_coverage(); rows.append(row('D-REACH-ARTIFACT-ROLES','PASS' if ar.get('status')=='PASS' and ar.get('registered_roles')==ar.get('naturally_selectable_roles')==107 else 'FAIL','DIRECT_RUNTIME_EXECUTION',ar))
    ids=[r.get('canonical_id') for r in contract.get('roles') or []]; cr=natural_trigger_coverage(ids); rows.append(row('D-REACH-COGNITIVE-COUNCILS','PASS' if cr.get('status')=='PASS' and cr.get('count')==cr.get('total') else 'FAIL','DIRECT_RUNTIME_EXECUTION',cr))
    rows.append(row('D-SUBJECT-REAL-ENGAGEMENT-BYTES','PASS' if eng_auth.get('status')=='PASS' and eng.get('status')=='PASS' and all(x.get('acceptance_status')=='BLOCKED' for x in eng.get('artifacts') or []) else 'FAIL','AUTHENTICATED_REAL_BYTE_INSPECTION',{'auth':eng_auth,'artifacts':eng.get('artifacts')}))
    ok=(rcrc==0 and ccrc==0 and rows and all(x['status']=='PASS' for x in rows))
    out={'suite':'Rashad v7.3.2 Behavioral Remediation Evidence Matrix','status':'PASS' if ok else 'FAIL','rows':rows,'passed':sum(x['status']=='PASS' for x in rows),'total':len(rows),'open':[x['detector'] for x in rows if x['status']!='PASS'],'rule':'Product closures come only from direct behavior re-execution or authenticated current-run product evidence. The matrix never rewrites the evidence it authenticates, and source-string presence is never a product closure predicate.'}
    CERT.mkdir(exist_ok=True); (CERT/'REMEDIATION_MATRIX_V7_3_2.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); print(json.dumps(out,ensure_ascii=False,indent=2)); return 0 if ok else 2

if __name__=='__main__': raise SystemExit(main())
