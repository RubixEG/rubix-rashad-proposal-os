from __future__ import annotations
from pathlib import Path
import hashlib,json,os
ROOT=Path(__file__).resolve().parents[2]
QA=ROOT/'QA'; RASHAD=ROOT/'Rashad'; CERT=QA/'Certification'

def sha256_file(p):
    p=Path(p); return hashlib.sha256(p.read_bytes()).hexdigest()

def source_fingerprint():
    """Fingerprint every shipped source/fixture byte that can affect certification.
    Only generated certification evidence and transient runtime caches are excluded.
    Binary fixtures are intentionally INCLUDED.
    """
    h=hashlib.sha256(); files=[]
    for base in (RASHAD,QA):
        for f in base.rglob('*'):
            if not f.is_file(): continue
            rel=f.relative_to(ROOT).as_posix(); parts=set(f.parts)
            # Exclude only generated QA/Certification evidence, never a source-side directory merely named Certification.
            if rel.startswith('QA/Certification/') or '__pycache__' in parts: continue
            if any(x.startswith('_regression') or x.startswith('_v732_probe') for x in f.parts): continue
            if f.suffix.lower() in {'.pyc'}: continue
            # Runtime-produced evidence/result files are not source; binary fixtures remain included.
            up=f.name.upper()
            if up.endswith(('_RESULTS.JSON','_RESULT.JSON')) or (up.startswith('REGRESSION_') and up.endswith('.JSON')): continue
            if f.name.endswith(('_stdout.txt','.log','.tmp')): continue
            files.append((rel,f))
    for rel,f in sorted(files):
        h.update(rel.encode('utf-8')); h.update(b'\0'); h.update(hashlib.sha256(f.read_bytes()).digest())
    return h.hexdigest()

def run_manifest_path(): return CERT/'CURRENT_RUN_MANIFEST.json'

def load_run_manifest():
    p=run_manifest_path()
    if not p.exists(): return {}
    try:return json.loads(p.read_text(encoding='utf-8'))
    except Exception:return {}

def validate_evidence_file(name, *, require_current_run=True):
    p=CERT/name; out={'status':'FAIL','name':name,'path':str(p)}
    if not p.exists(): out['reason']='MISSING_EVIDENCE_FILE'; return out
    m=load_run_manifest(); rid=os.getenv('RASHAD_CERT_RUN_ID') or m.get('run_id')
    sf=source_fingerprint()
    if require_current_run:
        if not m or m.get('run_id')!=rid: out['reason']='CURRENT_RUN_MANIFEST_MISSING_OR_WRONG_RUN'; return out
        if m.get('source_fingerprint')!=sf: out['reason']='SOURCE_FINGERPRINT_MISMATCH'; return out
    rec=(m.get('evidence_files') or {}).get(name)
    if not rec: out['reason']='EVIDENCE_NOT_PRODUCED_IN_CURRENT_RUN'; return out
    actual=sha256_file(p)
    if rec.get('sha256')!=actual: out['reason']='EVIDENCE_HASH_MISMATCH'; return out
    producer=rec.get('producer_suite')
    suite=(m.get('suites') or {}).get(producer) or {}
    if suite.get('status')!='PASS': out['reason']='EVIDENCE_PRODUCER_NOT_PASS'; return out
    if not rec.get('suite_module_sha256') or rec.get('suite_module_sha256')!=suite.get('module_sha256'):
        out['reason']='EVIDENCE_PRODUCER_MODULE_HASH_MISMATCH'; return out
    out.update(status='PASS',sha256=actual,run_id=rid,source_fingerprint=sf,producer_suite=producer)
    return out

def load_authenticated_json(name):
    v=validate_evidence_file(name)
    if v.get('status')!='PASS': return {},v
    try:return json.loads((CERT/name).read_text(encoding='utf-8')),v
    except Exception as e:return {},{'status':'FAIL','reason':'INVALID_JSON','detail':repr(e),'name':name}
