from __future__ import annotations
from pathlib import Path
import hashlib,json

from brain.orchestrator import run_brain
from brain.provider import ScriptedTestProvider
from brain.artifact_council_runtime import execute_artifact_councils
from brain.production_quality_judge import deterministic_pixel_review,deterministic_deck_review
from brain.product_inspector import inspect_pptx,sha256_file
from brain.actual_output_qa import evaluate_deck_output
from brain.deck_continuity import evaluate_ledger as evaluate_deck_continuity
from brain.style_memory import validate_style_convergence
from brain.composition_spec import build_page_composition_spec
from brain.concept_quality_judge import attach_concept_admission, validate_concept_admission
from production_test_fixtures_v7_3 import build_production_projection

DEFAULT_STRATEGIES=['IMAGE_LED','STATEMENT_LED','NUMBER_LED','TABLE_LED','CHART_LED','PROCESS_LED','COMPARISON_LED','DECISION_LED']
_FAMILY={
 'IMAGE_LED':'IMAGE','STATEMENT_LED':'MINIMAL','NUMBER_LED':'MINIMAL','TABLE_LED':'ANALYTICAL',
 'CHART_LED':'QUANTITATIVE','PROCESS_LED':'RELATIONAL','COMPARISON_LED':'ANALYTICAL','DECISION_LED':'DECISION',
 'SYSTEM_LED':'RELATIONAL','ARCHITECTURE_LED':'RELATIONAL','JOURNEY_LED':'RELATIONAL','MATRIX_LED':'ANALYTICAL',
 'EVIDENCE_LED':'ANALYTICAL','HYBRID_EXHIBIT':'HYBRID'
}


def _hypotheses(selected:str, seed:int):
    pool=[selected,'STATEMENT_LED','NUMBER_LED','EVIDENCE_LED','PROCESS_LED','HYBRID_EXHIBIT','COMPARISON_LED','IMAGE_LED']
    seen=[]
    for x in pool:
        if x not in seen: seen.append(x)
    seen=seen[:5]
    return [
      {'id':f'P{seed:02d}-H{i+1}','communication_strategy':s,'strategy_family':_FAMILY.get(s,'ANALYTICAL'),'structural_signature':f'P{seed:02d}|{s}|{i}'}
      for i,s in enumerate(seen)
    ]



def build_projection_concept_admission(proof:dict, strategy:str, seed:int):
    cp=dict(proof.get('content_pack') or {}); graph=dict(proof.get('semantic_graph') or {})
    selected_id=f'P{seed:02d}-SELECTED'
    selected={'id':selected_id,'communication_strategy':strategy,'strategy_family':_FAMILY.get(strategy,'ANALYTICAL'),'structural_signature':proof['composition_spec'].get('structural_signature'),'composition_spec':proof['composition_spec']}
    pool=['STATEMENT_LED','NUMBER_LED','PROCESS_LED','MATRIX_LED','HYBRID_EXHIBIT','DECISION_LED','IMAGE_LED','EVIDENCE_LED']
    hyps=[selected]; used={strategy}
    for j,st in enumerate(pool,1):
        if st in used: continue
        h={'id':f'P{seed:02d}-ALT{j}','communication_strategy':st,'strategy_family':_FAMILY.get(st,'ANALYTICAL'),'page_fingerprint':f'CERT-ALT-{seed}-{j}-{st}'}
        spec=build_page_composition_spec(h,cp,graph,variant_index=30+seed+j,reference_grammar_ids=['CERT-HARDENED-V732'])
        h['composition_spec']=spec; h['structural_signature']=spec.get('structural_signature'); hyps.append(h); used.add(st)
        if len(hyps)==5: break
    search={'status':'PASS','page_id':proof.get('page_id'),'hypotheses':hyps,'mutations':[],'final_independent_judgment':{'winner_candidate_id':selected_id,'independent':True,'judge_invocation_id':f'QA-V732-CONCEPT-JUDGE-{seed:02d}'}}
    attached=attach_concept_admission(search,selected_id,cp,graph,judge_invocation_id=f'QA-V732-CONCEPT-JUDGE-{seed:02d}')
    if attached.get('status')!='PASS': return {'status':'BLOCKED','reason':'CONCEPT_ATTACH_FAILED','detail':attached}
    bound=attached['search_result']; validation=validate_concept_admission(bound,cp,graph)
    if validation.get('status')!='PASS': return {'status':'BLOCKED','reason':'CONCEPT_VALIDATE_FAILED','detail':validation}
    return {'status':'PASS','search':bound,'validation':validation,'proof':(bound.get('final_independent_judgment') or {}).get('concept_admission_proof'),'selected_candidate_id':selected_id}

def _bound_pixel_review(proof:dict, render:dict, graph:dict):
    req={
      'render_path':render['render_path'],'actual_render_hash':render['actual_render_hash'],
      'composition_spec':proof['composition_spec'],'semantic_graph':graph,
      'html_master_path':render['html_master_path'],'certification_font_waiver':True,
      'admitted_image_sha256':render.get('image_asset_sha256'),
    }
    qa=deterministic_pixel_review(req,actor_id='QA-V732-HARDENED-DELIVERY-PIXEL-JUDGE')
    response_core={k:v for k,v in qa.items() if k!='review_execution_proof'}
    qa['review_execution_proof']={
      'schema':'RASHAD_REVIEW_EXECUTION_PROOF_V1',
      'challenge_id':'QA-V732-HARDENED-'+render['actual_render_hash'][:16],
      'request_sha256':hashlib.sha256(json.dumps({
        'actual_render_hash':render['actual_render_hash'],
        'composition_spec_sha256':proof['composition_spec'].get('spec_sha256'),
        'suite_fixture':'HARDENED_DELIVERY_V7_3_2',
      },sort_keys=True).encode()).hexdigest(),
      'actual_render_hash':render['actual_render_hash'],
      'reviewer_callable_origin':'brain.production_quality_judge:deterministic_pixel_review',
      'response_sha256':hashlib.sha256(json.dumps(response_core,ensure_ascii=False,sort_keys=True,default=str).encode()).hexdigest(),
    }
    return qa


def _execution_evidence(i:int, strategy:str, render_path:str):
    question=f'REDF page {i}: {strategy} decision evidence AI cybersecurity commercial delivery'
    task={'task_id':f'V732-HARD-P{i:02d}','rfp_role':'MANAGEMENT_DECISION','critical':True,'rendered':True,'deck_level':False,'question':question,'evidence':[{'id':'E1','source':'hardened-production-fixture'}]}
    provider=ScriptedTestProvider(); brain=run_brain(task,provider)
    graph={'nodes':[{'id':'N1','label':'Evidence'},{'id':'N2','label':'Decision'}],'edges':[{'source':'N1','target':'N2','relation':'SUPPORTS'}]}
    content={'page_id':f'P{i:02d}','thesis':question,'answer_first_thesis':question,'evidence':['E1'],'language':'AR','numbers':[87.5,70,80] if strategy in {'NUMBER_LED','CHART_LED'} else []}
    pre=execute_artifact_councils(graph,content,provider,'AR','PRE_CONCEPT')
    art=execute_artifact_councils(graph,content,provider,'AR','ART_DIRECTION',prior={'strategy':strategy})
    prod=execute_artifact_councils(graph,content,provider,'AR','PRODUCTION_READINESS',prior={'strategy':strategy})
    return brain,pre,art,prod


def build_hardened_user_visible_fixture(td:Path, strategies=None):
    td=Path(td); strategies=list(strategies or DEFAULT_STRATEGIES)
    projection=build_production_projection(td/'production',strategies)
    if projection.get('status')!='PASS': return {'status':'BLOCKED','reason':'PROJECTION_BUILD_FAILED','projection':projection}
    pages=[]
    for i,strategy in enumerate(strategies,1):
        proof=projection['pages'][i-1]; render=projection['renders'][i-1]
        graph=proof.get('semantic_graph') or {}
        brain,pre,art,prod=_execution_evidence(i,strategy,render['render_path'])
        concept=build_projection_concept_admission(proof,strategy,i)
        if concept.get('status')!='PASS': return {'status':'BLOCKED','reason':'CONCEPT_ADMISSION_NOT_PASS','page':i,'concept':concept}
        pixel=_bound_pixel_review(proof,render,graph)
        if pixel.get('status')!='PASS': return {'status':'BLOCKED','reason':'PIXEL_REVIEW_NOT_PASS','page':i,'review':pixel}
        page={
          'page_id':proof['page_id'],'selected_render_hash':render['actual_render_hash'],'selected_strategy':strategy,
          'selected_candidate_id':concept['selected_candidate_id'],'hypotheses':concept['search']['hypotheses'],
          'visual_concept_id':f'VC-PROD-{i:02d}-{strategy}','production_render_id':render['production_render_id'],
          'render_kind':'PRODUCTION_PAGE_RENDER','render_path':render['render_path'],'pixel_measurement':pixel.get('pixel_measurement'),
          'actual_pixel_review':pixel,'artifact_truth_score':pixel.get('artifact_truth_score'),'ceqs_score':pixel.get('ceqs_score'),
          'repair_required':False,'repair_history':[],'final_qa_round':1,
          'composition_spec':proof['composition_spec'],'composition_logic':proof['composition_spec'].get('structural_signature') or proof['composition_spec'].get('spec_sha256'),
          'semantic_master_qa':proof['semantic_master_qa'],'html_master_path':proof['html_master_path'],'html_master_sha256':proof['html_master_sha256'],'composition_spec_sha256':proof['composition_spec_sha256'],
          'brain_session_execution_evidence':brain,'expert_execution_ledger':brain.get('expert_execution_ledger'),
          'brain_cognitive_lock_status':'PASS' if brain.get('state')=='COGNITIVE_LOCKED' else 'BLOCKED',
          'expert_execution_status':'PASS' if (brain.get('expert_execution_ledger') or {}).get('status')=='PASS' else 'BLOCKED',
          'artifact_council_execution':pre,'artifact_council_execution_status':pre.get('status'),
          'art_direction_execution':art,'art_direction_execution_status':art.get('status'),
          'production_council_execution':prod,'production_council_execution_status':prod.get('status'),
          'material_claim_ids':[],'claim_visual_bindings':[],
          'concept_admission':concept['validation'],'concept_admission_proof':concept['proof'],
          'draft_mark_visible':bool((pixel.get('production_preexport_qa') or {}).get('draft_mark_visible')),
        }
        pages.append(page)
    ppt=Path(projection['pptx_path']); montage=Path(projection['montage_path']); dh=sha256_file(ppt); mh=sha256_file(montage)
    deck_graph={'nodes':[{'id':'D1'},{'id':'D2'}],'edges':[{'source':'D1','target':'D2','relation':'SEQUENCES'}]}
    deck_content={'page_id':'DECK','thesis':'REDF executive decision narrative','evidence':['E1'],'language':'AR'}
    deck_exec=execute_artifact_councils(deck_graph,deck_content,ScriptedTestProvider(),'AR','DECK_REVIEW')
    deck_review=deterministic_deck_review(montage,dh,mh,pages,actor_id='QA-V732-HARDENED-DELIVERY-DECK-JUDGE')
    continuity=[]
    for pg in pages:
        continuity.append({'page_id':pg['page_id'],'master_path':pg['render_path'],'master_sha256':pg['selected_render_hash'],'previous_page_id':continuity[-1]['page_id'] if continuity else None})
    continuity_qa=evaluate_deck_continuity({'pages':continuity})
    style_qa=validate_style_convergence([pg['composition_spec'] for pg in pages])
    product=inspect_pptx(ppt,pages)
    deck_qa=evaluate_deck_output(pages,'USER_VISIBLE_ARTIFACT_DRAFT',deck_review,dh,mh,product)
    dossier={
      'schema':'RASHAD_USER_VISIBLE_ARTIFACT_DELIVERY_V2','classification':'USER_VISIBLE_ARTIFACT_DRAFT',
      'output_file_sha256':dh,'montage_sha256':mh,'montage_path':str(montage),'pages':pages,
      'artifact_brain_execution_status':'PASS' if all(p['expert_execution_status']=='PASS' and p['artifact_council_execution_status']=='PASS' and p['art_direction_execution_status']=='PASS' and p['production_council_execution_status']=='PASS' for p in pages) else 'BLOCKED',
      'deck_artifact_council_execution':deck_exec,'production_render_status':'PASS',
      'actual_output_qa_closed_loop_status':'PASS' if deck_qa.get('status')=='PASS' else 'BLOCKED',
      'deck_pixel_review':deck_review,'product_inspection':product,'deck_continuity_qa':continuity_qa,'style_convergence_qa':style_qa,
      'projection_media_binding':projection['projection_media_binding'],'framework_certification_substitute':False,
      'independent_judgment_status':'NOT_EXECUTED','parity_status':'NOT_EXECUTED','proof_index_status':'NOT_EXECUTED','release':{},
    }
    return {'status':'PASS' if deck_qa.get('status')=='PASS' and product.get('status')=='PASS' and continuity_qa.get('status')=='PASS' and style_qa.get('status')=='PASS' else 'BLOCKED',
            'projection':projection,'pages':pages,'pptx_path':str(ppt),'montage_path':str(montage),'deck_review':deck_review,'deck_exec':deck_exec,'product':product,'deck_qa':deck_qa,'dossier':dossier}
