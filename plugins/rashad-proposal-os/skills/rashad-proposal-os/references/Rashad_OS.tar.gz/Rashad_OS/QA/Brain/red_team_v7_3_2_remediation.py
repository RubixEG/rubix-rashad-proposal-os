#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import copy,hashlib,json,os,shutil,sys,tempfile,zipfile

ROOT=Path(__file__).resolve().parents[2]
BR=ROOT/'Rashad/Brain/runtime'; QR=ROOT/'QA/Runtime'; CERT=ROOT/'QA/Certification'
sys.path[:0]=[str(BR),str(QR),str(ROOT/'QA')]

from PIL import Image, ImageDraw
import numpy as np
from pptx import Presentation
from pptx.util import Inches
from pptx.enum.shapes import MSO_SHAPE

from brain.depth_enforcement import load_contract, validate_role_output
from brain.artifact_council_runtime import natural_role_coverage, execute_artifact_councils
from brain.router import natural_trigger_coverage
from brain.provider import AdversarialCouncilProvider
from brain.composition_spec import build_page_composition_spec
from brain.visual_search import generate_hypotheses
from brain.concept_quality_judge import attach_concept_admission, validate_concept_admission
from brain.repair_engine import repair_spec
from brain.production.renderer import render_composition_page
from brain.production_quality_judge import deterministic_pixel_review
from brain.semantic_master_gate import inspect_semantic_html_master
from brain.actual_output_qa import evaluate_page_output
from brain.product_inspector import inspect_pptx
from brain.image_asset_scanner import scan_image, sha256_file
from brain.imagery_director import validate_image_plate
from brain.production.projector import build_image_master_pptx, verify_projection_media_binding
from brain.production.deck_assembly import assemble_certified_deck
from brain.production.font_preflight import check_brand_fonts
from validation.execution_dossier_v4 import validate_product_index_v4
from lib.certification_provenance import source_fingerprint, validate_evidence_file
from lib.certification_scheduler import topological_items

OUT=CERT/'V7_3_2_ADVERSARIAL_CLOSURE.json'

def t(name, ok, detail=None): return {'name':name,'status':'PASS' if ok else 'FAIL','detail':detail}
def dump(p,o): p=Path(p); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(o,ensure_ascii=False,indent=2),encoding='utf-8')
def h(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def page_inputs():
    cp={'page_id':'RT-P01','page_role':'ARCHITECTURE','language':'AR','title':'كيف تعمل منظومة التنفيذ؟','thesis':'منظومة مترابطة تربط الحوكمة والتنفيذ والقياس بالأدلة.','proof_points':['الحوكمة تحدد القرار','التنفيذ يحول القرار إلى عمل','القياس يثبت الأثر'],'executive_implication':'كل انتقال يجب أن يكون قابلًا للإثبات والاعتماد.','source_id':'EV-0001','output_classification':'USER_VISIBLE_ARTIFACT_DRAFT'}
    g={'nodes':[{'id':'N1','label':'الحوكمة','type':'CONTROL'},{'id':'N2','label':'التنفيذ','type':'PROCESS'},{'id':'N3','label':'القياس','type':'EVIDENCE'}], 'edges':[{'id':'E1','source':'N1','target':'N2','relation':'ENABLES'},{'id':'E2','source':'N2','target':'N3','relation':'EVIDENCES'}]}
    hyp={'id':'H1','communication_strategy':'SYSTEM_LED','strategy_family':'SYSTEM','page_fingerprint':'RT-732'}
    return cp,g,hyp

def make_near_white_deck(path):
    td=Path(path).parent/'rt_imgs'; td.mkdir(exist_ok=True)
    prs=Presentation(); prs.slide_width=Inches(13.333333); prs.slide_height=Inches(7.5); blank=prs.slide_layouts[6]
    for i in range(3):
        im=Image.new('RGB',(1920,1080),'white'); im.putpixel((20+i,20),(250,250,250)); fp=td/f'w{i}.png'; im.save(fp)
        s=prs.slides.add_slide(blank); s.shapes.add_picture(str(fp),0,0,width=prs.slide_width,height=prs.slide_height)
        s.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(12.9), Inches(7.1), Inches(.05), Inches(.05))
    prs.save(path)

def make_valid_dossier(root):
    # Mirrors QA's valid synthetic proof, but deliberately has no noncritical family declaration.
    p=Path(root); (p/'visual_search').mkdir(parents=True); (p/'qa').mkdir(parents=True)
    dump(p/'content_pack.json',{'page_id':'P1','page_family':'ANALYTICAL','claims':['c1']})
    dump(p/'relationship_graph.json',{'page_id':'P1','nodes':[{'id':'N1'}],'edges':[]})
    hs=[{'id':f'H{i+1}','topology':f'T{i+1}','reading_path':f'R{i+1}','relation_carriers':[f'C{i+1}'],'mass_plan':f'M{i+1}','focal_point':f'F{i+1}'} for i in range(5)]
    dump(p/'exhibit_hypotheses.json',{'page_id':'P1','hypotheses':hs}); dump(p/'exhibit_selection.json',{'page_id':'P1','winner':'H1','rejected':['H2','H3','H4','H5']}); dump(p/'evidence_pack.json',{'page_id':'P1','claims':[{'id':'c1','source_id':'SRC1','locator':'p1'}]})
    cands=[]
    for i in range(3): q=p/'visual_search'/f'c{i+1}.png'; q.write_bytes((f'candidate-{i}').encode()); cands.append({'id':f'C{i+1}','path':q.name})
    dump(p/'visual_search/manifest.json',{'page_id':'P1','candidates':cands,'structural_divergence':{'min_pairwise':0.2,'average_pairwise':0.24}})
    dump(p/'artifact_truth.json',{'page_id':'P1','status':'PASS','artifact_truth_score':94,'owner':'INDEPENDENT_ARTIFACT_JUDGE','independent':True,'judge_invocation_id':'J1','render_evidence':['N1'],'actual_render_hash':h(p/'visual_search/c1.png')})
    Image.new('RGB',(3840,2160),'white').save(p/'final_page_master.png'); mh=h(p/'final_page_master.png')
    dump(p/'ceqs.json',{'page_id':'P1','status':'PASS','ceqs':93,'owner':'INDEPENDENT_VISUAL_CRITIC','independent':True,'judge_invocation_id':'J2','visual_evidence':['m'],'actual_render_hash':mh})
    dump(p/'qa/html_report.json',{'release_verdict':'HTML_PREEXPORT_PASS','pages':[{'gates':[{'id':'C9_PIXEL','status':'PASS','test_count':1,'measured':{'count':1}}]}]})
    states=['INGESTED','CONTENT_LOCKED','GRAPH_LOCKED','ARTIFACT_TRUTH_PASS','EXHIBIT_SEARCH_COMPLETE','WINNER_LOCKED','VISUAL_SEARCH_COMPLETE','CEQS_PASS','PAGE_MASTER_LOCKED','PAGE_QA_PASS']; dump(p/'state_transitions.json',[{'state':s} for s in states])

def main(out_path=None):
    rows=[]
    contract=load_contract(); role_ids=[x['canonical_id'] for x in contract['roles']]
    rows.append(t('depth_contract_machine_readable_24_roles_226_items',len(role_ids)==24 and contract.get('mandatory_item_count')==226,{'roles':len(role_ids),'items':contract.get('mandatory_item_count')}))
    risk=validate_role_output('RISKS',{'page_ids':['P1'],'risk_rows':[{'risk':'R'}]},context={}); rows.append(t('depth_risk_missing_owner_treatment_residual_blocks',risk['status']=='BLOCKED' and all(any(k in b for b in risk['blockers']) for k in ('MISSING_OWNER','MISSING_TREATMENT','MISSING_RESIDUAL_RISK')),risk['blockers'][-12:]))
    clar=validate_role_output('CLARIFICATIONS',{'page_ids':['P1'],'clarification_rows':[{'observation':'x','default_assumption':'y','decision_delta':'z','impact':'h','treatment':'t','question_to_client':'send'}]},context={'clarification_window_status':'CLOSED'}); rows.append(t('closed_clarification_window_forbids_outbound_question',any('CLOSED_WINDOW_OUTBOUND_QUESTION_FORBIDDEN' in b for b in clar['blockers']),clar['blockers']))
    dates=validate_role_output('KEY_DATES',{'page_ids':['P1'],'date_fields':[{'field':'submission','source_values':['05/03/1448','07/03/1448'],'status':'KNOWN'}]},context={}); rows.append(t('conflicting_dates_require_conflict_register',any('MULTIPLE_SOURCE_VALUES_REQUIRE_CONFLICT_STATUS' in b for b in dates['blockers']) and any('DATE_CONFLICT_REGISTER_ID_REQUIRED' in b for b in dates['blockers']),dates['blockers']))
    ar=natural_role_coverage(); rows.append(t('artifact_roles_naturally_selectable_107_of_107',ar.get('status')=='PASS' and ar.get('registered_roles')==107 and ar.get('naturally_selectable_roles')==107,ar))
    cr=natural_trigger_coverage(role_ids); rows.append(t('cognitive_councils_sentinels_and_triggers_reach_all_16',cr.get('status')=='PASS' and cr.get('count')==cr.get('total')==16,cr))
    council=execute_artifact_councils({'nodes':[{'id':'N1'}],'edges':[]},{'page_id':'P1','page_role':'RISKS','language':'AR'},provider=AdversarialCouncilProvider(severity='CRITICAL',veto=False),stage='PRE_CONCEPT'); rows.append(t('open_critical_council_finding_blocks_without_explicit_veto',council.get('status')=='BLOCKED' and any(x.get('kind')=='ARTIFACT_COUNCIL_OPEN_HIGH_SEVERITY_FINDING' for x in council.get('errors',[])),council.get('errors')))

    # Status-shadowing attack: a blocked composition search may never inherit a stale PASS from the communication layer.
    bad_cp,bad_graph,_=page_inputs(); bad_search=generate_hypotheses(bad_graph,bad_cp)
    rows.append(t('composition_diversity_failure_cannot_be_shadowed_to_pass',bad_search.get('status')=='FAIL' and bad_search.get('reason')=='COMPOSITION_SPEC_DIVERSITY_FAILED' and (bad_search.get('composition') or {}).get('status')=='BLOCKED',{'status':bad_search.get('status'),'reason':bad_search.get('reason'),'composition_status':(bad_search.get('composition') or {}).get('status')}))

    # Concept-admission authority: independent selection is necessary but a numeric score is never sufficient.
    ccp={'page_id':'CQ-P01','language':'AR','title':'قرار الإدارة','thesis':'القرار مشروط بإغلاق الأدلة الحرجة.','answer_first_thesis':'القرار مشروط بإغلاق الأدلة الحرجة.','management_question':'هل ندخل؟','proof_points':['دليل مثبت','أثر إداري','إجراء قبول'],'evidence':['E1'],'source_note':'SRC-CQ'}
    cgraph={'nodes':[{'id':'N1','label':'دليل','type':'EVIDENCE'},{'id':'N2','label':'قرار','type':'DECISION'},{'id':'N3','label':'تنفيذ','type':'PROCESS'}], 'edges':[{'id':'E1','source':'N1','target':'N2','relation':'SUPPORTS'},{'id':'E2','source':'N2','target':'N3','relation':'ENABLES'}]}
    csearch=generate_hypotheses(cgraph,ccp); cwinner=csearch['hypotheses'][0]['id']
    high_score=copy.deepcopy(csearch); high_score['final_independent_judgment']={'winner_candidate_id':cwinner,'independent':True,'judge_invocation_id':'FORGED-SCORE','score':999}
    hv=validate_concept_admission(high_score,ccp,cgraph)
    rows.append(t('forged_high_concept_score_without_proof_blocks',hv.get('status')=='BLOCKED' and 'CONCEPT_ADMISSION_PROOF_REQUIRED' in hv.get('blockers',[]),hv.get('blockers')))
    attached=attach_concept_admission(csearch,cwinner,ccp,cgraph,judge_invocation_id='REAL-CONCEPT-JUDGE')
    valid_search=attached.get('search_result') or {}
    vv=validate_concept_admission(valid_search,ccp,cgraph)
    rows.append(t('hash_bound_concept_admission_proof_passes',attached.get('status')=='PASS' and vv.get('status')=='PASS',{'attach':attached.get('status'),'validate':vv.get('status'),'blockers':vv.get('blockers')}))
    score_tamper=copy.deepcopy(valid_search); score_tamper['final_independent_judgment']['score']=999999
    sv=validate_concept_admission(score_tamper,ccp,cgraph)
    rows.append(t('caller_numeric_concept_score_has_no_release_authority',sv.get('status')=='PASS',{'status':sv.get('status'),'blockers':sv.get('blockers')}))
    other=valid_search['hypotheses'][1]['id']; winner_tamper=copy.deepcopy(valid_search); winner_tamper['final_independent_judgment']['winner_candidate_id']=other
    wv=validate_concept_admission(winner_tamper,ccp,cgraph)
    rows.append(t('concept_proof_copied_to_different_winner_blocks',wv.get('status')=='BLOCKED' and any(x in wv.get('blockers',[]) for x in ('CONCEPT_ADMISSION_WINNER_MISMATCH','CONCEPT_ADMISSION_PROOF_MISMATCH')),wv.get('blockers')))
    spec_tamper=copy.deepcopy(valid_search); spec_tamper['hypotheses'][0]['composition_spec']['dominant_mass_target']=0.97
    spv=validate_concept_admission(spec_tamper,ccp,cgraph)
    rows.append(t('concept_proof_after_spec_mutation_blocks',spv.get('status')=='BLOCKED' and any('SPEC' in x or 'PROOF_MISMATCH' in x for x in spv.get('blockers',[])),spv.get('blockers')))
    graph_tamper=copy.deepcopy(cgraph); graph_tamper['nodes'].append({'id':'NX','label':'عنصر جديد','type':'EVIDENCE'})
    gv=validate_concept_admission(valid_search,ccp,graph_tamper)
    rows.append(t('concept_proof_cannot_be_reused_for_different_semantic_graph',gv.get('status')=='BLOCKED' and ('CONCEPT_ADMISSION_PROOF_MISMATCH' in gv.get('blockers',[]) or 'CONCEPT_TOPOLOGY_NODE_BINDING_MISMATCH' in gv.get('blockers',[])),gv.get('blockers')))
    # A pre-repair proof cannot be carried across a valid repaired composition spec.
    original_spec=copy.deepcopy(valid_search['hypotheses'][0]['composition_spec'])
    repaired=repair_spec(original_spec,{'scores':{'visual_form_fitness':40,'production_quality':40},'blockers':['G40_COLUMN_BALANCE']},2)
    stale_repair=copy.deepcopy(valid_search)
    if repaired.get('status')=='PASS':
        stale_repair['hypotheses'][0]['composition_spec']=copy.deepcopy(repaired['spec'])
        stale_repair['hypotheses'][0]['structural_signature']=repaired['spec'].get('structural_signature')
    rv=validate_concept_admission(stale_repair,ccp,cgraph)
    rows.append(t('pre_repair_concept_proof_cannot_authorize_post_repair_spec',repaired.get('status')=='PASS' and rv.get('status')=='BLOCKED' and any(x in rv.get('blockers',[]) for x in ('CONCEPT_ADMISSION_PROOF_MISMATCH','CONCEPT_ADMISSION_SPEC_MISMATCH')),{'repair_status':repaired.get('status'),'old_spec':original_spec.get('spec_sha256'),'new_spec':(repaired.get('spec') or {}).get('spec_sha256'),'validation':rv}))

    with tempfile.TemporaryDirectory() as td0:
        td=Path(td0); cp,g,hyp=page_inputs(); spec=build_page_composition_spec(hyp,cp,g,reference_grammar_ids=['RT-GRAMMAR'])
        rr=render_composition_page(spec,cp,g,td/'real',allow_test_font_fallback=True)
        q=deterministic_pixel_review({'render_path':rr.get('render_path'),'actual_render_hash':rr.get('actual_render_hash'),'composition_spec':spec,'semantic_graph':g,'html_master_path':rr.get('html_master_path'),'certification_font_waiver':True}) if rr.get('status')=='PASS' else {'status':'BLOCKED','hard_blockers':['RENDER_FAIL']}
        rows.append(t('real_composer_to_chromium_to_production_gate_passes',rr.get('status')=='PASS' and q.get('status')=='PASS' and (q.get('production_preexport_qa') or {}).get('draft_mark_visible') is True,{'render':rr.get('status'),'qa':q.get('status'),'blockers':q.get('hard_blockers'),'draft':(q.get('production_preexport_qa') or {}).get('draft_mark_visible')}))
        # Random noise cannot masquerade as a pass, even with a matching declared file hash.
        noise=(np.random.default_rng(732).integers(0,256,(1080,1920,3),dtype=np.uint8)); npth=td/'noise.png'; Image.fromarray(noise).save(npth); nh=h(npth)
        nq=deterministic_pixel_review({'render_path':str(npth),'actual_render_hash':nh,'composition_spec':spec,'semantic_graph':g,'html_master_path':rr.get('html_master_path'),'certification_font_waiver':True})
        rows.append(t('random_rgb_noise_blocks_hardened_production_gate',nq.get('status')=='BLOCKED',nq.get('hard_blockers')))
        # Empty semantic shell bound to the correct spec is still not content-bearing.
        shell=td/'empty.html'; shell.write_text(f'<div data-page-id="P" data-page-mode="ARTIFACT_LED" data-region-id="DOMINANT" data-composition-spec-sha256="{spec.get("spec_sha256")}"></div>',encoding='utf-8'); sm=inspect_semantic_html_master(shell,spec)
        rows.append(t('empty_semantic_master_blocks',sm.get('status')=='BLOCKED' and any('CONTENT_BEARING_FLOOR' in x for x in sm.get('blockers',[])),sm.get('blockers')))
        # Logo/text/digit spoof: caller clean metadata must lose to in-package OCR/CV.
        dirty=td/'dirty.png'; im=Image.new('RGB',(1000,420),'white'); d=ImageDraw.Draw(im); d.rectangle((40,40,190,190),outline='black',width=10); d.text((230,110),'LOGO 123 ACME CORP',fill='black'); im.save(dirty)
        scan=scan_image(dirty); req={'request_sha256':'REQ-X'}; res={'status':'PASS','asset_path':str(dirty),'asset_sha256':sha256_file(dirty),'provider_actor_id':'PROVIDER-X','proof':{'request_sha256':'REQ-X'}}; adm=validate_image_plate(res,req,{'asset_sha256':sha256_file(dirty),'ocr_text':'','contains_logo':False,'contains_digits':False})
        rows.append(t('logo_123_spoof_blocked_by_real_ocr_cv',adm.get('status')=='BLOCKED' and (scan.get('contains_digits') is True or bool(scan.get('ocr_text'))) and any(x in adm.get('blockers',[]) for x in ('GENERATED_IMAGE_CONTAINS_TEXT','GENERATED_IMAGE_DIGITS_NOT_PROVEN_ABSENT','GENERATED_IMAGE_LOGO_NOT_PROVEN_ABSENT')),{'scan':scan,'blockers':adm.get('blockers')}))
        # Projection media binding is recomputed from the PPTX bytes.
        imgs=[]
        for i,c in enumerate(((255,255,255),(245,245,245))): fp=td/f'p{i}.png'; Image.new('RGB',(1920,1080),c).save(fp); imgs.append(fp)
        proj=build_image_master_pptx(imgs,td/'bound.pptx'); reb=verify_projection_media_binding(td/'bound.pptx',proj.get('source_page_render_hashes')); wrong=verify_projection_media_binding(td/'bound.pptx',list(reversed(proj.get('source_page_render_hashes') or [])))
        rows.append(t('pptx_media_hashes_bound_in_slide_order',proj.get('status')=='PASS' and reb.get('status')=='PASS' and wrong.get('status')=='BLOCKED',{'projector':proj.get('media_binding_status'),'recomputed':reb,'wrong_order':wrong.get('reason')}))
        edit=assemble_certified_deck([],td/'edit',output_mode='NATIVE_EDITABLE_PPTX'); rows.append(t('editable_pptx_request_refuses_instead_of_silent_raster_fallback',edit.get('status')=='BLOCKED' and edit.get('reason')=='NATIVE_EDITABLE_PPTX_CAPABILITY_NOT_IMPLEMENTED',edit))
        # Decoy shape must not suppress pixel inspection of a large blank picture.
        dec=td/'decoy.pptx'; make_near_white_deck(dec); pi=inspect_pptx(dec); rows.append(t('decoy_vector_does_not_disable_large_picture_pixel_truth',pi.get('status')=='BLOCKED' and any('PICTURE_PIXEL' in x for x in pi.get('blockers',[])),pi.get('blockers')[:30]))
        # Caller-declared critical:false is ignored by product-level authority.
        droot=td/'dossier'; make_valid_dossier(droot); obj=json.loads((droot/'exhibit_hypotheses.json').read_text()); obj['hypotheses']=obj['hypotheses'][:1]; dump(droot/'exhibit_hypotheses.json',obj); idx=td/'index.json'; dump(idx,{'schema_version':'4.0','pages':[{'page_id':'P1','path':'dossier','critical':False}]}); vr=validate_product_index_v4(idx); kinds=[e.get('kind') for p in vr.get('pages',[]) for e in (p.get('result') or {}).get('errors',[])]
        rows.append(t('critical_false_cannot_waive_analytical_page_checks',vr.get('status')=='FAIL' and 'wrong_hypothesis_count' in kinds,{'status':vr.get('status'),'kinds':kinds,'measured':((vr.get('pages') or [{}])[0].get('result') or {}).get('measured')}))
        # Ambient env var no longer enables font fallback.
        old=os.environ.get('RASHAD_TEST_ALLOW_FONT_FALLBACK'); os.environ['RASHAD_TEST_ALLOW_FONT_FALLBACK']='1'
        try: fp=check_brand_fonts(('Definitely Missing Rashad Font 732',),allow_test_fallback=False)
        finally:
            if old is None: os.environ.pop('RASHAD_TEST_ALLOW_FONT_FALLBACK',None)
            else: os.environ['RASHAD_TEST_ALLOW_FONT_FALLBACK']=old
        rows.append(t('ambient_env_cannot_waive_font_fail_closed',fp.get('status')=='BLOCKED',fp))

    # Certification evidence: a hand-typed file is rejected before the verifier authenticates it.
    CERT.mkdir(parents=True,exist_ok=True); fakep=CERT/'HAND_TYPED_ATTACK.json'; fakep.write_text('{"status":"PASS","tests":[{"status":"PASS"}]}',encoding='utf-8')
    try: va=validate_evidence_file(fakep.name); rows.append(t('hand_typed_pass_evidence_rejected',va.get('status')=='FAIL' and va.get('reason') in {'EVIDENCE_NOT_PRODUCED_IN_CURRENT_RUN','CURRENT_RUN_MANIFEST_MISSING_OR_WRONG_RUN','SOURCE_FINGERPRINT_MISMATCH'},va))
    finally: fakep.unlink(missing_ok=True)

    # Fingerprint must include vendored binary fixtures. Mutate+restore exact bytes during the test.
    fixture=ROOT/'QA/Runtime/fixtures/engagement/REDF_2610089_CLAUDE_NEGATIVE_BASELINE.pptx'; orig=fixture.read_bytes() if fixture.exists() else None
    if orig is not None:
        sf1=source_fingerprint(); fixture.write_bytes(orig+b'RASHAD-FINGERPRINT-ATTACK')
        try: sf2=source_fingerprint()
        finally: fixture.write_bytes(orig)
        sf3=source_fingerprint(); rows.append(t('binary_fixture_bytes_are_source_fingerprinted',sf1!=sf2 and sf1==sf3,{'before':sf1,'mutated':sf2,'restored':sf3}))
    else: rows.append(t('binary_fixture_bytes_are_source_fingerprinted',False,'fixture missing'))

    # Certification scheduler is itself attacked: consumer-before-producer must be reordered,
    # and missing/cyclic evidence graphs must fail rather than silently consume stale state.
    sched=[
      {'name':'consumer','produces':[],'consumes':['X.json']},
      {'name':'producer','produces':['X.json'],'consumes':[]},
    ]
    try:
        ordered=[x['name'] for x in topological_items(sched)]
        rows.append(t('dependency_scheduler_reorders_consumer_after_producer',ordered==['producer','consumer'],ordered))
    except Exception as e:
        rows.append(t('dependency_scheduler_reorders_consumer_after_producer',False,repr(e)))
    try:
        topological_items([{'name':'c','produces':[],'consumes':['MISSING.json']}])
        rows.append(t('dependency_scheduler_blocks_missing_producer',False,'did not raise'))
    except RuntimeError as e:
        rows.append(t('dependency_scheduler_blocks_missing_producer','MISSING_DECLARED_EVIDENCE_PRODUCER' in str(e),str(e)))
    try:
        topological_items([
          {'name':'a','produces':['A.json'],'consumes':['B.json']},
          {'name':'b','produces':['B.json'],'consumes':['A.json']},
        ])
        rows.append(t('dependency_scheduler_blocks_cycles',False,'did not raise'))
    except RuntimeError as e:
        rows.append(t('dependency_scheduler_blocks_cycles','CERTIFICATION_DEPENDENCY_CYCLE' in str(e),str(e)))

    # Font-waiver profile is not a quality waiver.
    v4=json.loads((QR/'config/profile_v4.json').read_text()); fw=json.loads((QR/'config/profile_font_waiver.json').read_text()); rows.append(t('font_waiver_profile_preserves_all_v4_quality_thresholds',v4.get('thresholds')==fw.get('thresholds') and v4.get('brand_lock')==fw.get('brand_lock'),{'same_thresholds':v4.get('thresholds')==fw.get('thresholds'),'same_brand_lock':v4.get('brand_lock')==fw.get('brand_lock')}))

    ok=all(x['status']=='PASS' for x in rows); report={'suite':'Rashad OS v7.3.2 Adversarial Remediation Closure','status':'PASS' if ok else 'FAIL','tests':rows,'passed':sum(x['status']=='PASS' for x in rows),'total':len(rows),'rule':'An attack counts only when it constructs a hostile/defective input and executes the real runtime or product gate; static string-presence assertions are not adversarial tests.'}
    target=Path(out_path) if out_path else OUT; target.parent.mkdir(parents=True,exist_ok=True); target.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); print(json.dumps(report,ensure_ascii=False,indent=2)); return 0 if ok else 2

if __name__=='__main__': raise SystemExit(main())
