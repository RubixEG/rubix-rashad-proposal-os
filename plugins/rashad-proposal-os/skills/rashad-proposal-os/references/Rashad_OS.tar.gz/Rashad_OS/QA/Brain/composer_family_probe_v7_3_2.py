#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import argparse, hashlib, json, sys, tempfile

ROOT=Path(__file__).resolve().parents[2]
BR=ROOT/'Rashad/Brain/runtime'; QR=ROOT/'QA/Runtime'
sys.path[:0]=[str(BR),str(QR)]
from brain.composition_spec import build_page_composition_spec
from brain.production.renderer import render_composition_page
from brain.production_preexport_qa import run_production_preexport
from brain.imagery_director import build_image_request, validate_image_plate
from brain.image_asset_scanner import scan_image, sha256_file
from qa.unified_html_qa import run as unified_html_run

REGISTRY=json.loads((ROOT/'Rashad/Brain/config/artifact_brain_expert_universe_v3.json').read_text(encoding='utf-8'))
STRATEGIES=set(REGISTRY['communication_strategy_universe'])

def sha(p:Path)->str: return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def _cp(st:str):
    cp={'page_id':'P01','page_role':'ARCHITECTURE','language':'AR','title':'منهجية التنفيذ المتكاملة',
        'thesis':'نظام مترابط يحول القرار إلى تنفيذ قابل للقياس والإثبات',
        'proof_points':['الحوكمة تحدد القرار','التنفيذ يحول القرار إلى عمل','القياس يثبت الأثر','المراجعة تغلق حلقة التحسين'],
        'executive_implication':'المقيّم يرى نظام تشغيل مترابطًا يمكن استمراره بعد انتهاء العقد',
        'source_note':'EV-0001','source_id':'EV-0001','output_classification':'USER_VISIBLE_ARTIFACT_DRAFT'}
    if st=='CHART_LED':
        cp.update({'chart_values':[72,54,68,83],'chart_evidence_refs':['EV-0001']*4,
                   'chart_categories':['الحوكمة','القياس','التنفيذ','التحسين'],
                   'chart_title':'مؤشر جاهزية التنفيذ','chart_unit':'٪'})
    return cp

def run(st:str,out_dir:Path):
    if st not in STRATEGIES: return {'strategy':st,'status':'FAIL','stage':'INPUT','detail':'UNKNOWN_STRATEGY'}
    graph=json.loads((QR/'fixtures/graph.json').read_text(encoding='utf-8'))
    ledger=json.loads((QR/'fixtures/evidence_ledger.json').read_text(encoding='utf-8'))
    exhibit=json.loads((QR/'fixtures/exhibit.json').read_text(encoding='utf-8'))
    base=json.loads((QR/'fixtures/page_spec.json').read_text(encoding='utf-8'))
    brand=ROOT/'Rashad/Skill/08_BRAND_CURRENT/assets/rubix-consulting-current-light.png'
    client=QR/'fixtures/client_test.png'
    plate=QR/'fixtures/image_admission/clean_generated_plate.png'
    hyp={'id':'H1','communication_strategy':st,'strategy_family':'RELATIONAL','page_fingerprint':'V732-'+st}
    cp=_cp(st)
    spec=build_page_composition_spec(hyp,cp,graph,variant_index=0,reference_grammar_ids=['V732-PRODUCTION-CERT'])
    od=Path(out_dir)/st; od.mkdir(parents=True,exist_ok=True)
    image_asset=None; admitted_sha=None; admission=None; scan=None
    if st=='IMAGE_LED':
        scan=scan_image(plate)
        reqwrap=build_image_request(spec,cp)
        if reqwrap.get('status')!='HOST_NATIVE_IMAGE_PENDING':
            return {'strategy':st,'status':'FAIL','stage':'IMAGE_REQUEST','detail':reqwrap}
        req=reqwrap['request']; psha=sha256_file(plate)
        provider_result={'status':'PASS','asset_path':str(plate),'asset_sha256':psha,
                         'provider_actor_id':'V732-CERT-IMAGE-PROVIDER',
                         'proof':{'request_sha256':req['request_sha256']}}
        admission=validate_image_plate(provider_result,req)
        if admission.get('status')!='PASS':
            return {'strategy':st,'status':'FAIL','stage':'IMAGE_ADMISSION','detail':admission,'scan':scan}
        image_asset=plate; admitted_sha=admission.get('asset_sha256')
    r=render_composition_page(spec,cp,graph,od/'render',image_asset=image_asset,
                              allow_test_font_fallback=True,brand_logo=brand,client_logo=client)
    if r.get('status')!='PASS': return {'strategy':st,'status':'FAIL','stage':'RENDER','detail':r}
    pre=run_production_preexport(r['html_master_path'],spec,graph,r['render_path'],od/'pre',
                                 allow_font_waiver=True,admitted_image_sha256=admitted_sha)
    qspec=json.loads(json.dumps(base)); qspec['artifact_expected']=True
    qspec['content_pack']['sources']=['EV-0001']; qspec['page_mode']='ARTIFACT_LED'
    qspec['communication_strategy']=st
    qspec['artifact_family']='CHART' if st=='CHART_LED' else ('HERO_IMAGE' if st=='IMAGE_LED' else spec.get('dominant_form'))
    qspec['content_binding']=spec.get('content_binding') or {}; qspec['page_family']=spec.get('page_family')
    qspec['overlay_policy']=spec.get('overlay_policy') or {}
    qout=od/'unified'; qout.mkdir(parents=True,exist_ok=True)
    uq=unified_html_run(Path(r['html_master_path']),QR/'config/profile_font_waiver.json',qspec,graph,exhibit,qout,'.page',False,ledger)
    page=(uq.get('pages') or [{}])[0]; ub=page.get('blocking_gates') or []
    ok=(pre.get('release_verdict')=='HTML_PREEXPORT_PASS' and uq.get('release_verdict')=='HTML_PREEXPORT_PASS' and not ub)
    return {'strategy':st,'form':spec.get('dominant_form'),'status':'PASS' if ok else 'FAIL',
            'production_preexport':pre.get('release_verdict'),'production_blockers':pre.get('blockers') or [],
            'unified':uq.get('release_verdict'),'unified_blockers':ub,'ceqs':(page.get('ceqs') or {}).get('score'),
            'render_hash':r.get('actual_render_hash'),'spec_sha256':spec.get('spec_sha256'),
            'pixel_metrics':pre.get('pixel_metrics'),'image_scan':scan,'image_admission':admission}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('strategy',choices=sorted(STRATEGIES)); ap.add_argument('--out-dir')
    a=ap.parse_args()
    if a.out_dir:
        outdir=Path(a.out_dir); outdir.mkdir(parents=True,exist_ok=True); out=run(a.strategy,outdir)
        (outdir/(a.strategy+'.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    else:
        with tempfile.TemporaryDirectory(prefix='rashad-v732-family-probe-') as td: out=run(a.strategy,Path(td))
    print(json.dumps(out,ensure_ascii=False,indent=2)); return 0 if out['status']=='PASS' else 2
if __name__=='__main__': raise SystemExit(main())
