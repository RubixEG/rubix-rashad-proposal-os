from pathlib import Path
import sys,json,os,hashlib
ROOT=Path(__file__).resolve().parents[2]; sys.path.insert(0,str(ROOT/'QA'))
from lib.certification_provenance import source_fingerprint
CERT=ROOT/'QA/Certification'; m=json.loads((CERT/'CURRENT_RUN_MANIFEST.json').read_text())
out={'version':'7.3.2','run_id':m.get('run_id'),'source_fingerprint':source_fingerprint(),'completed_suites':sorted(k for k,v in (m.get('suites') or {}).items() if v.get('status')=='PASS'),'evidence_files':sorted((m.get('evidence_files') or {}).keys()),'status':'PASS'}
(CERT/'CURRENT_CERTIFICATION_INDEX.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8'); print(json.dumps(out,ensure_ascii=False,indent=2))
