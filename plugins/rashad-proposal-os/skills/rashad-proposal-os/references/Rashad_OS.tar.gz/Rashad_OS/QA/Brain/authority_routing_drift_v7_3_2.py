from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[2]; sys.path.insert(0,str(ROOT/'Rashad/Brain/runtime'))
from brain.authority_compiler import validate_authority_routing, compile_authority_bundle
CERT=ROOT/'QA/Certification'
qa=validate_authority_routing(); rfp=compile_authority_bundle('RFP_SUMMARY'); art=compile_authority_bundle('ARTIFACT_PRODUCTION')
ok=qa.get('status')=='PASS' and rfp.get('status')=='PASS' and art.get('status')=='PASS' and qa.get('detected')==qa.get('registered')
out={'suite':'V7_3_2_AUTHORITY_ROUTING_DRIFT_AUDIT','status':'PASS' if ok else 'FAIL','routing_qa':qa,'rfp_authority_count':rfp.get('authority_count'),'artifact_authority_count':art.get('authority_count'),'subject':'AUTHORITY_ROUTING_GOVERNANCE_NOT_PRODUCT_QUALITY','rule':'Every detected normative status declaration must be explicitly classified; unclassified drift blocks the production compiler.'}
CERT.mkdir(exist_ok=True); (CERT/'AUTHORITY_ROUTING_DRIFT_V7_3_2.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); print(json.dumps(out,ensure_ascii=False,indent=2)); raise SystemExit(0 if ok else 2)
