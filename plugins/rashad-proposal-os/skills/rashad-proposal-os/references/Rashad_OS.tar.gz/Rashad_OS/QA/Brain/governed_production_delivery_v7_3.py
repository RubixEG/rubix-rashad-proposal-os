#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import json,sys,tempfile
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'Rashad/Brain/runtime')); sys.path.insert(0,str(Path(__file__).parent))
from brain.orchestrator import run_brain
from brain.provider import ScriptedTestProvider
from brain.visual_search import generate_hypotheses
from brain.artifact_council_runtime import execute_artifact_councils
from brain.execution_proof import validate_artifact_execution_ledger,validate_brain_execution_proof
from brain.production.deck_assembly import assemble_certified_deck
from brain.actual_output_qa import evaluate_deck_output
from brain.product_inspector import inspect_pptx,sha256_file
from artifact_delivery_orchestrator import promote_page_to_production,build_delivery_dossier,authorize_delivery
from brain.production_quality_judge import deterministic_pixel_review, deterministic_deck_review
from brain.concept_quality_judge import attach_concept_admission

CASES=[
 ('DECISION_LED','قرار الدخول','التوصية دخول مشروط بأربع بوابات لا تقبل التأجيل'),
 ('CHART_LED','منطق التقييم','الوزن 50% للنطاق و40% للمنهجية و10% للخبرة'),
 ('SEQUENCE_LED','الجدول الزمني','أربع مراحل خلال 12 أسبوعًا تبدأ بالتأسيس ثم البناء ثم التجربة ثم التشغيل'),
 ('ARCHITECTURE_LED','المعمارية التقنية','منصة AI تربط البيانات والتكامل والأمن والتشغيل ضمن حوكمة واحدة'),
 ('COMPARISON_LED','مقارنة الخيارات','مقارنة بين خيارين مع تعارض سعر ومخاطر تنفيذ مختلفة'),
 ('EVIDENCE_LED','الأدلة','كل ادعاء مرتبط بدليل ومصدر وإجراء قبول واضح'),
 ('SCORECARD_LED','التزامات القرار','المخاطر والالتزامات تحتاج قرارًا مشروطًا بدرجات جاهزية وإثبات قبل التسعير'),
 ('NUMBER_LED','حجم الالتزام','ثلاثة مؤشرات حاسمة: 24 شهرًا و12 دورًا و70 نقطة فنية'),
]

def graph(i):
 return {'nodes':[{'id':f'N{i}1','label':'دليل','type':'EVIDENCE'},{'id':f'N{i}2','label':'قرار','type':'DECISION'},{'id':f'N{i}3','label':'تنفيذ','type':'PROCESS'}], 'edges':[{'id':f'E{i}1','source':f'N{i}1','target':f'N{i}2','relation':'SUPPORTS'},{'id':f'E{i}2','source':f'N{i}2','target':f'N{i}3','relation':'ENABLES'}]}

def pixel_reviewer(req):
 return deterministic_pixel_review(req,actor_id='QA-V731-DETERMINISTIC-PIXEL-JUDGE')

def main():
 rows=[]
 with tempfile.TemporaryDirectory() as td:
  td=Path(td); provider=ScriptedTestProvider(); promotions=[]; images=[]
  for i,(wanted,title,thesis) in enumerate(CASES,1):
   cp={'page_id':f'P{i:02d}','language':'AR','title':title,'thesis':thesis,'answer_first_thesis':thesis,'management_question':title,'proof_points':['دليل مثبت','أثر على القرار','إجراء قبول'],'evidence':['E1'],'source_note':'SRC-CERT','numbers':[50,40,10,24,12,70] if wanted in {'CHART_LED','NUMBER_LED'} else []}
   if wanted=='CHART_LED':
    cp['chart_values']=[50,40,10]
    cp['chart_evidence_refs']=['E1','E1','E1']
    cp['chart_categories']=['النطاق','المنهجية','الخبرة']
    cp['chart_title']='توزيع أوزان التقييم الفني'
    cp['chart_unit']='٪'
   g=graph(i); task={'task_id':f'V73-GOV-{i}','rfp_role':'MANAGEMENT_DECISION','critical':True,'rendered':True,'question':title+' '+thesis,'evidence':[{'id':'E1','source':'certification'}]}
   brain=run_brain(task,provider)
   if validate_brain_execution_proof(brain).get('status')!='PASS': raise RuntimeError('brain proof failed')
   search=generate_hypotheses(g,cp)
   hyp=next((h for h in search.get('hypotheses',[]) if h.get('communication_strategy')==wanted),None)
   if not hyp: raise RuntimeError(f'wanted strategy {wanted} not available: {[h.get("communication_strategy") for h in search.get("hypotheses",[])]}')
   pre=execute_artifact_councils(g,cp,provider,'AR','PRE_CONCEPT')
   art=execute_artifact_councils(g,cp,provider,'AR','ART_DIRECTION',prior={'strategy':wanted})
   search['artifact_council_execution']=pre; search['art_direction_execution']=art
   search['final_independent_judgment']={'winner_candidate_id':hyp['id'],'independent':True,'judge_invocation_id':f'TEST-V73-JUDGE-{i}','actual_render_hash':hyp.get('concept_render',{}).get('actual_render_hash')}
   admitted=attach_concept_admission(search,hyp['id'],cp,g,judge_invocation_id=f'TEST-V73-JUDGE-{i}')
   if admitted.get('status')!='PASS': raise RuntimeError(f'concept admission {i} failed: {admitted}')
   search=admitted['search_result']
   p=promote_page_to_production(
      search,pixel_reviewer=pixel_reviewer,content_pack=cp,semantic_graph=g,out_dir=td/f'prod_{i}',brain_session=brain,
      page_contract={'page_id':cp['page_id'],'critical':True},artifact_intent={'strategy':wanted,'decision':title},evidence_lineage={'E1':{'source':'certification'}},
      brand_preflight={'status':'PASS','rubix_asset_status':'VERIFIED'},artifact_provider=provider,allow_test_font_fallback=True)
   if p.get('status')!='PASS': raise RuntimeError(f'promotion {i} failed: {p}')
   promotions.append(p); images.append(p['final_render']['render_path'])
   rows.append({'page_id':cp['page_id'],'strategy':wanted,'promotion':'PASS','artifact_truth':p['production_page'].get('artifact_truth_score'),'ceqs':p['production_page'].get('ceqs_score'),'semantic_master':(p['production_page'].get('semantic_master_qa') or {}).get('status')})
  deck_g={'nodes':[{'id':'D1'},{'id':'D2'}],'edges':[{'id':'DE1','source':'D1','target':'D2','relation':'SEQUENCES'}]}; deck_c={'page_id':'DECK','language':'AR','title':'تسلسل القرار','thesis':'ثمان صفحات متنوعة تقود إلى قرار الإدارة','evidence':['E1']}
  deck_exec=execute_artifact_councils(deck_g,deck_c,provider,'AR','DECK_REVIEW')
  assembled=assemble_certified_deck(promotions,td/'deck',classification='USER_VISIBLE_ARTIFACT_DRAFT',deck_artifact_council_execution=deck_exec)
  if assembled.get('status')!='PASS': raise RuntimeError(f'deck assembly/delivery failed: {assembled}')
  ppt=Path(assembled['pptx_path']); dossier=assembled['dossier']; delivery=assembled['delivery']; deck_review=assembled['deck_review']; product=assembled['dossier']['product_inspection']; deckqa=assembled['dossier']['deck_qa']
  checks={
   'all_8_promotions_pass':len(promotions)==8,
   'all_artifact_truth_ge_90':all(float(p['production_page'].get('artifact_truth_score',0))>=90 for p in promotions),
   'all_ceqs_ge_90':all(float(p['production_page'].get('ceqs_score',0))>=90 for p in promotions),
   'all_semantic_masters_pass':all((p['production_page'].get('semantic_master_qa') or {}).get('status')=='PASS' for p in promotions),
   'all_preconcept_executed':all(validate_artifact_execution_ledger(p['production_page']['artifact_council_execution'],'PRE_CONCEPT').get('status')=='PASS' for p in promotions),
   'all_art_direction_executed':all(validate_artifact_execution_ledger(p['production_page']['art_direction_execution'],'ART_DIRECTION').get('status')=='PASS' for p in promotions),
   'all_production_councils_executed':all(validate_artifact_execution_ledger(p['production_page']['production_council_execution'],'PRODUCTION_READINESS').get('status')=='PASS' for p in promotions),
   'deck_council_executed':validate_artifact_execution_ledger(deck_exec,'DECK_REVIEW').get('status')=='PASS',
   'product_inspection_pass':product.get('status')=='PASS',
   'actual_output_qa_pass':deckqa.get('status')=='PASS',
   'delivery_allowed':delivery.get('status')=='DELIVERY_ALLOWED',
   'handoff_certified':(delivery.get('handoff_certificate') or {}).get('status')=='CERTIFIED_FOR_HANDOFF',
  }
  out={'suite':'Rashad v7.3 Governed Production Delivery Success Path','status':'PASS' if all(checks.values()) else 'FAIL','checks':checks,'pages':rows,'product_blockers':product.get('blockers'),'qa_blockers':deckqa.get('blockers'),'delivery_blockers':delivery.get('blockers'),'rule':'Fail-closed production is certified only if at least one real Brain→Councils→CompositionSpec→Composer→Pixels→QA→Exact-Handoff path succeeds.'}
  (ROOT/'QA/Certification/GOVERNED_PRODUCTION_DELIVERY_V7_3.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8'); print(json.dumps(out,ensure_ascii=False,indent=2)); return 0 if out['status']=='PASS' else 2
if __name__=='__main__': raise SystemExit(main())
