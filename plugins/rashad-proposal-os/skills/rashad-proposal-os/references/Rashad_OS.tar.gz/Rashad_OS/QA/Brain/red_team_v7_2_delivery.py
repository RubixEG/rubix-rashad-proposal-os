#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import sys,json,tempfile,copy
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'Rashad/Brain/runtime'))
sys.path.insert(0,str(Path(__file__).parent))
from brain.actual_output_qa import evaluate_page_output,evaluate_deck_output
from brain.delivery_gate import validate_user_visible_delivery
from brain.product_inspector import inspect_pptx,sha256_file
from delivery_test_fixtures_v7_2 import bad_pptx
from hardened_delivery_fixture_v7_3_2 import build_hardened_user_visible_fixture
OUT=ROOT/'QA/Certification'

def blocked_page(p): return evaluate_page_output(p,'USER_VISIBLE_ARTIFACT_DRAFT')['status']=='BLOCKED'
def record(a,n,ok,d=''): a.append({'attack':n,'status':'BLOCKED' if ok else 'ESCAPED','detail':d})

def main():
    a=[]
    baseline={}
    with tempfile.TemporaryDirectory() as td:
      td=Path(td)
      fx=build_hardened_user_visible_fixture(td/'hardened')
      if fx.get('status')!='PASS':
          out={'suite':'V7.2 User-Visible Artifact Delivery Red Team','status':'FAIL','blocked':0,'total':0,'baseline':{'status':'FAIL','detail':fx},'attacks':[]}
          (OUT/'V7_2_USER_VISIBLE_DELIVERY_RED_TEAM.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,default=str),encoding='utf8')
          print(json.dumps({'suite':out['suite'],'status':'FAIL','reason':'VALID_BASELINE_NOT_AVAILABLE'},ensure_ascii=False,indent=2)); return 2
      ppt=Path(fx['pptx_path']); pages=fx['pages']; dossier=fx['dossier']; dr=fx['deck_review']; pi=fx['product']
      dh=sha256_file(ppt); mh=dossier['montage_sha256']; baseline_gate=validate_user_visible_delivery(dossier,ppt)
      baseline={'status':'PASS' if baseline_gate.get('status')=='DELIVERY_ALLOWED' else 'FAIL','delivery_status':baseline_gate.get('status'),'blockers':baseline_gate.get('blockers',[])}
      if baseline['status']!='PASS':
          out={'suite':'V7.2 User-Visible Artifact Delivery Red Team','status':'FAIL','blocked':0,'total':0,'baseline':baseline,'attacks':[]}
          (OUT/'V7_2_USER_VISIBLE_DELIVERY_RED_TEAM.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
          print(json.dumps(out,ensure_ascii=False,indent=2)); return 2
      # Page attacks start from a page that independently passes the user-visible page gate.
      record(a,'concept_wireframe_as_user_visible',blocked_page({**copy.deepcopy(pages[1]),'render_kind':'COMMUNICATION_STRATEGY_CONCEPT_RENDER_V3'}))
      x=copy.deepcopy(pages[1]); x['actual_pixel_review']={'status':'NOT_EXECUTED'}; record(a,'no_pixel_review',blocked_page(x))
      x=copy.deepcopy(pages[1]); x['actual_pixel_review']['independent']=False; record(a,'producer_reviews_own_pixels',blocked_page(x))
      x=copy.deepcopy(pages[1]); x['actual_pixel_review']['producer_actor_collision']=True; record(a,'producer_actor_collision',blocked_page(x))
      x=copy.deepcopy(pages[1]); x['actual_pixel_review']['actual_render_hash']='a'*64; record(a,'review_wrong_render_hash',blocked_page(x))
      x=copy.deepcopy(pages[1]); x['actual_pixel_review']['scores']['simplicity']=40; record(a,'low_simplicity_hidden_by_high_average',blocked_page(x))
      x=copy.deepcopy(pages[1]); x['actual_pixel_review']['generic_layout_swap_test']='FAIL'; record(a,'generic_label_swap_page',blocked_page(x))
      x=copy.deepcopy(pages[1]); x['actual_pixel_review']['artifact_skeptic_test']='FAIL'; record(a,'decoration_only_artifact',blocked_page(x))
      x=copy.deepcopy(pages[1]); x['actual_pixel_review']['five_second_test']='FAIL'; record(a,'fails_five_second_test',blocked_page(x))
      x=copy.deepcopy(pages[1]); x['actual_pixel_review']['hard_blockers']=['WEAK']; record(a,'hard_blocker_averaged_away',blocked_page(x))
      x=copy.deepcopy(pages[1]); x['repair_required']=True; x['repair_history']=[]; record(a,'failed_round_without_repair',blocked_page(x))
      x=copy.deepcopy(pages[1]); x.pop('production_render_id',None); record(a,'missing_production_render_identity',blocked_page(x))
      # Deck attacks assert the intended deck blocker is present, not merely that some unrelated page gate failed.
      dup=copy.deepcopy(pages); dup[2]['selected_render_hash']=dup[1]['selected_render_hash']; q=evaluate_deck_output(dup,'INTERNAL'); record(a,'cross_page_render_hash_reuse','CROSS_PAGE_RENDER_HASH_REUSE' in q.get('blockers',[]),str(q.get('blockers')))
      diag=copy.deepcopy(pages)
      for p in diag[:6]: p['selected_strategy']='SYSTEM_LED'
      q=evaluate_deck_output(diag,'INTERNAL'); record(a,'diagram_overuse','DECK_DIAGRAM_OVERUSE' in q.get('blockers',[]),str(q.get('blockers')))
      same=copy.deepcopy(pages)
      for p in same[:4]: p['selected_strategy']='STATEMENT_LED'
      q=evaluate_deck_output(same,'INTERNAL'); record(a,'four_same_strategy_run','FOUR_CONSECUTIVE_SAME_COMMUNICATION_STRATEGY' in q.get('blockers',[]),str(q.get('blockers')))
      lowvar=copy.deepcopy(pages)
      for i,p in enumerate(lowvar): p['selected_strategy']='STATEMENT_LED' if i%2==0 else 'NUMBER_LED'
      q=evaluate_deck_output(lowvar,'INTERNAL'); record(a,'insufficient_deck_strategy_variety','INSUFFICIENT_DECK_COMMUNICATION_VARIETY' in q.get('blockers',[]),str(q.get('blockers')))
      norev=copy.deepcopy(dossier); norev['deck_pixel_review']={}; record(a,'no_deck_pixel_review',validate_user_visible_delivery(norev,ppt)['status']=='BLOCK_DELIVERY')
      badhash=copy.deepcopy(dossier); badhash['deck_pixel_review']['deck_sha256']='b'*64; record(a,'deck_review_wrong_file_hash',validate_user_visible_delivery(badhash,ppt)['status']=='BLOCK_DELIVERY')
      badmont=copy.deepcopy(dossier); badmont['deck_pixel_review']['montage_sha256']='c'*64; record(a,'deck_review_wrong_montage_hash',validate_user_visible_delivery(badmont,ppt)['status']=='BLOCK_DELIVERY')
      sub=copy.deepcopy(dossier); sub['framework_certification_substitute']=True; record(a,'framework_qa_substitution',validate_user_visible_delivery(sub,ppt)['status']=='BLOCK_DELIVERY')
      noart=copy.deepcopy(dossier); noart['artifact_brain_execution_status']='PASS_FROM_FRAMEWORK_TEST'; record(a,'no_artifact_execution_proof',validate_user_visible_delivery(noart,ppt)['status']=='BLOCK_DELIVERY')
      noprod=copy.deepcopy(dossier); noprod['production_render_status']='NOT_EXECUTED'; record(a,'no_production_render_proof',validate_user_visible_delivery(noprod,ppt)['status']=='BLOCK_DELIVERY')
      noqaloop=copy.deepcopy(dossier); noqaloop['actual_output_qa_closed_loop_status']='DRAFT_QA_PARTIAL'; record(a,'partial_qa_called_delivery_ready',validate_user_visible_delivery(noqaloop,ppt)['status']=='BLOCK_DELIVERY')
      filem=copy.deepcopy(dossier); filem['output_file_sha256']='d'*64; record(a,'dossier_bound_to_different_pptx',validate_user_visible_delivery(filem,ppt)['status']=='BLOCK_DELIVERY')
      bind=copy.deepcopy(dossier); bind['projection_media_binding']['embedded_media_hashes']=list(reversed(bind['projection_media_binding']['embedded_media_hashes'])); record(a,'reordered_projection_media_hashes',validate_user_visible_delivery(bind,ppt)['status']=='BLOCK_DELIVERY')
      # real incident shape-only profile
      bad=td/'bad.pptx'; bad_pptx(bad); bi=inspect_pptx(bad); record(a,'shape_only_template_deck',bi['status']=='BLOCKED',str(bi['blockers']))
      # Strategy claims cannot convert unrelated card/shape bytes into the expected semantic product.
      ip=inspect_pptx(bad,pages); record(a,'strategy_label_lies_about_actual_objects',ip['status']=='BLOCKED',str(ip['blockers']))
    escaped=[x for x in a if x['status']!='BLOCKED']; out={'suite':'V7.2 User-Visible Artifact Delivery Red Team','status':'PASS' if not escaped and baseline.get('status')=='PASS' else 'FAIL','baseline':baseline,'blocked':len(a)-len(escaped),'total':len(a),'attacks':a}
    (OUT/'V7_2_USER_VISIBLE_DELIVERY_RED_TEAM.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps({'suite':out['suite'],'status':out['status'],'baseline':baseline,'blocked':out['blocked'],'total':out['total'],'escaped':escaped},ensure_ascii=False,indent=2)); return 0 if out['status']=='PASS' else 2
if __name__=='__main__': raise SystemExit(main())
