#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[2]; BR=ROOT/'Rashad/Brain/runtime'; CERT=ROOT/'QA/Certification'
sys.path[:0]=[str(BR)]
from brain.depth_enforcement import load_contract,pages_required,validate_role_output,strength_floor
from brain.artifact_council_runtime import natural_role_coverage,execute_artifact_councils
from brain.router import natural_trigger_coverage,route
from brain.provider import AdversarialCouncilProvider
OUT=CERT/'COUNCIL_DEPTH_ACCEPTANCE_V7_3_2.json'

def t(name,ok,detail=None): return {'name':name,'status':'PASS' if ok else 'FAIL','detail':detail}

def main(out_path=None):
    rows=[]; c=load_contract(); floor=strength_floor()
    rows.append(t('depth_authority_is_machine_readable_24_roles_226_items',c.get('role_count')==24 and c.get('mandatory_item_count')==226,{'roles':c.get('role_count'),'items':c.get('mandatory_item_count')}))
    numeric=['body_min_pt','table_body_min_pt','label_min_pt','source_min_pt','title_min_pt','arabic_body_min_pt','arabic_table_body_min_pt']
    rows.append(t('strength_floor_is_numeric_and_blocking',all(isinstance(floor.get(k),(int,float)) and floor.get(k)>0 for k in numeric) and floor.get('status')=='BLOCKING_NUMERIC_STRENGTH_FLOOR',{k:floor.get(k) for k in numeric}|{'status':floor.get('status')}))
    exp={rid:pages_required(rid)['pages_required'] for rid in ['BOQ_INTELLIGENCE','COMMERCIAL_EXPOSURE','RISKS','TECHNICAL_REQUIREMENTS']}
    rows.append(t('page_count_is_computed_not_fixed',exp=={'BOQ_INTELLIGENCE':2,'COMMERCIAL_EXPOSURE':3,'RISKS':3,'TECHNICAL_REQUIREMENTS':3},exp))
    # Reproduce the shallow-commercial-exposure defect class: half the mandatory items cannot satisfy the role.
    rc=next(x for x in c['roles'] if x['canonical_id']=='COMMERCIAL_EXPOSURE'); mids=[x['id'] for x in rc['mandatory_items']]; aids=[x['id'] for x in rc['required_analysis_items']]
    cov=[{'item_id':iid,'status':'COVERED','evidence_refs':['EV-1'],'page_ids':['P1'],'visible_text_fragment':'evidence'} for iid in mids[:8]]
    acov=[{'item_id':iid,'status':'COVERED','evidence_refs':['EV-1']} for iid in aids]
    shallow={'mandatory_item_coverage':cov,'analysis_item_coverage':acov,'management_implication':'أثر إداري','artifact_intent':'COMMERCIAL_EXPOSURE','page_ids':['P1'],'render_strength_metrics':{'body_min_pt':16,'table_body_min_pt':14,'label_min_pt':12,'source_min_pt':10,'title_min_pt':24},'cost_drivers':[{'driver':'الفريق','known_quantity_or_basis':'24×12','confidence':'HIGH','commercial_effect':'تكلفة','evidence_refs':['EV-1']}], 'team_count':24,'contract_months':12,'person_months':288}
    vr=validate_role_output('COMMERCIAL_EXPOSURE',shallow); missing=[x for x in vr.get('blockers',[]) if x.startswith('DEPTH_MANDATORY_ITEM_MISSING:')]
    rows.append(t('shallow_commercial_exposure_8_of_16_is_blocked',vr.get('status')=='BLOCKED' and len(missing)==8 and any('DEPTH_EXPANSION_REQUIRED' in x for x in vr.get('blockers',[])),{'missing_count':len(missing),'blockers':vr.get('blockers')}))
    ar=natural_role_coverage(); seen=set(ar.get('naturally_selectable_role_ids') or [])
    sme_ids={'AR-TRANSFORMATION-SME','AR-OPERATING-MODEL-SME','AR-VALUE-CREATION-SME','AR-SOURCE-INTEGRITY-SME','AR-DECISION-COMMUNICATION-SME','AR-PRICING-SME','AR-COMMERCIAL-SME','AR-STATISTICS-SME','AR-FINANCIAL-MODELING-SME'}
    attacker_ids={'AR-GENERIC-LAYOUT-ATTACKER','AR-DIAGRAM-OVERUSE-ATTACKER','AR-TEMPLATE-SIMILARITY-ATTACKER','AR-FIVE-SECOND-COMPREHENSION-ATTACKER','AR-EVIDENCE-OMISSION-ATTACKER','AR-COMPLEXITY-ATTACKER'}
    rows.append(t('all_107_artifact_roles_naturally_selectable_without_injection',ar.get('status')=='PASS' and ar.get('registered_roles')==ar.get('naturally_selectable_roles')==107,ar))
    rows.append(t('all_9_artifact_smes_naturally_selectable',sme_ids<=seen,{'missing':sorted(sme_ids-seen)}))
    rows.append(t('all_6_red_team_attackers_naturally_selectable',attacker_ids<=seen,{'missing':sorted(attacker_ids-seen)}))
    role_ids=[x['canonical_id'] for x in c['roles']]; cr=natural_trigger_coverage(role_ids)
    rows.append(t('all_16_cognitive_councils_naturally_triggered',cr.get('status')=='PASS' and cr.get('count')==cr.get('total')==16,cr))
    commercial_route=route('COMMERCIAL_EXPOSURE',critical=True,rendered=True,deck=False,final_release=False)
    expected={'C03_EPISTEMIC_TRUTH','C04_COMMERCIAL_FINANCIAL','C07_LEGAL_PROCUREMENT_COMPLIANCE','C09_CAUSAL_SCENARIO','C13_ADVERSARIAL_COUNTERFACTUAL','C15_META_COGNITION_INTEGRITY'}
    rows.append(t('commercial_exposure_routes_required_sentinels_and_domain_councils',expected<=set(commercial_route),{'route':commercial_route,'missing':sorted(expected-set(commercial_route))}))
    adverse=execute_artifact_councils({'nodes':[{'id':'N1'}],'edges':[]},{'page_id':'P1','page_role':'COMMERCIAL_EXPOSURE','role_id':'COMMERCIAL_EXPOSURE','language':'AR'},provider=AdversarialCouncilProvider(severity='CRITICAL',veto=False),stage='PRE_CONCEPT')
    rows.append(t('critical_council_finding_changes_release_outcome',adverse.get('status')=='BLOCKED' and any(e.get('kind')=='ARTIFACT_COUNCIL_OPEN_HIGH_SEVERITY_FINDING' for e in adverse.get('errors',[])),{'status':adverse.get('status'),'findings':len(adverse.get('findings') or []),'errors':adverse.get('errors')}))
    ok=all(x['status']=='PASS' for x in rows)
    out={'suite':'Rashad v7.3.2 Council + SME + Depth Acceptance','status':'PASS' if ok else 'FAIL','passed':sum(x['status']=='PASS' for x in rows),'total':len(rows),'tests':rows,'rule':'Registered is not execution. Certification requires natural routing, executable depth rejection and findings that change the release outcome.'}
    target=Path(out_path) if out_path else OUT; target.parent.mkdir(parents=True,exist_ok=True); target.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); print(json.dumps(out,ensure_ascii=False,indent=2)); return 0 if ok else 2
if __name__=='__main__': raise SystemExit(main())
