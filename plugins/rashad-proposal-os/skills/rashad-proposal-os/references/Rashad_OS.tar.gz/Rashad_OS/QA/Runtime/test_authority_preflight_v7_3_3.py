# -*- coding: utf-8 -*-
"""Permanent regression fixtures for RASHAD-INC-2026-08-18.
Every confirmed defect becomes a fixture before closure."""
import os, sys, json, pathlib, subprocess, tempfile

ROOT = pathlib.Path(__file__).resolve().parents[2]
P = ROOT / "Rashad" / "Brain" / "runtime" / "brain" / "authority_preflight.py"


def run(args, ledger):
    env = dict(os.environ, RASHAD_LEDGER_DIR=str(ledger))
    return subprocess.run([sys.executable, str(P)] + args, capture_output=True,
                          text=True, env=env, cwd=str(ROOT))


def fresh(tmp, product="RFP_SUMMARY_ARTIFACT"):
    run(["--init", product], tmp)


def main():
    fails = []
    with tempfile.TemporaryDirectory() as td:
        tmp = pathlib.Path(td)

        # FIX-AUTH-COVERAGE-01 — the incident state must block
        fresh(tmp)
        run(["--attest", "00_CHAT_MIRROR_KERNEL/00_RASHAD_BOOTSTRAP.md",
             "Binds the engagement startup order and makes authority preflight the first action before ingestion.",
             "startup"], tmp)
        r = json.loads(run(["--gate", "USER_VISIBLE_ARTIFACT"], tmp).stdout)
        if r["status"] != "BLOCK_PRODUCTION":
            fails.append("FIX-AUTH-COVERAGE-01 :: partial ledger did not block client-visible output")

        # advisory path must warn, not block
        r = json.loads(run(["--gate", "ADVISORY"], tmp).stdout)
        if r["status"] != "PROCEED_WITH_COVERAGE_BANNER" or not r["banner"]:
            fails.append("FIX-AUTH-COVERAGE-01b :: advisory path lost its coverage banner")

        # FIX-AUTH-COVERAGE-03 — templated attestations
        fresh(tmp)
        same = ("Binds visible naming, numeral policy, brand signature placement, evaluation "
                "weighting, delivery gating and evidence locators across every produced page.")
        for f in ["00_CHAT_MIRROR_KERNEL/01_OWNER_POLICY.md",
                  "00_CHAT_MIRROR_KERNEL/03_PRODUCT_REGISTRY.md",
                  "00_CHAT_MIRROR_KERNEL/12_CONTEXT_ROUTER.md"]:
            run(["--attest", f, same, "deck"], tmp)
        r = json.loads(run(["--gate", "USER_VISIBLE_ARTIFACT"], tmp).stdout)
        if not any("TEMPLATED" in b for b in r["blockers"]):
            fails.append("FIX-AUTH-COVERAGE-03 :: identical attestations were accepted")

        # thin / echo attestations
        out = run(["--attest", "00_CHAT_MIRROR_KERNEL/01_OWNER_POLICY.md", "read it", "x"], tmp)
        if "ATTESTATION_TOO_THIN" not in (out.stdout + out.stderr):
            fails.append("ATTESTATION_TOO_THIN not enforced")

        # FIX-AUTH-COVERAGE-02 — uncovered authorities are NOT_EXECUTED, never PASS
        sys.path.insert(0, str(P.parent))
        os.environ["RASHAD_LEDGER_DIR"] = str(tmp)
        import importlib, authority_preflight as ap
        importlib.reload(ap)
        cov = ap.gate_coverage({"G_OVERFLOW": ["01_ACTIVE_RUNTIME/29_PRODUCTION_EXECUTION_FIREWALL.md"]})
        if cov["status"] != "NOT_EXECUTED" or not cov["authorities_not_executed"]:
            fails.append("FIX-AUTH-COVERAGE-02 :: partial gate map reported PASS")

    print(json.dumps({"fixtures": 6, "failed": len(fails), "failures": fails},
                     ensure_ascii=False, indent=1))
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
