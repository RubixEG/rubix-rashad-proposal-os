#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import sys,json,tempfile
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'Rashad/Brain/runtime')); sys.path.insert(0,str(Path(__file__).parent))
from brain.execution_proof import validate_artifact_execution_ledger,validate_brain_execution_proof
from brain.delivery_gate import validate_user_visible_delivery
from brain.product_inspector import inspect_pptx
from golden_redf_fixture_v7_2 import bad_pptx
from hardened_delivery_fixture_v7_3_2 import build_hardened_user_visible_fixture
OUT=ROOT/'QA/Certification'

STRATEGIES=['IMAGE_LED','DECISION_LED','NUMBER_LED','SYSTEM_LED','EVIDENCE_LED','ARCHITECTURE_LED','TABLE_LED','JOURNEY_LED','STATEMENT_LED','CHART_LED','COMPARISON_LED','MATRIX_LED','SCORECARD_LED','PROCESS_LED']

def main():
  with tempfile.TemporaryDirectory() as td0:
    td=Path(td0)
    fx=build_hardened_user_visible_fixture(td/'golden',STRATEGIES)
    if fx.get('status')!='PASS': raise RuntimeError('hardened golden fixture failed: '+repr({'reason':fx.get('reason'),'page':fx.get('page'),'review':fx.get('review')}))
    ppt=Path(fx['pptx_path']); pages=fx['pages']; product=fx['product']; deckqa=fx['deck_qa']; dossier=fx['dossier']; deck_exec=fx['deck_exec']
    delivery=validate_user_visible_delivery(dossier,ppt)
    inc=json.load(open(ROOT/'QA/Runtime/fixtures/incidents/INCIDENT_REDF_20260816_SHAPE_ONLY_ARTIFACT_COLLAPSE.json',encoding='utf-8'))
    bad=td/'incident_bad.pptx'; bad_pptx(bad); neg=inspect_pptx(bad)
    checks={
      'golden_page_count_14':product.get('slide_count')==14,
      'all_14_pages_have_real_brain_execution':len(pages)==14 and all(validate_brain_execution_proof(p['brain_session_execution_evidence'])['status']=='PASS' for p in pages),
      'all_14_pages_have_all_three_artifact_execution_stages':all(validate_artifact_execution_ledger(p['artifact_council_execution'],'PRE_CONCEPT')['status']=='PASS' and validate_artifact_execution_ledger(p['art_direction_execution'],'ART_DIRECTION')['status']=='PASS' and validate_artifact_execution_ledger(p['production_council_execution'],'PRODUCTION_READINESS')['status']=='PASS' for p in pages),
      'deck_review_council_execution_pass':validate_artifact_execution_ledger(deck_exec,'DECK_REVIEW')['status']=='PASS',
      'golden_product_inspection_pass':product.get('status')=='PASS',
      'golden_actual_output_qa_pass':deckqa.get('status')=='PASS',
      'golden_exact_file_delivery_allowed':delivery.get('status')=='DELIVERY_ALLOWED',
      'golden_media_bound_to_certified_renders':(dossier.get('projection_media_binding') or {}).get('media_binding_status')=='PASS',
      'golden_continuity_pass':(dossier.get('deck_continuity_qa') or {}).get('status')=='PASS',
      'golden_style_convergence_pass':(dossier.get('style_convergence_qa') or {}).get('status')=='PASS',
      'strategy_variety_at_least_8':len(set(STRATEGIES))>=8,
      'not_diagram_dominated':deckqa.get('diagram_ratio',1)<=.55,
      'incident_profile_still_blocked':inc.get('status')=='BLOCKED',
      'incident_shape_only_signature_locked':'PPTX_SHAPE_ONLY_ANALYTICAL_DECK_OVERUSE' in inc.get('blockers',[]),
      'synthetic_bad_deck_still_blocked':neg.get('status')=='BLOCKED',
    }
    out={'suite':'Rashad v7.2 Golden REDF End-to-End Brain→Artifact→Pixel-QA Acceptance — v7.3.2 hardened baseline','status':'PASS' if all(checks.values()) else 'FAIL','checks':checks,'strategy_count':len(set(STRATEGIES)),'diagram_ratio':deckqa.get('diagram_ratio'),'golden_product_blockers':product.get('blockers'),'golden_qa_blockers':deckqa.get('blockers'),'delivery_blockers':delivery.get('blockers'),'incident_blockers':inc.get('blockers'),'fixture_bypass_used':False}
    (OUT/'V7_2_GOLDEN_REDF_ACCEPTANCE.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(out,ensure_ascii=False,indent=2)); return 0 if out['status']=='PASS' else 2
if __name__=='__main__': raise SystemExit(main())
