#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import json,sys,tempfile
ROOT=Path(__file__).resolve().parents[2]
BR=ROOT/'Rashad/Brain/runtime'; QR=ROOT/'QA/Runtime'
sys.path.insert(0,str(QR)); sys.path.insert(0,str(BR))
from brain.composition_spec import build_page_composition_spec
from brain.production.renderer import render_composition_page
from qa.unified_html_qa import run as unified_html_run

OUT=ROOT/'QA/Certification/COMPOSER_FAMILY_TRUTH_V7_3_1.json'

def main():
    graph=json.loads((QR/'fixtures/graph.json').read_text(encoding='utf-8'))
    ledger=json.loads((QR/'fixtures/evidence_ledger.json').read_text(encoding='utf-8'))
    exhibit=json.loads((QR/'fixtures/exhibit.json').read_text(encoding='utf-8'))
    brand_logo=ROOT/'Rashad/Skill/08_BRAND_CURRENT/assets/rubix-consulting-current-light.png'
    client_logo=QR/'fixtures/client_test.png'
    strategies=['SYSTEM_LED','ARCHITECTURE_LED','JOURNEY_LED','MATRIX_LED']
    rows=[]
    with tempfile.TemporaryDirectory() as td:
        td=Path(td)
        for i,st in enumerate(strategies):
            hyp={'id':f'H{i+1}','communication_strategy':st,'strategy_family':'RELATIONAL','page_fingerprint':f'V731-{st}'}
            cp={'page_id':f'P{i+1:02d}','language':'AR','title':'منهجية التنفيذ','thesis':'نظام مترابط تحكمه بوابات قرار وتغذية راجعة','proof_points':['كل مرحلة تنتج قرارًا أو دليلًا قابلًا للمراجعة','الحوكمة وضمان الجودة تعبران جميع المراحل','المقيّم يرى نظام تشغيل مغلقًا'],'executive_implication':'المقيّم يرى نظام تشغيل مترابطًا يمكن استمراره بعد انتهاء العقد','source_note':'EV-0001'}
            spec=build_page_composition_spec(hyp,cp,graph,variant_index=i)
            r=render_composition_page(spec,cp,graph,td/st,allow_test_font_fallback=True,brand_logo=brand_logo,client_logo=client_logo)
            if r.get('status')!='PASS':
                rows.append({'strategy':st,'status':'FAIL','stage':'RENDER','detail':r}); continue
            qspec=json.loads((QR/'fixtures/page_spec.json').read_text(encoding='utf-8'))
            qspec['artifact_family']='MATRIX' if st=='MATRIX_LED' else 'SYSTEM'
            qspec['artifact_expected']=True; qspec['content_pack']['sources']=['EV-0001']
            qout=td/f'{st}_qa'; qout.mkdir(exist_ok=True)
            uq=unified_html_run(Path(r['html_master_path']),QR/'config/profile_font_waiver.json',qspec,graph,exhibit,qout,'.page',False,ledger)
            page=(uq.get('pages') or [{}])[0]; ceqs=page.get('ceqs') or {}
            blockers=page.get('blocking_gates') or []
            ok=uq.get('release_verdict')=='HTML_PREEXPORT_PASS' and float(ceqs.get('score',0))>=90 and not blockers
            rows.append({'strategy':st,'status':'PASS' if ok else 'FAIL','release_verdict':uq.get('release_verdict'),'ceqs':ceqs.get('score'),'blockers':blockers,'render_hash':r.get('actual_render_hash'),'spec_sha256':spec.get('spec_sha256')})
    out={'suite':'Rashad v7.3.1 Composer Family Production Truth','status':'PASS' if all(x['status']=='PASS' for x in rows) else 'FAIL','passed':sum(x['status']=='PASS' for x in rows),'total':len(rows),'tests':rows}
    OUT.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(out,ensure_ascii=False,indent=2))
    return 0 if out['status']=='PASS' else 2
if __name__=='__main__': raise SystemExit(main())
