from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[2]; sys.path.insert(0,str(ROOT/'QA'))
from lib.certification_provenance import load_authenticated_json
FIX=ROOT/'QA/Runtime/fixtures/engagement'; CERT=ROOT/'QA/Certification'
d,auth=load_authenticated_json('ENGAGEMENT_ARTIFACT_ACCEPTANCE_V7_3.json'); tests=[]
def add(n,ok,detail=None): tests.append({'name':n,'status':'PASS' if ok else 'FAIL','detail':detail})
add('acceptance_evidence_authenticated',auth.get('status')=='PASS',auth)
rows=d.get('artifacts') or []
add('two_real_baselines',len(rows)==2,len(rows))
for r in rows:
    p=FIX/r.get('name',''); actual=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
    add('fixture_exists_'+str(r.get('name')),p.exists(),str(p))
    add('fixture_hash_recomputed_'+str(r.get('name')),actual==r.get('sha256'),{'actual':actual,'recorded':r.get('sha256')})
    add('fixture_expected_blocked_'+str(r.get('name')),r.get('acceptance_status')=='BLOCKED',r.get('blockers'))
out={'suite':'ENGAGEMENT_ACCEPTANCE_EVIDENCE_VERIFIER_V7_3_2','status':'PASS' if all(x['status']=='PASS' for x in tests) else 'FAIL','tests':tests}
(CERT/'ENGAGEMENT_ACCEPTANCE_EVIDENCE_VERIFIER_V7_3.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8'); print(json.dumps(out,ensure_ascii=False,indent=2)); raise SystemExit(0 if out['status']=='PASS' else 1)
