from __future__ import annotations

def topological_items(items):
    """Stable topological sort over declared evidence producers/consumers.

    Each item may declare `produces` and `consumes` as evidence paths relative to
    QA/Certification. Duplicate producers, missing producers and cycles are hard
    errors. Original item order is preserved wherever no dependency constrains it.
    """
    original={x['name']:i for i,x in enumerate(items)}
    by={x['name']:x for x in items}
    producers={}
    for it in items:
        for ev in it.get('produces') or []:
            if ev in producers and producers[ev]!=it['name']:
                raise RuntimeError(f'DUPLICATE_EVIDENCE_PRODUCER::{ev}::{producers[ev]}::{it["name"]}')
            producers[ev]=it['name']
    deps={x['name']:set() for x in items}
    for it in items:
        for ev in it.get('consumes') or []:
            prod=producers.get(ev)
            if not prod:
                raise RuntimeError(f'MISSING_DECLARED_EVIDENCE_PRODUCER::{it["name"]}::{ev}')
            if prod!=it['name']: deps[it['name']].add(prod)
    out=[]; remaining=set(by)
    while remaining:
        ready=sorted((n for n in remaining if not (deps[n] & remaining)),key=lambda n:original[n])
        if not ready:
            cycle={n:sorted(deps[n]&remaining) for n in sorted(remaining)}
            raise RuntimeError('CERTIFICATION_DEPENDENCY_CYCLE::'+repr(cycle))
        for n in ready:
            out.append(by[n]); remaining.remove(n)
    return out
